"""Finite, one-shot pidfd wait for one already-running, owned soak.

Never starts/restarts/signals the runner, changes acceptance or cleans resources.
Only the existing immutable terminal auditor can create the acceptance artifact.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import select
import subprocess
import sys
import time
from datetime import UTC, datetime

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
SOAK = ROOT / '.qa/soak-cash-20261018-79f7ab59792c'
EVIDENCE = ROOT / 'docs/acceptance/evidence'
LAUNCH = EVIDENCE / 'soak-24h-cash-20261018-79f7ab59792c-launch.json'
TERMINAL = EVIDENCE / 'soak-24h-cash-20261018-79f7ab59792c-terminal-review.json'
RUN_ID = '79f7ab59792c'
SOURCE = '4fd1380c5c1595bfb8bbd311f02ec561fc013eac5f7da9563dc5c025151d1d30'
MODEL = '6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e'
BOOT = '8e2a4ea6-7359-453d-8da4-23627cd94395'
NAMESPACE = 'pid:[4026532221]'
HELPERS = {
    'audit_terminal.py': 'edff62ee6e46df6f8cce304e0afd05bf276abec3649f9d762d0af4b03fcd7e03',
    'process_identity.py': 'be61cb68419c10faa8711ef9105224e5c85657b041b81d5640bef53253d4c5d7',
    'sitecustomize.py': '4b941a89e907a4a11ea18af9740777642cc1c7b3d92a4272a6573ae94a7245c3',
    'launch.py': 'cb13c7fb96dbf823ae568d65d7e52bd868d1f04ba72e4e8e54bd0acd6d2c34bf',
    'source-input-manifest.json': '02361ea2492a487ac985fe208fd85a7f35997a01e536360b44ac88454108241c',
    # launch.py updates plan.json with the actual verified process identities.
    # Bind that retained running plan, rather than its pre-launch preparation hash.
    'plan.json': 'ac596d0779aefe61c149e50e735690574c1e7c6569de22ae66189c90e56196cf',
}


class Refusal(Exception):
    pass


def require(condition, code):
    if not condition:
        raise Refusal(code)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def now():
    return datetime.now(UTC).isoformat()


def save(name, value):
    with (WORK / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def exact_environment():
    env = {
        'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8',
        'PYTHONPATH': str(SOAK) + ':' + str(ROOT),
        'PYTHONDONTWRITEBYTECODE': '1',
        'LD_LIBRARY_PATH': str(ROOT / '.qa/postgres-root/usr/lib/x86_64-linux-gnu'),
        'PGPASSFILE': '/dev/null', 'PGSERVICEFILE': '/dev/null',
        'NEWS_SOURCE_POLICIES': '{}', 'NEWS_SERVICE_USER_ID': '',
        'NEWSLETTER_OWNER_USER_ID': '', 'NEWSLETTER_EMAIL_USER': '',
        'NEWSLETTER_EMAIL_PASSWORD': '',
    }
    for key in ('LIVE_TRADING_ENABLED', 'IBKR_ENABLED', 'BANK_SYNC_ENABLED',
                'MCP_ENABLED', 'AUTONOMOUS_SCANS_ENABLED', 'NEWS_API_ADAPTERS_ENABLED',
                'YAHOO_MARKET_DATA_ENABLED', 'YAHOO_HISTORICAL_DATA_ENABLED'):
        env[key] = 'false'
    return env


def checked_bindings():
    require(not sys.flags.optimize, 'OPTIMIZATION_REFUSED')
    require(WORK == ROOT / ('.qa/soak-cash-terminal-20261018-' + RUN_ID), 'PATH_MISMATCH')
    for name, expected in HELPERS.items():
        require(digest(SOAK / name) == expected, 'BOUND_HELPER_CHANGED_' + name)
    # Import only after verifying the existing identity helper.
    from process_identity import context_status
    require(context_status(BOOT, NAMESPACE) == 'MATCH', 'NATIVE_BOOT_NAMESPACE_REQUIRED')
    plan = json.loads((WORK / 'observer-plan.json').read_text())
    require(plan.get('run_id') == RUN_ID and plan.get('source_sha256') == SOURCE
            and plan.get('model_sha256') == MODEL, 'OBSERVER_PLAN_MISMATCH')
    for name in ('observer.py', 'launch_once.py'):
        require(digest(WORK / name) == plan['helper_sha256'][name], 'OBSERVER_HELPER_CHANGED')
    require(digest(LAUNCH) == plan['launch_receipt_sha256'], 'LAUNCH_RECEIPT_CHANGED')
    preparation = SOAK / 'preparation-review.json'
    require(digest(preparation) == plan['preparation_review_sha256'], 'PREPARATION_CHANGED')
    env = exact_environment()
    require(json.loads(preparation.read_text())['clean_parent_environment'] == env,
            'ORIGINAL_CLEAN_ENVIRONMENT_MISMATCH')
    require(dict(os.environ) == env, 'INHERITED_ENVIRONMENT_REFUSED')
    launch = json.loads(LAUNCH.read_text())
    require(launch.get('run_id') == RUN_ID and launch.get('code_sha256') == SOURCE
            and launch.get('model_sha256') == MODEL, 'RUN_BINDING_MISMATCH')
    identity = launch['runner_identity']
    require(identity['pid'] == launch['runner_pid'] == 333647
            and identity['start_ticks'] == 5593877
            and identity['command_sha256'] == '191e080c92b7df9ea52783273868f9aebcaccb405b6ce27c4377c9dc29916dca'
            and identity['boot_id'] == BOOT and identity['pid_namespace'] == NAMESPACE,
            'RUNNER_IDENTITY_MISMATCH')
    return plan, launch, identity, env


def preflight():
    _, launch, identity, env = checked_bindings()
    from process_identity import matches
    require(matches(identity) and matches(launch['postgres_identity']), 'OWNED_PROCESS_NOT_LIVE')
    require(not TERMINAL.exists(), 'TERMINAL_ARTIFACT_ALREADY_PRESENT')
    for name in ('observer-start.json', 'observer-result.json', 'auditor-start.json',
                 'auditor-output.log', 'observer-output.log', 'launch-execution.json', 'launch-claim.json'):
        require(not (WORK / name).exists(), 'EXISTING_OPERATION_REQUIRES_INSPECTION')
    state = json.loads((SOAK / 'observation/checkpoint.json').read_text())
    require(state.get('status') == 'RUNNING' and state.get('runner_pid') == identity['pid']
            and state.get('code_sha256') == SOURCE and state.get('failures') == [], 'RUNNING_STATE_MISMATCH')
    manifest = json.loads((SOAK / 'source-input-manifest.json').read_text())
    for name, expected in (manifest['source_input_sha256'] | manifest['reviewed_candidate_files']).items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'INVALID_INPUT_PATH')
        require(digest(ROOT / name) == expected, 'SOURCE_INPUT_CHANGED')
    require(digest(ROOT / 'models/qwen2.5-1.5b-instruct-q4_k_m.gguf') == MODEL, 'MODEL_CHANGED')
    require(matches(identity), 'RUNNER_EXITED_DURING_PREFLIGHT')
    return identity, env


def observe():
    _, _, identity, env = checked_bindings()
    from process_identity import capture, context_status, matches
    require(not TERMINAL.exists(), 'TERMINAL_ARTIFACT_ALREADY_PRESENT')
    require(matches(identity), 'RUNNER_ALREADY_EXITED_OR_REUSED')
    fd = os.pidfd_open(identity['pid'])
    try:
        # Refuse a process which exited or was replaced while pidfd_open raced.
        require(matches(identity), 'RUNNER_CHANGED_DURING_PIDFD_OPEN')
        state = json.loads((SOAK / 'observation/checkpoint.json').read_text())
        elapsed = state.get('current_window_seconds')
        require(state.get('status') == 'RUNNING' and state.get('runner_pid') == identity['pid']
                and state.get('code_sha256') == SOURCE and state.get('failures') == [], 'CHECKPOINT_NOT_RUNNING')
        require(type(elapsed) in (int, float) and math.isfinite(elapsed) and 0 <= elapsed < 86400,
                'INVALID_REMAINING_DURATION')
        # Grace bounds this observer only; the immutable auditor still needs >=86400s.
        timeout_seconds = 86400 - elapsed + 900
        require(0 < timeout_seconds <= 87300, 'UNBOUNDED_WAIT_REFUSED')
        observer = capture(os.getpid())
        save('observer-start.json', {
            'status': 'WAITING_FOR_BOUND_RUNNER_EXIT', 'at': now(), 'run_id': RUN_ID,
            'observer_identity': observer, 'runner_identity': identity,
            'checkpoint_seconds': elapsed, 'maximum_wait_seconds': timeout_seconds,
            'observer_sha256': digest(Path(__file__)),
            'plan_sha256': digest(WORK / 'observer-plan.json'),
            'acceptance_credit': False, 'signals_or_cleanup_permitted': False,
        })
        poller = select.poll()
        poller.register(fd, select.POLLIN)
        wait_started = time.monotonic()
        events = poller.poll(math.ceil(timeout_seconds * 1000))
        waited = time.monotonic() - wait_started
        require(bool(events), 'OBSERVER_TIMEOUT_NO_ACCEPTANCE')
        require(len(events) == 1 and events[0][0] == fd
                and bool(events[0][1] & (select.POLLIN | select.POLLHUP))
                and not events[0][1] & (select.POLLNVAL | select.POLLERR), 'INVALID_PIDFD_EVENT')
        require(context_status(BOOT, NAMESPACE) == 'MATCH', 'NATIVE_CONTEXT_CHANGED')
        require(not matches(identity), 'BOUND_RUNNER_STILL_LIVE')
        checked_bindings()
        require(not TERMINAL.exists(), 'TERMINAL_ARTIFACT_ALREADY_PRESENT')
        argv = [str(ROOT / '.venv/bin/python'), '-B', str(SOAK / 'audit_terminal.py')]
        save('auditor-start.json', {'at': now(), 'run_id': RUN_ID,
                                  'argv': argv, 'waited_seconds': waited,
                                  'auditor_sha256': HELPERS['audit_terminal.py'],
                                  'maximum_auditor_seconds': 300})
        with (WORK / 'auditor-output.log').open('x') as log:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT)
            save('auditor-execution.json', {'at': now(), 'identity': capture(child.pid),
                                           'argv': argv, 'maximum_seconds': 300})
            try:
                exit_code = child.wait(timeout=300)
            except subprocess.TimeoutExpired:
                # Do not signal even this audit. Preserve its exact child receipt for inspection.
                raise Refusal('AUDITOR_TIMEOUT_INSPECT_SAVED_CHILD_NO_RETRY') from None
        require(exit_code == 0, 'TERMINAL_AUDITOR_REJECTED_' + str(exit_code))
        require(TERMINAL.is_file(), 'VERIFIED_TERMINAL_ARTIFACT_MISSING')
        review = json.loads(TERMINAL.read_text())
        duration = review.get('continuous_seconds')
        require(review.get('status') == 'PASS_24H_VERIFIED' and review.get('run_id') == RUN_ID
                and review.get('source_fingerprint') == SOURCE
                and review.get('model', {}).get('sha256') == MODEL
                and type(duration) in (int, float) and math.isfinite(duration) and duration >= 86400,
                'VERIFIED_TERMINAL_BINDING_MISMATCH')
        save('observer-result.json', {'at': now(), 'status': 'EXISTING_TERMINAL_AUDITOR_VERIFIED',
             'run_id': RUN_ID, 'auditor_exit_code': exit_code,
             'terminal_review': str(TERMINAL.relative_to(ROOT)),
             'terminal_review_sha256': digest(TERMINAL), 'continuous_seconds': duration,
             'goal_status_changed': False, 'cleanup_executed': False})
        return 0
    finally:
        os.close(fd)


if __name__ == '__main__':
    try:
        if sys.argv[1:] == ['--preflight']:
            preflight()
            print(json.dumps({'status': 'OBSERVER_PREFLIGHT_PASS_NOT_STARTED', 'run_id': RUN_ID}))
            raise SystemExit(0)
        require(sys.argv[1:] == ['--observe-once'], 'EXPLICIT_MODE_REQUIRED')
        raise SystemExit(observe())
    except (Refusal, OSError, ValueError, KeyError, TypeError) as exc:
        reason = str(exc) if isinstance(exc, Refusal) else type(exc).__name__
        result = {'at': now(), 'status': 'OBSERVER_NOT_ACCEPTED', 'run_id': RUN_ID,
                  'reason': reason, 'goal_status_changed': False, 'cleanup_executed': False}
        if sys.argv[1:] == ['--observe-once']:
            save('observer-result.json', result)
        print(json.dumps(result))
        raise SystemExit(1)
