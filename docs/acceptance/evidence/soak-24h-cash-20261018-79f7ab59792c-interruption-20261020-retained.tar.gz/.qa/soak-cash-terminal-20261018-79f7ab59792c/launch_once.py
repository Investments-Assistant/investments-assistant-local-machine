"""Attach exactly one finite terminal observer; no scheduler or service setup."""
import json
import os
import subprocess
import sys
from pathlib import Path

from observer import ROOT, WORK, RUN_ID, digest, now, preflight, require, save


def launch():
    require(sys.argv[1:] == ['--launch-reviewed'], 'EXPLICIT_REVIEWED_MODE_REQUIRED')
    identity, env = preflight()
    save('launch-claim.json', {'at': now(), 'run_id': RUN_ID,
                             'launcher_sha256': digest(Path(__file__)),
                             'runner_identity': identity, 'acceptance_credit': False})
    from process_identity import capture
    argv = [str(ROOT / '.venv/bin/python'), '-B', str(WORK / 'observer.py'), '--observe-once']
    with (WORK / 'observer-output.log').open('x') as log:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        # Persist before returning to Codex. The child writes its independent start receipt.
        save('launch-execution.json', {'at': now(), 'status': 'OBSERVER_LAUNCHED_ONCE',
             'run_id': RUN_ID, 'argv': argv, 'observer_identity': capture(child.pid),
             'launcher_identity': capture(os.getpid()),
             'observer_sha256': digest(WORK / 'observer.py'),
             'plan_sha256': digest(WORK / 'observer-plan.json'),
             'no_runner_signal_restart_or_cleanup': True, 'acceptance_credit': False})
    print(json.dumps({'status': 'OBSERVER_LAUNCHED_ONCE', 'pid': child.pid, 'run_id': RUN_ID}))


if __name__ == '__main__':
    launch()
