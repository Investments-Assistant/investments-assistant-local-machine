"""Retain one already-verified terminal soak; never wait, audit, signal or clean.

Only explicit hashed source/evidence paths enter the archive. Existing reports,
runner/observer files, PostgreSQL, model files and Goal state remain unchanged.
"""
from datetime import UTC, datetime
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tarfile

from process_identity import context_status, matches

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
PLAN_FILE = WORK / "retention-plan.json"
SOAK = ".qa/soak-cash-20261018-79f7ab59792c"
OBSERVER = ".qa/soak-cash-terminal-20261018-79f7ab59792c"
EV = "docs/acceptance/evidence/"
TERMINAL = EV + "soak-24h-cash-20261018-79f7ab59792c-terminal-review.json"
MANIFEST = SOAK + "/source-input-manifest.json"
MAPPING = EV + "cash-halt-published-bytes-reconciliation-20261018.json"
CI = EV + "cash-halt-ci-20261018.json"
AUDITOR_SHA = "edff62ee6e46df6f8cce304e0afd05bf276abec3649f9d762d0af4b03fcd7e03"


class Refusal(Exception):
    pass


class Pending(Refusal):
    pass


def require(condition, code):
    if not condition:
        raise Refusal(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_path(name):
    require(type(name) is str and str(PurePosixPath(name)) == name
            and not PurePosixPath(name).is_absolute() and "\\" not in name
            and not set(PurePosixPath(name).parts) & {"..", ".env", ".git", ".local-private", "pgdata", "models", "keys", ".keys"}, "UNSAFE_PATH")
    path = ROOT
    for component in PurePosixPath(name).parts:
        path = path / component
        require(not path.is_symlink(), "SYMLINK_REFUSED")
    require(path.is_relative_to(ROOT), "OUTSIDE_ROOT")
    return path


def read(name, plan):
    path = safe_path(name)
    require(path.is_file(), "EXPECTED_FILE_MISSING_" + name)
    before = path.stat()
    require(before.st_size <= plan["maximum_individual_bytes"], "INDIVIDUAL_SIZE_LIMIT")
    raw = path.read_bytes()
    after = path.stat()
    require(len(raw) == before.st_size and all(getattr(before, key) == getattr(after, key)
            for key in ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")), "INPUT_CHANGED_DURING_READ")
    return raw


def save(name, value):
    with (WORK / name).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def snapshot():
    plan_raw = PLAN_FILE.read_bytes()
    plan = json.loads(plan_raw)
    require(WORK.name == "soak-cash-retention-20261018-79f7ab59792c", "OWNED_WORK_PATH_MISMATCH")
    require((plan["run_id"], plan["source"], plan["model"], plan["published_head"], plan["candidate_patch"], plan["boot_id"], plan["namespace"])
            == ("79f7ab59792c", "4fd1380c5c1595bfb8bbd311f02ec561fc013eac5f7da9563dc5c025151d1d30",
                "6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e",
                "e154a0a365ece2a9fd81657034139c43c8e0abe6", "cfd2612f17d4cf7c41c507fdf0e1178c3b579e132095509b72cc28f3a58871b2",
                "8e2a4ea6-7359-453d-8da4-23627cd94395", "pid:[4026532221]"), "EXACT_RUN_PLAN_BINDING_CHANGED")
    require(plan["maximum_individual_bytes"] == 64 * 1024 * 1024
            and plan["maximum_snapshot_bytes"] == 128 * 1024 * 1024, "SIZE_BUDGET_CHANGED")
    require(plan["runner_identity"]["pid"] == 333647 and plan["runner_identity"]["start_ticks"] == 5593877
            and plan["observer_identity"]["pid"] == 668060 and plan["observer_identity"]["start_ticks"] == 13397958,
            "BOUND_PROCESS_IDENTITY_CHANGED")
    for key, command in (("runner_identity", "191e080c92b7df9ea52783273868f9aebcaccb405b6ce27c4377c9dc29916dca"),
                         ("observer_identity", "62f28a15a3f03cff2824a9a87cf4dd5b88ab5576833056d81eef6597556bec71")):
        require(plan[key]["boot_id"] == plan["boot_id"] and plan[key]["pid_namespace"] == plan["namespace"]
                and plan[key]["command_sha256"] == command, "EXACT_BOUND_PROCESS_RECORD_CHANGED")
    require(context_status(plan["boot_id"], plan["namespace"]) == "MATCH", "NATIVE_SAME_BOOT_NAMESPACE_REQUIRED")
    for name, expected in plan["helper_sha256"].items():
        require(sha((WORK / name).read_bytes()) == expected, "RETENTION_HELPER_CHANGED")
    live = [name for name in ("runner_identity", "observer_identity") if matches(plan[name])]
    if live:
        raise Pending("BOUND_PROCESSES_STILL_LIVE_" + "_".join(live))
    if not safe_path(TERMINAL).exists() or not safe_path(OBSERVER + "/observer-result.json").exists():
        raise Pending("VERIFIED_TERMINAL_AND_OBSERVER_RESULT_REQUIRED")
    for name in ("retention-claim.json", "retention-start.json", "retention-result.json"):
        require(not (WORK / name).exists(), "EXISTING_RETENTION_REQUIRES_INSPECTION_NO_RETRY")
    expected_outputs = {"archive": EV + "soak-24h-cash-20261018-79f7ab59792c-retained.tar.gz",
                        "manifest": EV + "soak-24h-cash-20261018-79f7ab59792c-retention-manifest.json"}
    require(plan["outputs"] == expected_outputs, "OUTPUT_PATHS_CHANGED")
    require(not any(safe_path(name).exists() for name in expected_outputs.values()), "EXISTING_OUTPUT_MUST_BE_PRESERVED")
    data = {}

    def add(name, expected=None):
        if name not in data:
            data[name] = read(name, plan)
        if expected is not None:
            require(sha(data[name]) == expected, "HASH_MISMATCH_" + name)
        require(sum(map(len, data.values())) <= plan["maximum_snapshot_bytes"], "TOTAL_SIZE_LIMIT")
        return data[name]

    review_raw = add(TERMINAL)
    review = json.loads(review_raw)
    duration = review.get("continuous_seconds")
    require(review.get("status") == "PASS_24H_VERIFIED" and review.get("run_id") == plan["run_id"]
            and review.get("source_fingerprint") == plan["source"] and review.get("model", {}).get("sha256") == plan["model"]
            and type(duration) in (int, float) and math.isfinite(duration) and duration >= 86400, "VERIFIED_TERMINAL_BINDING_MISMATCH")
    require(review.get("kernel_boot_id_verified") == plan["boot_id"]
            and review.get("native_pid_namespace_verified") == plan["namespace"]
            and review.get("runner_start_ticks") == plan["runner_identity"]["start_ticks"], "TERMINAL_NATIVE_IDENTITY_MISMATCH")
    observer_result = json.loads(add(OBSERVER + "/observer-result.json"))
    require(observer_result.get("status") == "EXISTING_TERMINAL_AUDITOR_VERIFIED"
            and observer_result.get("run_id") == plan["run_id"] and observer_result.get("auditor_exit_code") == 0
            and observer_result.get("terminal_review") == TERMINAL
            and observer_result.get("terminal_review_sha256") == sha(review_raw)
            and observer_result.get("continuous_seconds") == duration, "OBSERVER_RESULT_MISMATCH")
    for name, expected in plan["pinned_files_sha256"].items():
        add(name, expected)
    state = json.loads(add(SOAK + "/observation/checkpoint.json"))
    require(state.get("status") == "PASS_24H" and state.get("runner_pid") is None
            and state.get("service_pid") is None and state.get("failures") == [], "RUNNER_NOT_TERMINAL_PASS")
    fixed = {SOAK + "/observation/checkpoint.json", EV + "soak-24h-cash-20261018-79f7ab59792c-launch.json",
             MANIFEST, EV + "cash-halt-publication-review-20261018.patch", SOAK + "/sitecustomize.py",
             SOAK + "/launch.py", SOAK + "/process_identity.py", SOAK + "/isolation-check.log",
             SOAK + "/observation/latency-samples.jsonl", EV + "soak-24h-cash-20261018-79f7ab59792c-launch.log",
             SOAK + "/audit_terminal.py"}
    model_rows = state.get("model_runs", [])
    require(len(model_rows) == 24, "EXPECTED_MODEL_ARTIFACT_COUNT")
    for index, row in enumerate(model_rows):
        name = row["path"]
        require(re.fullmatch(f"model-{index:04d}-[0-9a-f]{{8}}\\.json", name) is not None, "MODEL_ARTIFACT_PATH_REFUSED")
        fixed.add(SOAK + "/observation/" + name)
    require(set(review["artifact_sha256"]) == fixed, "TERMINAL_ARTIFACT_ALLOWLIST_MISMATCH")
    require(review["artifact_sha256"][SOAK + "/audit_terminal.py"] == AUDITOR_SHA, "IMMUTABLE_AUDITOR_MISMATCH")
    for name, expected in review["artifact_sha256"].items():
        add(name, expected)
    manifest = json.loads(data[MANIFEST])
    sources, candidate = manifest["source_input_sha256"], manifest["reviewed_candidate_files"]
    require(len(sources) == 156 and len(candidate) == 7 and len(sources | candidate) == 160
            and sorted(sources | candidate) == plan["source_paths"], "SOURCE_ALLOWLIST_MISMATCH")
    digest = hashlib.sha256()
    for name in sorted(sources):
        raw = add(name, sources[name])
        digest.update(name.encode())
        digest.update(raw)
    require(digest.hexdigest() == plan["source"], "INDEPENDENT_SOURCE_FINGERPRINT_MISMATCH")
    for name, expected in candidate.items():
        add(name, expected)
    mapping, ci = json.loads(data[MAPPING]), json.loads(data[CI])
    require(mapping.get("reconciled_commit") == plan["published_head"]
            and mapping.get("approved_patch_sha256") == plan["candidate_patch"]
            and mapping.get("exact_commit_diff_equals_approved_patch") is True
            and mapping.get("files_sha256") == candidate
            and mapping.get("source", {}).get("fingerprint") == plan["source"]
            and mapping["source"].get("commit_and_current_files_match_frozen_manifest") is True, "PUBLISHED_BYTES_MAPPING_MISMATCH")
    require(ci.get("head") == plan["published_head"] and ci.get("run_id") == 39083730719 and ci.get("workflow_conclusion") == "success"
            and len(ci.get("jobs", [])) == 4 and all(row.get("conclusion") == "success" for row in ci["jobs"])
            and ci.get("sonar", {}).get("scm_revision") == plan["published_head"]
            and ci["sonar"].get("project_key") == "Investments-Assistant_investments-assistant"
            and ci["sonar"].get("exact_report_quality_gate") == "PASSED", "EXACT_PUBLISHED_CI_PROOF_MISMATCH")
    for name in ("auditor-start.json", "auditor-execution.json", "auditor-output.log", "observer-output.log"):
        add(OBSERVER + "/" + name)
    require(not matches(plan["runner_identity"]) and not matches(plan["observer_identity"]), "BOUND_PROCESS_REAPPEARED")
    require(PLAN_FILE.read_bytes() == plan_raw, "RETENTION_PLAN_CHANGED_DURING_SNAPSHOT")
    plan["verified_retention_plan_sha256"] = sha(plan_raw)
    return plan, data, review


def retain(plan, data, review):
    claim = {"at": datetime.now(UTC).isoformat(), "status": "CLAIMED_NO_AUTOMATIC_RETRY",
             "run_id": plan["run_id"], "plan_sha256": sha(PLAN_FILE.read_bytes()), "helper_sha256": sha(Path(__file__).read_bytes())}
    save("retention-claim.json", claim)
    try:
        save("retention-start.json", {**claim, "status": "ARCHIVE_CREATION_STARTING", "files": len(data),
                                      "snapshot_bytes": sum(map(len, data.values()))})
        archive = safe_path(plan["outputs"]["archive"])
        with archive.open("xb") as output:
            with gzip.GzipFile(fileobj=output, mode="wb", mtime=0) as compressed:
                with tarfile.open(fileobj=compressed, mode="w") as bundle:
                    for name, raw in sorted(data.items()):
                        info = tarfile.TarInfo(name)
                        info.size, info.mode = len(raw), 0o600
                        bundle.addfile(info, io.BytesIO(raw))
            output.flush()
            os.fsync(output.fileno())
        require(archive.stat().st_size <= plan["maximum_individual_bytes"], "ARCHIVE_SIZE_LIMIT")
        with tarfile.open(archive, "r:gz") as bundle:
            members = bundle.getmembers()
            require(len(members) == len(data) and {item.name for item in members} == set(data), "ARCHIVE_MEMBER_SET_MISMATCH")
            for item in members:
                require(item.isfile() and not item.linkname and item.size == len(data[item.name])
                        and bundle.extractfile(item).read() == data[item.name], "ARCHIVE_ROUND_TRIP_MISMATCH")
        require(all(read(name, plan) == raw for name, raw in data.items()), "ORIGINAL_INPUT_CHANGED_DURING_RETENTION")
        require(sha(PLAN_FILE.read_bytes()) == plan["verified_retention_plan_sha256"], "RETENTION_PLAN_CHANGED")
        result = {"status": "VERIFIED_TERMINAL_RAW_AND_SOURCE_RETAINED", "at": datetime.now(UTC).isoformat(),
                  "run_id": plan["run_id"], "source_fingerprint": plan["source"], "model_sha256": plan["model"],
                  "candidate_patch_sha256": plan["candidate_patch"], "published_head": plan["published_head"],
                  "ci_run_id": json.loads(data[CI])["run_id"], "continuous_seconds": review["continuous_seconds"],
                  "terminal_review_sha256": sha(data[TERMINAL]), "archive": plan["outputs"]["archive"],
                  "archive_sha256": sha(archive.read_bytes()), "archive_bytes": archive.stat().st_size,
                  "members": len(data), "snapshot_bytes": sum(map(len, data.values())),
                  "source_inputs": 156, "candidate_files": 7, "unique_source_candidate_paths": 160,
                  "archive_member_sha256": {name: sha(raw) for name, raw in sorted(data.items())},
                  "round_trip_all_bytes_verified": True, "original_inputs_unchanged": True,
                  "plan_sha256": sha(PLAN_FILE.read_bytes()), "helper_sha256": sha(Path(__file__).read_bytes()),
                  "limitations": ["Only the existing exact terminal auditor establishes24h acceptance; retention adds none.",
                                  "No GGUFbinary, PostgreSQLdump, private files or arbitrary directorycontents included.",
                                  "Published mapping/CI reports retained with pinned hashes; their separately linked remote raw artifacts remain in original QA paths.",
                                  "Original raw wall/restart limitations remain in the terminal review; no thermal, Paper, economic or production-inference claim.",
                                  "No process, cleanup, Goal state or progress percentage changed."]}
        public = safe_path(plan["outputs"]["manifest"])
        raw = (json.dumps(result, indent=2) + "\n").encode()
        require(len(raw) <= plan["maximum_individual_bytes"], "MANIFEST_SIZE_LIMIT")
        with public.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        save("retention-result.json", {"status": result["status"], "manifest": plan["outputs"]["manifest"],
                                      "manifest_sha256": sha(raw), "archive_sha256": result["archive_sha256"], "members": len(data)})
        print(json.dumps({key: result[key] for key in ("status", "archive", "archive_sha256", "members", "snapshot_bytes")}))
    except BaseException as exc:
        save("retention-result.json", {"status": "RETENTION_NOT_ACCEPTED_PRESERVE_PARTIAL_OUTPUTS",
                                      "at": datetime.now(UTC).isoformat(), "reason": str(exc) if isinstance(exc, Refusal) else type(exc).__name__,
                                      "no_retry_cleanup_or_signals": True})
        raise


if __name__ == "__main__":
    try:
        require(sys.argv[1:] in (["--preflight"], ["--retain-reviewed"]), "EXPLICIT_MODE_REQUIRED")
        plan, data, review = snapshot()
        if sys.argv[1:] == ["--preflight"]:
            print(json.dumps({"status": "RETENTION_READY_NOT_EXECUTED", "members": len(data), "bytes": sum(map(len, data.values()))}))
        else:
            retain(plan, data, review)
    except (Refusal, OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "RETENTION_PENDING" if isinstance(exc, Pending) else "RETENTION_NOT_ACCEPTED",
                          "reason": str(exc) if isinstance(exc, Refusal) else type(exc).__name__}))
        raise SystemExit(2 if isinstance(exc, Pending) else 1)
