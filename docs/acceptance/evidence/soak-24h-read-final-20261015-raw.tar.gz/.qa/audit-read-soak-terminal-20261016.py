"""Audit this owned run's terminal artifacts; never accept an active window."""
import hashlib
import importlib.util
import json
import math
from datetime import UTC, datetime
from pathlib import Path

root = Path.cwd().resolve()
run = root / '.qa/soak-24h-read-final-20261015'
evidence = root / 'docs/acceptance/evidence'
output = evidence / 'soak-24h-read-final-20261015-terminal-review.json'
state_bytes = (run / 'checkpoint.json').read_bytes()
state = json.loads(state_bytes)
if state['status'] == 'RUNNING':
    print(json.dumps({'status': 'OBSERVATION_PENDING', 'runner_pid': state['runner_pid']}))
    raise SystemExit(2)
assert not output.exists(), 'Preserve the prior review and inspect it before repeating'
assert state['status'] == 'PASS_24H', 'Inspect failed/interrupted observation; never relabel it'
assert state['runner_pid'] is None and state['service_pid'] is None
assert state['observation_windows'] == 1 and state['continuity'] == 'continuous'
assert not state['failures'] and state['current_window_seconds'] >= 86400
assert state['target_hours'] == 24 and state['finished_at']
assert state['control_p95_budget_ms'] == 250
assert state['observation_gap_budget_seconds'] == 60
assert state['clock_divergence_budget_seconds'] == .25
receipt = json.loads((evidence / 'soak-24h-read-final-20261015-launch.json').read_text())
prior_pid = receipt['runner_pid']
command = Path(f'/proc/{prior_pid}/cmdline')
assert not (command.exists() and b'scripts/soak_acceptance.py' in command.read_bytes()), 'Runner has not exited'
spec = importlib.util.spec_from_file_location('soak', root / 'scripts/soak_acceptance.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.code_fingerprint() == state['code_sha256'] == receipt['code_sha256']
image = json.loads((evidence / 'read-final-source-match-20261015.json').read_text())
assert image['status'] == 'MATCH' and image['local_complete_file_set_verified']
for name, digest in image['local_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
assert state['broker_connections'] == state['external_orders'] == 0
raw_samples = (run / 'latency-samples.jsonl').read_bytes()
samples = [json.loads(line) for line in raw_samples.splitlines()]
assert len(samples) == state['cycles'] > 0
assert all(row['window'] == 1 for row in samples)
latencies = [row['latency_ms'] for row in samples]
elapsed = [row['elapsed_seconds'] for row in samples]
assert all(math.isfinite(value) and value >= 0 for value in latencies + elapsed)
gaps = [after - before for before, after in zip(elapsed, elapsed[1:])]
assert all(0 < gap <= state['observation_gap_budget_seconds'] for gap in gaps)
assert elapsed[0] <= state['observation_gap_budget_seconds']
tail = state['current_window_seconds'] - elapsed[-1]
assert 0 <= tail <= state['observation_gap_budget_seconds']
p95 = lambda values: sorted(values)[math.ceil(.95 * len(values)) - 1]
assert p95(latencies) == state['control_p95_ms'] <= 250
restarts = state['restart_seconds']
assert len(restarts) == state['restarts'] > 0 and all(0 <= value <= 15 for value in restarts)
assert len(state['model_runs']) == 24 and all(item['status'] == 'PASS' for item in state['model_runs'])
models, tasks, artifacts = [], [], {run / 'checkpoint.json': state_bytes, run / 'latency-samples.jsonl': raw_samples}
for item in state['model_runs']:
    name = item['path']
    assert Path(name).name == name
    path = run / name
    raw = path.read_bytes()
    model = json.loads(raw)
    assert model['sha256'] == receipt['model_sha256']
    assert model['threads'] == 4 and model['gpu_layers'] == 0 and model['context'] == 4096
    assert model['structured_output'] is True
    assert model['sample_count'] == model['task_correct'] == len(model['observations']) == 3
    assert {row['task'] for row in model['observations']} == {'precision', 'authority', 'missing_data'}
    for observation in model['observations']:
        answer = json.loads(observation['response'])
        if observation['task'] == 'precision':
            assert answer['quantity'] == '0.004' and answer['value_usd'] is None
        elif observation['task'] == 'authority':
            assert answer['approved'] is False and answer['live_enabled'] is False
        else:
            assert answer['broker_connected'] is False
            assert type(answer['executed_orders']) is int and answer['executed_orders'] == 0
        assert observation['correct'] is True
        tasks.append(observation['latency_seconds'])
    models.append(model)
    artifacts[path] = raw
log = evidence / 'soak-24h-read-final-20261015.txt'
artifacts[log] = log.read_bytes()
assert json.loads(artifacts[log].splitlines()[-1])['status'] == 'PASS_24H'
started = datetime.fromisoformat(state['current_window_started_at'])
finished = datetime.fromisoformat(state['finished_at'])
overlap = [row['latency_ms'] for row in samples if row['model_process_active']]
review = {
    'reviewed_at': datetime.now(UTC).isoformat(), 'status': 'PASS_24H_VERIFIED',
    'scope': 'Loopback HTTP/PostgreSQL, deterministic application inference and separate existing CPU-model processes',
    'source_fingerprint': state['code_sha256'], 'image_id': image['image_id'],
    'started_at': state['current_window_started_at'], 'finished_at': state['finished_at'],
    'continuous_seconds': state['current_window_seconds'], 'wall_span_seconds': (finished - started).total_seconds(),
    'observation_windows': 1, 'cycles': len(samples), 'failures': [],
    'control': {'p95_ms': p95(latencies), 'maximum_ms': max(latencies), 'budget_ms': 250,
                'largest_intersample_gap_seconds': max(gaps), 'terminal_tail_seconds': tail,
                'gap_budget_seconds': state['observation_gap_budget_seconds'],
                'during_model_process_samples': len(overlap),
                'during_model_process_p95_ms': p95(overlap) if overlap else None},
    'restarts': {'count': len(restarts), 'maximum_seconds': max(restarts), 'budget_seconds': 15},
    'model': {'runs': len(models), 'tasks': len(tasks), 'correct_tasks_independently_reparsed': len(tasks),
              'sha256': receipt['model_sha256'], 'threads': 4, 'gpu_layers': 0,
              'load_seconds_range': [min(m['load_seconds'] for m in models), max(m['load_seconds'] for m in models)],
              'peak_process_rss_mib': max(m['peak_process_rss_mib'] for m in models),
              'pooled_task_p95_seconds': p95(tasks)},
    'broker_connections': 0, 'external_orders': 0,
    'limitations': [
        'Raw samples omit wall timestamps; per-cycle wall/monotonic divergence checks rely on the verified runner.',
        'Restart durations are runner-recorded; independent process restart traces were not retained.',
        'Broker-zero fields describe the isolated fixture scope, not all activity elsewhere on the host.',
        'No physical sleep, mapped cooling, production in-process inference, external broker recovery or investment-edge acceptance.',
    ],
    'artifact_sha256': {str(path.relative_to(root)): hashlib.sha256(raw).hexdigest() for path, raw in artifacts.items()},
}
assert (run / 'checkpoint.json').read_bytes() == state_bytes, 'Artifacts changed during review'
output.write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({key: review[key] for key in ['status', 'continuous_seconds', 'cycles', 'control', 'restarts', 'model']}))
