"""Synthetic subprocess isolation: no dotenv or operator-private file reads."""
import os
import sys

from pydantic_settings import BaseSettings

_original_init = BaseSettings.__init__


def _without_dotenv(self, *args, **kwargs):
    kwargs["_env_file"] = None
    return _original_init(self, *args, **kwargs)


BaseSettings.__init__ = _without_dotenv


def _deny_private_files(event, arguments):
    if event != "open" or not arguments:
        return
    path = arguments[0]
    if not isinstance(path, (str, bytes, os.PathLike)):
        return
    path = os.fsdecode(path)
    if os.path.basename(path) == ".env" or "/.local-private/" in path:
        raise PermissionError("SOAK_OPERATOR_PRIVATE_FILE_READ_FORBIDDEN")


sys.addaudithook(_deny_private_files)

# Only the owned runner gets tracing; its Uvicorn/model subprocesses retain the
# dotenv isolation above without HTTP instrumentation. Never retain bodies,
# headers, query strings, cookies, usernames or account identifiers.
if os.environ.get("SOAK_HTTP_TRACE_PATH") and os.path.basename(sys.argv[0]) == "soak_acceptance.py":
    import json
    from pathlib import Path
    import re
    import time

    import httpx

    _trace_path = Path(os.environ["SOAK_HTTP_TRACE_PATH"])
    if _trace_path.parent.resolve() != Path(__file__).resolve().parent or _trace_path.name != "http-route-trace.jsonl":
        raise RuntimeError("OWNED_HTTP_TRACE_PATH_REQUIRED")
    _trace_sequence = 0
    _original_client_init = httpx.Client.__init__

    def _route_only_response(response):
        global _trace_sequence
        request = response.request
        if request.url.host != "127.0.0.1":
            return
        _trace_sequence += 1
        route = re.sub(r"(/api/simulator/accounts/)[^/]+", r"\1{account}", request.url.path)
        row = {"sequence": _trace_sequence, "pid": os.getpid(), "monotonic": time.monotonic(),
               "method": request.method, "route": route, "port": request.url.port,
               "status": response.status_code}
        with _trace_path.open("a") as stream:
            stream.write(json.dumps(row) + "\n")

    def _traced_client_init(self, *args, **kwargs):
        hooks = {key: list(values) for key, values in (kwargs.get("event_hooks") or {}).items()}
        hooks.setdefault("response", []).append(_route_only_response)
        kwargs["event_hooks"] = hooks
        return _original_client_init(self, *args, **kwargs)

    httpx.Client.__init__ = _traced_client_init
