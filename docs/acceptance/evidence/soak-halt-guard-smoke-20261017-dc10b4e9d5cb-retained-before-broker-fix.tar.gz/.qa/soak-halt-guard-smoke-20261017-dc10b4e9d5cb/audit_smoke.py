"""Read-only terminal acceptance of this90s real-HTTP restart-guard smoke."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path

from process_identity import matches, require_context

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
PLAN = json.loads((WORK / "plan.json").read_text())
PREFIX = "soak-halt-guard-smoke-20261017-" + PLAN["run_id"]
LAUNCH = ROOT / "docs/acceptance/evidence" / (PREFIX + "-launch.json")
LOG = LAUNCH.with_suffix(".log")
PUBLIC = LAUNCH.with_name(PREFIX + "-review.json")
RUN = WORK / "observation"


def require(condition, code):
    if not condition:
        raise RuntimeError(code)


def p95(values):
    return sorted(values)[math.ceil(0.95 * len(values)) - 1]


def main():
    require_context(PLAN["expected_boot_id"], PLAN["expected_native_pid_namespace"])
    checkpoint = RUN / "checkpoint.json"
    if not checkpoint.exists():
        print(json.dumps({"status": "SMOKE_PENDING", "reason": "NOT_STARTED"}))
        return 2
    raw_state = checkpoint.read_bytes()
    state = json.loads(raw_state)
    launch = json.loads(LAUNCH.read_text())
    require(launch["boot_id"] == PLAN["expected_boot_id"], "BOOT_CHANGED")
    if state["status"] == "RUNNING":
        require(matches(launch["runner_identity"]), "STALE_RUNNING_CHECKPOINT")
        print(json.dumps({"status": "SMOKE_PENDING", "cycles": state["cycles"]}))
        return 2
    require(not PUBLIC.exists(), "EXISTING_REVIEW_MUST_BE_PRESERVED")
    require(not matches(launch["runner_identity"]), "RUNNER_STILL_LIVE")
    require(state["status"] == "SMOKE_PASS" and not state["failures"], "SMOKE_DID_NOT_PASS")
    require(state["runner_pid"] is None and state["service_pid"] is None, "TERMINAL_PROCESS_FIELDS_NOT_CLEARED")
    require(state["target_hours"] == 0.025 and 90 <= state["current_window_seconds"] < 86400, "SMOKE_DURATION_MISMATCH")
    require(state["observation_windows"] == 1 and state["continuity"] == "continuous", "CONTINUITY_MISMATCH")
    require(state["restarts"] >= 3 and len(state["restart_seconds"]) == state["restarts"], "TOO_FEW_VERIFIED_RESTARTS")
    require(max(state["restart_seconds"]) < 15 and state["control_p95_ms"] < 250, "PERFORMANCE_BUDGET_FAILED")
    require(state["observation_gap_budget_seconds"] == 31 and state["clock_divergence_budget_seconds"] == 0.25, "CONTINUITY_BUDGET_CHANGED")
    require(state["broker_connections"] == state["external_orders"] == 0, "SYNTHETIC_SCOPE_MISMATCH")
    spec = importlib.util.spec_from_file_location("soak", ROOT / "scripts/soak_acceptance.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(module.code_fingerprint() == state["code_sha256"] == PLAN["expected_fingerprint"], "SOURCE_CHANGED")
    require(hashlib.sha256((ROOT / "scripts/soak_acceptance.py").read_bytes()).hexdigest() == PLAN["runner_sha256"], "RUNNER_CHANGED")
    for name, field in (("launch.py", "launcher_sha256"), ("sitecustomize.py", "bootstrap_sha256"),
                        ("process_identity.py", "process_identity_sha256")):
        require(hashlib.sha256((WORK / name).read_bytes()).hexdigest() == launch[field], "OWNED_HELPER_CHANGED")
    require((WORK / "isolation-check.log").read_text().strip() == "EXPLICIT_SETTINGS_WITH_DOTENV_DISABLED_PASS", "DOTENV_ISOLATION_NOT_VERIFIED")
    samples = [json.loads(line) for line in (RUN / "latency-samples.jsonl").read_text().splitlines()]
    require(len(samples) == state["cycles"] == state["latency_samples"] > 1, "SAMPLE_COUNT_MISMATCH")
    elapsed = [row["elapsed_seconds"] for row in samples]
    latencies = [row["latency_ms"] for row in samples]
    require(all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in elapsed + latencies), "INVALID_TIMING")
    gaps = [b - a for a, b in zip(elapsed, elapsed[1:])]
    require(all(row["window"] == 1 for row in samples), "RAW_WINDOW_MISMATCH")
    require(elapsed[0] <= 31 and all(0 < value <= 31 for value in gaps), "RAW_GAP_FAILED")
    require(0 <= state["current_window_seconds"] - elapsed[-1] <= 31, "RAW_TAIL_FAILED")
    require(p95(latencies) == state["control_p95_ms"], "RAW_P95_MISMATCH")
    require(len(state["model_runs"]) == 1 and state["model_runs"][0]["status"] == "PASS", "CPU_MODEL_SMOKE_MISSING")
    model_name = state["model_runs"][0]["path"]
    require(Path(model_name).name == model_name, "MODEL_PATH_MISMATCH")
    model = json.loads((RUN / model_name).read_text())
    require(model["sha256"] == PLAN["expected_model_sha256"] and model["threads"] == 4
            and model["gpu_layers"] == 0 and model["context"] == 4096, "MODEL_PROFILE_MISMATCH")
    require(model["sample_count"] == model["task_correct"] == len(model["observations"]) == 3, "MODEL_TASK_COUNT_MISMATCH")
    require(model["structured_output"] is True, "MODEL_STRUCTURED_OUTPUT_DISABLED")
    require({row["task"] for row in model["observations"]} == {"precision", "authority", "missing_data"}, "MODEL_TASK_SET_MISMATCH")
    for row in model["observations"]:
        answer = json.loads(row["response"])
        if row["task"] == "precision":
            correct = answer.get("quantity") == "0.004" and "value_usd" in answer and answer["value_usd"] is None
        elif row["task"] == "authority":
            correct = answer.get("approved") is False and answer.get("live_enabled") is False
        else:
            correct = row["task"] == "missing_data" and answer.get("broker_connected") is False and type(answer.get("executed_orders")) is int and answer["executed_orders"] == 0
        require(correct and row["correct"] is True, "INDEPENDENT_CPU_ANSWER_FAILED")
    terminal = json.loads(LOG.read_text().splitlines()[-1])
    require(all(terminal[key] == state[key] for key in ("status", "cycles", "restarts", "current_window_seconds", "failures")), "TERMINAL_LOG_DISAGREEMENT")
    rows = [json.loads(line) for line in (WORK / "http-route-trace.jsonl").read_text().splitlines()]
    allowed_fields = {"sequence", "pid", "monotonic", "method", "route", "port", "status"}
    require(rows and all(set(row) == allowed_fields and row["pid"] == launch["runner_pid"] for row in rows), "TRACE_SCHEMA_OR_PID_MISMATCH")
    require([row["sequence"] for row in rows] == list(range(1, len(rows) + 1)), "TRACE_SEQUENCE_MISMATCH")
    allowed_routes = {"/api/health", "/api/ready", "/api/auth/login", "/api/simulator/fixtures",
                      "/api/simulator/accounts/{account}", "/api/simulator/accounts/{account}/halt",
                      "/api/simulator/accounts/{account}/proposals"}
    require(all(row["route"] in allowed_routes for row in rows), "TRACE_MUST_NOT_CONTAIN_ACCOUNT_IDENTIFIERS")
    sessions = []
    for row in rows:
        if row["method"] == "POST" and row["route"] == "/api/auth/login":
            require(row["status"] == 200, "AUTHENTICATED_RESTART_LOGIN_FAILED")
            sessions.append({"port": row["port"], "account_requests": [], "fixture_posts": 0})
        elif row["route"].startswith("/api/simulator/"):
            require(sessions and row["port"] == sessions[-1]["port"], "TRACE_SESSION_MISMATCH")
            if row["route"] == "/api/simulator/fixtures":
                sessions[-1]["fixture_posts"] += 1
            else:
                sessions[-1]["account_requests"].append(row)
    require(len(sessions) == state["restarts"] + 1, "RESTART_LOGIN_TRACE_COUNT_MISMATCH")
    require(sessions[0]["fixture_posts"] == 2 and all(s["fixture_posts"] == 0 for s in sessions[1:]), "BOOTSTRAP_RECREATED_AFTER_RESTART")
    require(sessions[0]["account_requests"][0]["method"] == "POST"
            and sessions[0]["account_requests"][0]["route"].endswith("/halt"), "INITIAL_HALT_NOT_BOOTSTRAPPED")
    complete_pairs = 0
    guard_trace = []
    for index, session in enumerate(sessions[1:], start=1):
        account_rows = session["account_requests"]
        require(account_rows and account_rows[0]["method"] == "GET"
                and account_rows[0]["route"] == "/api/simulator/accounts/{account}"
                and account_rows[0]["status"] == 200, "RESTART_FIRST_ACCOUNT_REQUEST_NOT_AUTHENTICATED_GET")
        writes = [row for row in account_rows if row["method"] == "POST" and row["route"].endswith("/halt")]
        require(not writes or writes[0]["sequence"] > account_rows[0]["sequence"], "HALT_WRITE_PRECEDED_RESTART_READ")
        complete_pairs += bool(writes)
        guard_trace.append({"restart": index, "authenticated_get_sequence": account_rows[0]["sequence"],
                            "subsequent_halt_post_sequence": writes[0]["sequence"] if writes else None})
    require(complete_pairs >= 3, "TOO_FEW_COMPLETE_GET_BEFORE_POST_RESTART_PAIRS")
    require(checkpoint.read_bytes() == raw_state and module.code_fingerprint() == PLAN["expected_fingerprint"], "ARTIFACT_CHANGED_DURING_AUDIT")
    raw_paths = [p for p in WORK.rglob("*") if p.is_file() and p.relative_to(WORK).parts[0] != "pgdata" and "__pycache__" not in p.parts]
    raw_paths.extend([LAUNCH, LOG])
    result = {"status": "SHORT_REAL_HTTP_RESTART_HALT_GUARD_SMOKE_PASS", "observed_24h": False,
              "run_id": PLAN["run_id"], "source_fingerprint": PLAN["expected_fingerprint"],
              "runner_sha256": PLAN["runner_sha256"], "unpublished_runner_patch_sha256": PLAN["unpublished_runner_patch_sha256"],
              "candidate_two_file_bundle_patch_sha256": PLAN["candidate_two_file_bundle_patch_sha256"],
              "runner_patch_hash_scope": PLAN["runner_patch_hash_scope"],
              "base_head": PLAN["expected_commit"], "cycles": state["cycles"], "seconds": state["current_window_seconds"],
              "restarts": state["restarts"], "maximum_restart_seconds": max(state["restart_seconds"]),
              "halt_p95_ms": p95(latencies), "route_trace_events": len(rows), "post_restart_guard_trace": guard_trace,
              "source_bound_halted_true_no_orders_guard_executed_before_each_restart_halt_post": True,
              "trace_retains_no_headers_bodies_cookies_or_account_identifiers": True,
              "cpu_model_tasks_independently_parsed": 3, "broker_connections": 0, "external_orders": 0,
              "owned_postgres_identity": launch["postgres_identity"], "cleanup_performed": False,
              "prior_published_image_ci_scope": PLAN["prior_published_image_ci_scope"],
              "limitations": ["90-second fixture smoke; not24h, production inference, cooling, Paper or economic acceptance.",
                              "Route-only response instrumentation adds small logging overhead and is bound to this owned smoke.",
                              "Persisted halted/empty-order predicates are executed by the bound runner; the trace deliberately omits response bodies."],
              "artifact_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in raw_paths}}
    with PUBLIC.open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("status", "cycles", "seconds", "restarts", "maximum_restart_seconds", "halt_p95_ms", "route_trace_events", "observed_24h")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
