"""Own exactly one new synthetic PostgreSQL cluster and detached observation."""
import asyncio
import base64
from datetime import UTC, datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import time

import asyncpg
from cryptography.fernet import Fernet
from process_identity import capture, context_status, matches, require_context

WORK = Path(__file__).resolve().parent
PLAN_FILE = WORK / "plan.json"
PLAN = json.loads(PLAN_FILE.read_text())
ROOT = Path(PLAN["root"]).resolve()
SOCKET = Path(PLAN["socket"])
DATA = WORK / "pgdata"
PORT = PLAN["port"]
NAME = PLAN["database"]
PG = ROOT / ".qa/postgres-root/usr/lib/postgresql/16/bin"
OUTPUT = WORK / "observation"
PUBLIC = ROOT / ("docs/acceptance/evidence/soak-24h-credentials-20261017-" + PLAN["run_id"] + "-launch.json")
PUBLIC_LOG = PUBLIC.with_suffix(".log")
MARKER = PLAN.get("disposable_marker") or "fixture-soak-credentials-" + secrets.token_hex(24)
URL = f"postgresql+asyncpg://lulu@/{NAME}?host={SOCKET}&port={PORT}"
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "LANG": "C.UTF-8",
    "LD_LIBRARY_PATH": str(ROOT / ".qa/postgres-root/usr/lib/x86_64-linux-gnu"),
    "PGPASSFILE": str(WORK / "absent-pgpass"),
    "PGSSLMODE": "disable",
}


def save(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def run(command, log, env=BASE_ENV):
    with log.open("a") as stream:
        subprocess.run(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                       stdout=stream, stderr=subprocess.STDOUT, check=True,
                       timeout=90, start_new_session=True)


def module():
    spec = importlib.util.spec_from_file_location("owned_soak", ROOT / "scripts/soak_acceptance.py")
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


async def connect(database="postgres"):
    return await asyncpg.connect(host=str(SOCKET), port=PORT, user="lulu", database=database,
                                 timeout=5, command_timeout=5, passfile=str(WORK / "absent-pgpass"),
                                 ssl=False)


async def identity(connection):
    require_context(PLAN["expected_boot_id"], PLAN["expected_native_pid_namespace"])
    assert Path(await connection.fetchval("SHOW data_directory")).resolve() == DATA.resolve()
    assert await connection.fetchval("SHOW port") == str(PORT)
    assert await connection.fetchval("SHOW listen_addresses") == ""


async def create_database():
    connection = await connect()
    try:
        await identity(connection)
        assert not await connection.fetchval("SELECT 1 FROM pg_database WHERE datname=$1", NAME)
        await connection.execute(f'CREATE DATABASE "{NAME}"')
    finally:
        await connection.close()
    connection = await connect(NAME)
    try:
        await identity(connection)
        assert await connection.fetchval("SELECT current_database()") == NAME
        await connection.execute("CREATE TABLE public.ia_disposable_marker(token text NOT NULL)")
        await connection.execute("INSERT INTO public.ia_disposable_marker VALUES($1)", MARKER)
    finally:
        await connection.close()


def live_owned_runner(pid):
    record = PLAN.get("runner_identity")
    if not record or pid != record["pid"] or not matches(record):
        return False
    arguments = Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\0")
    return b"scripts/soak_acceptance.py" in arguments and str(OUTPUT.relative_to(ROOT)).encode() in arguments


async def cleanup_database():
    connection = await connect()
    try:
        await identity(connection)
        exists = await connection.fetchval("SELECT 1 FROM pg_database WHERE datname=$1", NAME)
        assert not await connection.fetchval(
            "SELECT count(*) FROM pg_stat_activity WHERE datname=$1", NAME)
    finally:
        await connection.close()
    if exists:
        connection = await connect(NAME)
        try:
            await identity(connection)
            assert await connection.fetchval("SELECT current_database()") == NAME
            assert await connection.fetchval("SELECT token FROM public.ia_disposable_marker") == MARKER
        finally:
            await connection.close()
        connection = await connect()
        try:
            await identity(connection)
            assert not await connection.fetchval(
                "SELECT count(*) FROM pg_stat_activity WHERE datname=$1", NAME)
            await connection.execute(f'DROP DATABASE "{NAME}"')
        finally:
            await connection.close()


def cleanup():
    require_context(PLAN["expected_boot_id"], PLAN["expected_native_pid_namespace"])
    assert WORK == Path(PLAN["work"]).resolve()
    assert WORK.parent == ROOT / ".qa" and WORK.name.endswith(PLAN["run_id"])
    assert SOCKET.parent == ROOT / ".qa" and SOCKET.name == "s-" + PLAN["run_id"][:8]
    assert not live_owned_runner(PLAN.get("runner_pid")), "OWNED_RUNNER_IS_LIVE_DO_NOT_CLEAN"
    status = subprocess.run([str(PG / "pg_ctl"), "-D", str(DATA), "status"],
                            env=BASE_ENV, capture_output=True, text=True, timeout=5)
    if status.returncode == 0:
        assert matches(PLAN.get("postgres_identity")), "OWNED_POSTGRES_IDENTITY_CHANGED_REVIEW_REQUIRED"
        asyncio.run(cleanup_database())
        run([str(PG / "pg_ctl"), "-D", str(DATA), "-m", "smart", "-w", "-t", "15", "stop"], WORK / "cleanup.log")
    else:
        assert status.returncode == 3 and not (DATA / "postmaster.pid").exists(), "SERVER_STATE_REQUIRES_INSPECTION"
    receipt = {"at": datetime.now(UTC).isoformat(), "status": "OWNED_CLUSTER_STOPPED",
               "database": NAME, "cluster": str(DATA), "drop_used_force": False,
               "operator_files_read": False, "unrelated_cluster_changes": False,
               "data_directory_preserved_for_evidence": True}
    save(WORK / "cleanup.json", receipt)
    PLAN.update(cluster_stopped=True, cleanup_verified=True)
    save(PLAN_FILE, PLAN)
    print(json.dumps(receipt), flush=True)


def preflight():
    require_context(PLAN["expected_boot_id"], PLAN["expected_native_pid_namespace"])
    assert PLAN["status"] == "PREPARED_NOT_LAUNCHED", "INSPECT_EXISTING_RUN_BEFORE_RETRY"
    assert ROOT == Path.cwd().resolve()
    assert not DATA.exists() and not SOCKET.exists() and not OUTPUT.exists()
    assert not PUBLIC.exists() and not PUBLIC_LOG.exists(), "PUBLIC_EVIDENCE_ALREADY_EXISTS"
    assert len(str(SOCKET / f".s.PGSQL.{PORT}").encode()) < 108
    live = []
    for path in Path("/proc").glob("[0-9]*/cmdline"):
        try:
            arguments = path.read_bytes().split(b"\0")
        except OSError:
            continue
        if any(value.endswith(b"/soak_acceptance.py") or value == b"scripts/soak_acceptance.py" for value in arguments):
            live.append(int(path.parent.name))
    assert not live, "ANOTHER_SOAK_IS_LIVE"
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, env=BASE_ENV, text=True).strip()
    assert head == PLAN["expected_commit"], "SOURCE_COMMIT_CHANGED_REVIEW_REQUIRED"
    assert module().code_fingerprint() == PLAN["expected_fingerprint"]
    model = ROOT / "models/qwen2.5-1.5b-instruct-q4_k_m.gguf"
    digest = hashlib.sha256()
    with model.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    assert digest.hexdigest() == PLAN["expected_model_sha256"]
    available = int(next(value.split()[1] for value in Path("/proc/meminfo").read_text().splitlines() if value.startswith("MemAvailable:")))
    assert available > 4 * 1024 * 1024
    versions = {}
    for name in ("initdb", "pg_ctl", "postgres"):
        result = subprocess.run([str(PG / name), "--version"], env=BASE_ENV, capture_output=True, text=True, timeout=5)
        assert result.returncode == 0
        versions[name] = result.stdout.strip()
    return {"status": "READY_NOT_STARTED", "at": datetime.now(UTC).isoformat(), "run_id": PLAN["run_id"],
            "head": head, "source_fingerprint": PLAN["expected_fingerprint"], "model_sha256": digest.hexdigest(),
            "boot_id": PLAN["expected_boot_id"], "native_pid_namespace": PLAN["expected_native_pid_namespace"],
            "preflight_process_identity": capture(os.getpid()), "native_active_soak_pids": live,
            "database": NAME, "socket": str(SOCKET), "port": PORT, "work": str(WORK),
            "postgres_versions": versions, "mem_available_kib": available,
            "helper_sha256": {name: hashlib.sha256((WORK / name).read_bytes()).hexdigest()
                              for name in ("launch.py", "sitecustomize.py", "process_identity.py")},
            "resource_budgets": {"target_hours": 24, "sample_interval_seconds": 30, "restart_every_seconds": 900,
                                 "model_cpu_threads": 4, "model_gpu_layers": 0, "model_context": 4096,
                                 "minimum_available_memory_gib": 4, "model_timeout_seconds": 180,
                                 "service_startup_budget_seconds": 15, "restart_strict_budget_seconds": 15,
                                 "halt_p95_strict_budget_ms": 250, "observation_gap_budget_seconds": 60,
                                 "clock_divergence_budget_seconds": 0.25},
            "old_cluster_reused": False, "postgres_tcp_listener": False,
            "requires_root_recovery_and_preflight_review_before_launch": True}


def launch():
    checked = preflight()
    head = checked["head"]
    model = ROOT / "models/qwen2.5-1.5b-instruct-q4_k_m.gguf"
    source = module()
    PLAN.update(status="PREPARING", disposable_marker=MARKER, database_url=URL,
                source_head=head, code_sha256=PLAN["expected_fingerprint"],
                created_at=datetime.now(UTC).isoformat(), runner_pid=None, cluster_stopped=False)
    save(PLAN_FILE, PLAN)
    metadata = {key: PLAN[key] for key in ("created_at", "run_id", "source_head", "code_sha256",
                                         "database", "disposable_marker", "socket", "port", "runner_pid")}
    metadata.update(status="PREPARING", output=str(OUTPUT.relative_to(ROOT)),
                    postgres_data_directory=str(DATA.relative_to(ROOT)), model_sha256=checked["model_sha256"],
                    boot_id=PLAN["expected_boot_id"], native_pid_namespace=PLAN["expected_native_pid_namespace"],
                    process_identity_sha256=hashlib.sha256((WORK / "process_identity.py").read_bytes()).hexdigest(),
                    scope="New marked native PostgreSQL/loopback HTTP; synthetic app inference and separate existing CPU model",
                    no_operator_dotenv_or_keys=True, dotenv_disabled_by_owned_bootstrap=True,
                    bootstrap_sha256=hashlib.sha256((WORK / "sitecustomize.py").read_bytes()).hexdigest(),
                    launcher_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    fresh_environment_not_inherited=True, broker_connections=0, external_orders=0,
                    target_hours=24, observed_24h=False, cleanup_verified=False)
    with PUBLIC.open("x") as stream:
        stream.write(json.dumps(metadata, indent=2) + "\n")
    SOCKET.mkdir(mode=0o700)
    try:
        run([str(PG / "initdb"), "-D", str(DATA), "--encoding=UTF8", "--locale=C.UTF-8",
             "--auth-local=trust", "--auth-host=reject"], WORK / "postgres-setup.log")
        run([str(PG / "pg_ctl"), "-D", str(DATA), "-l", str(WORK / "postgres.log"),
             "-o", f"-k {SOCKET} -p {PORT} -c listen_addresses='' -c unix_socket_permissions=0700",
             "-w", "-t", "15", "start"], WORK / "postgres-setup.log")
        pg_pid = int((DATA / "postmaster.pid").read_text().splitlines()[0])
        PLAN["postgres_identity"] = capture(pg_pid)
        assert PLAN["postgres_identity"] and PLAN["postgres_identity"]["boot_id"] == PLAN["expected_boot_id"]
        assert str(DATA).encode() in Path(f"/proc/{pg_pid}/cmdline").read_bytes().split(b"\0")
        save(PLAN_FILE, PLAN)
        metadata["postgres_identity"] = PLAN["postgres_identity"]
        save(PUBLIC, metadata)
        asyncio.run(create_database())
        env = dict(BASE_ENV, PYTHONPATH=str(WORK) + os.pathsep + str(ROOT),
                   PYTHONUNBUFFERED="1", PYTHONDONTWRITEBYTECODE="1", ENVIRONMENT="production",
                   TEST_DATABASE_URL=URL, TEST_DATABASE_DISPOSABLE_TOKEN=MARKER, DATABASE_URL=URL,
                   LIVE_TRADING_ENABLED="false", IBKR_ENABLED="false", BANK_SYNC_ENABLED="false",
                   MCP_ENABLED="false", AUTONOMOUS_SCANS_ENABLED="false", NEWS_API_ADAPTERS_ENABLED="false",
                   YAHOO_MARKET_DATA_ENABLED="false", YAHOO_HISTORICAL_DATA_ENABLED="false",
                   OPENBLAS_NUM_THREADS="4", OMP_NUM_THREADS="4", ALLOWED_IPS="127.0.0.1/32",
                   TRUST_PROXY_HEADERS="false", AUTH_REQUIRE_LOGIN="true", AUTH_COOKIE_SECURE="false",
                   AUTH_USERNAME="fixture-soak-bootstrap",
                   AUTH_USERNAME_BASE64=base64.b64encode(b"fixture-soak-bootstrap").decode(),
                   AUTH_PASSWORD_HASH="fixture-unusable-bootstrap", AUTH_SESSION_SECRET=secrets.token_urlsafe(32),
                   BROKER_CREDENTIALS_KEY=Fernet.generate_key().decode(), REPORTS_DIR=str(WORK / "reports"))
        # This proof imports Settings in an isolated child; dotenv reads would be rejected by its audit hook.
        run([str(ROOT / ".venv/bin/python"), "-c",
             "from src.config import settings; assert settings.database_url == __import__('os').environ['TEST_DATABASE_URL']; "
             "assert settings.live_trading_enabled is False; print('EXPLICIT_SETTINGS_WITH_DOTENV_DISABLED_PASS')"],
            WORK / "isolation-check.log", env)
        run([str(ROOT / ".venv/bin/python"), "-m", "alembic", "upgrade", "head"], WORK / "migrations.log", env)
        asyncio.run(source.verify_database(URL, MARKER))
        assert source.code_fingerprint() == PLAN["expected_fingerprint"]
        require_context(PLAN["expected_boot_id"], PLAN["expected_native_pid_namespace"])
        assert matches(PLAN["postgres_identity"]), "OWNED_POSTGRES_IDENTITY_CHANGED"
        command = [str(ROOT / ".venv/bin/python"), "scripts/soak_acceptance.py", "--hours", "24",
                   "--interval", "30", "--restart-every", "900", "--model", str(model.relative_to(ROOT)),
                   "--output", str(OUTPUT.relative_to(ROOT))]
        with PUBLIC_LOG.open("x") as stream:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                       stdout=stream, stderr=subprocess.STDOUT,
                                       start_new_session=True, close_fds=True)
        PLAN["runner_identity"] = capture(process.pid)
        assert PLAN["runner_identity"] and PLAN["runner_identity"]["boot_id"] == PLAN["expected_boot_id"]
        PLAN.update(status="LAUNCHED_NOT_YET_VERIFIED", runner_pid=process.pid,
                    command=command, launched_at=datetime.now(UTC).isoformat())
        save(PLAN_FILE, PLAN)
        metadata.update(status=PLAN["status"], runner_pid=process.pid, runner_identity=PLAN["runner_identity"], command=command,
                        launched_at=PLAN["launched_at"])
        save(PUBLIC, metadata)
        # Bounded startup validation only; no ongoing poller survives this launcher.
        deadline = time.monotonic() + 25
        while True:
            checkpoint = OUTPUT / "checkpoint.json"
            if checkpoint.exists():
                state = json.loads(checkpoint.read_text())
                assert state["code_sha256"] == PLAN["expected_fingerprint"]
                assert state["runner_pid"] == process.pid and not state["failures"]
                assert state["status"] == "RUNNING"
                if state.get("cycles", 0) >= 1:
                    break
            assert process.poll() is None, "RUNNER_EXITED_DURING_STARTUP"
            assert time.monotonic() < deadline, "INITIAL_OBSERVATION_NOT_YET_VERIFIED"
            time.sleep(1)
        require_context(PLAN["expected_boot_id"], PLAN["expected_native_pid_namespace"])
        assert live_owned_runner(process.pid) and matches(PLAN["postgres_identity"])
        metadata["initial_service_identity"] = capture(state["service_pid"])
        assert source.code_fingerprint() == PLAN["expected_fingerprint"]
        metadata.update(status="RUNNING_VERIFIED", verified_at=datetime.now(UTC).isoformat(),
                        initial_cycles=state["cycles"], initial_window_seconds=state["current_window_seconds"],
                        initial_restarts=state["restarts"], initial_failures=state["failures"],
                        cleanup_command=[str(ROOT / ".venv/bin/python"), str(Path(__file__)), "--cleanup-reviewed"])
        PLAN.update(status="RUNNING_VERIFIED", verified_at=metadata["verified_at"])
        save(PLAN_FILE, PLAN)
        save(PUBLIC, metadata)
        print(json.dumps(metadata), flush=True)
    except BaseException as exc:
        metadata.update(status="LAUNCH_OR_INITIAL_VERIFICATION_FAILED", failure_type=type(exc).__name__,
                        failure_code=str(exc) if isinstance(exc, AssertionError) else type(exc).__name__,
                        failed_at=datetime.now(UTC).isoformat(), observed_24h=False)
        PLAN["status"] = metadata["status"]
        save(PLAN_FILE, PLAN)
        save(PUBLIC, metadata)
        if PLAN.get("runner_pid") is None:
            try:
                cleanup()
                metadata["cleanup_verified"] = True
                save(PUBLIC, metadata)
            except BaseException as cleanup_error:
                metadata["cleanup_requires_inspection"] = type(cleanup_error).__name__
                save(PUBLIC, metadata)
        raise


if __name__ == "__main__":
    if sys.argv[1:] == ["--preflight"]:
        print(json.dumps(preflight()), flush=True)
    elif sys.argv[1:] == ["--launch-reviewed"]:
        launch()
    elif sys.argv[1:] == ["--cleanup-reviewed"]:
        cleanup()
    else:
        raise SystemExit("Use --preflight; launch requires explicit root recovery/preflight review then --launch-reviewed")
