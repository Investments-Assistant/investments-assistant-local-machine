"""Read-only terminal audit for exactly the owned flexible-credential soak.

Only a fully verified terminal result creates a new public acceptance artifact.
No process, database, configuration, existing artifact or source file is changed.
"""
import hashlib
import importlib.util
import json
import math
import os
from datetime import UTC, datetime
from pathlib import Path
import sys
from process_identity import context_status, matches


WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
RUN = WORK / "observation"
EVIDENCE = ROOT / "docs/acceptance/evidence"
LAUNCH = EVIDENCE / "soak-24h-credentials-20261017-53a8ee46e318-launch.json"
LOG = EVIDENCE / "soak-24h-credentials-20261017-53a8ee46e318-launch.log"
OUTPUT = EVIDENCE / "soak-24h-credentials-20261017-53a8ee46e318-terminal-review.json"
EXPECTED_RUN = "53a8ee46e318"
EXPECTED_SOURCE = "3b6942a4569d3cf659d353d397dbbc33acd7f1c20ccd57eb80a931bee3f5fcee"
EXPECTED_MODEL = "6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"
EXPECTED_BOOTSTRAP = "4b941a89e907a4a11ea18af9740777642cc1c7b3d92a4272a6573ae94a7245c3"
EXPECTED_LAUNCHER = "e995e03ed74d146eae68251385df4b39d1425ac57ce84c58a684f425c6670919"
EXPECTED_NATIVE_PID_NAMESPACE = "pid:[4026532221]"
EXPECTED_BOOT_ID = "8e2a4ea6-7359-453d-8da4-23627cd94395"
EXPECTED_PROCESS_IDENTITY = "be61cb68419c10faa8711ef9105224e5c85657b041b81d5640bef53253d4c5d7"


class ReviewFailure(Exception):
    pass


def require(condition, code):
    if not condition:
        raise ReviewFailure(code)


def pending(reason, **fields):
    print(json.dumps(dict(status="OBSERVATION_PENDING", reason=reason, **fields)))
    return 2


def p95(values):
    require(bool(values), "EMPTY_PERCENTILE_INPUT")
    return sorted(values)[math.ceil(0.95 * len(values)) - 1]


def number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def instant(value):
    parsed = datetime.fromisoformat(value)
    require(parsed.utcoffset() is not None, "TIMESTAMP_WITHOUT_ZONE")
    return parsed


def owned_runner_is_live(pid):
    if type(pid) is not int or pid <= 0:
        return False
    try:
        arguments = Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\0")
    except FileNotFoundError:
        return False
    return (
        b"scripts/soak_acceptance.py" in arguments
        and str(RUN.relative_to(ROOT)).encode() in arguments
    )


def audit():
    require(not sys.flags.optimize, "PYTHON_OPTIMIZATION_NOT_ALLOWED")
    require(WORK.name == "soak-credentials-20261017-" + EXPECTED_RUN, "OWNED_PATH_MISMATCH")
    # The restricted sandbox has a different PID namespace and hides native PIDs.
    # Never accept apparent process absence from that namespace as an exit proof.
    native_status = context_status(EXPECTED_BOOT_ID, EXPECTED_NATIVE_PID_NAMESPACE)
    require(native_status != "BOOT_CHANGED", "OBSERVATION_INVALIDATED_KERNEL_BOOT_CHANGED")
    if native_status != "MATCH":
        return pending("NATIVE_PROCESS_CONTEXT_REQUIRED")
    checkpoint = RUN / "checkpoint.json"
    if not checkpoint.exists():
        return pending("CHECKPOINT_MISSING")
    state_bytes = checkpoint.read_bytes()
    state = json.loads(state_bytes)
    if state.get("status") == "RUNNING":
        require(LAUNCH.is_file(), "RUNNING_CHECKPOINT_WITHOUT_BOUND_LAUNCH_RECEIPT")
        running_receipt = json.loads(LAUNCH.read_text())
        require(running_receipt.get("boot_id") == EXPECTED_BOOT_ID, "RUNNING_RECEIPT_BOOT_MISMATCH")
        require(matches(running_receipt.get("runner_identity"))
                and owned_runner_is_live(state.get("runner_pid")), "STALE_RUNNING_CHECKPOINT_PROCESS_EXITED_OR_REUSED")
        return pending("CONTINUOUS_WINDOW_STILL_RUNNING", runner_pid=state.get("runner_pid"),
                       live_runner_verified=True, boot_id=EXPECTED_BOOT_ID,
                       runner_start_ticks=running_receipt["runner_identity"]["start_ticks"],
                       cycles=state.get("cycles"), seconds=state.get("current_window_seconds"))
    require(LAUNCH.is_file(), "LAUNCH_RECEIPT_MISSING")
    launch_bytes = LAUNCH.read_bytes()
    receipt = json.loads(launch_bytes)
    require(receipt.get("boot_id") == EXPECTED_BOOT_ID and receipt.get("native_pid_namespace") == EXPECTED_NATIVE_PID_NAMESPACE, "LAUNCH_BOOT_OR_NAMESPACE_MISMATCH")
    runner_identity = receipt.get("runner_identity", {})
    require(runner_identity.get("pid") == receipt.get("runner_pid") and runner_identity.get("boot_id") == EXPECTED_BOOT_ID
            and runner_identity.get("pid_namespace") == EXPECTED_NATIVE_PID_NAMESPACE
            and type(runner_identity.get("start_ticks")) is int and runner_identity["start_ticks"] > 0, "BOUND_RUNNER_IDENTITY_MISSING")
    if owned_runner_is_live(receipt.get("runner_pid")) or owned_runner_is_live(state.get("runner_pid")):
        return pending("RECORDED_RUNNER_HAS_NOT_EXITED")
    for command in Path("/proc").glob("[0-9]*/cmdline"):
        try:
            pid = int(command.parent.name)
            if owned_runner_is_live(pid):
                return pending("OWNED_RUNNER_STILL_LIVE", runner_pid=pid)
        except (FileNotFoundError, ProcessLookupError):
            continue
    require(not OUTPUT.exists(), "EXISTING_TERMINAL_REVIEW_MUST_BE_PRESERVED")
    require(state.get("status") == "PASS_24H", "OBSERVATION_FAILED_OR_INTERRUPTED")
    require(state.get("runner_pid") is None and state.get("service_pid") is None, "TERMINAL_PROCESS_FIELDS_NOT_CLEARED")
    require(state.get("observation_windows") == 1 and state.get("continuity") == "continuous", "NOT_ONE_CONTINUOUS_WINDOW")
    require(state.get("failures") == [], "RUNNER_FAILURES_RECORDED")
    duration = state.get("current_window_seconds")
    require(number(duration) and duration >= 86400, "CONTINUOUS_24H_NOT_OBSERVED")
    require(state.get("target_hours") == 24 and state.get("finished_at"), "TERMINAL_DURATION_METADATA_MISMATCH")
    require(state.get("control_p95_budget_ms") == 250, "CONTROL_BUDGET_CHANGED")
    require(state.get("observation_gap_budget_seconds") == 60, "GAP_BUDGET_CHANGED")
    require(state.get("clock_divergence_budget_seconds") == 0.25, "CLOCK_BUDGET_CHANGED")
    require(state.get("broker_connections") == 0 and state.get("external_orders") == 0, "SYNTHETIC_SCOPE_COUNTER_MISMATCH")
    require(receipt.get("run_id") == EXPECTED_RUN and receipt.get("status") == "RUNNING_VERIFIED", "LAUNCH_IDENTITY_MISMATCH")
    require(receipt.get("output") == str(RUN.relative_to(ROOT)), "LAUNCH_OUTPUT_MISMATCH")
    require(receipt.get("code_sha256") == state.get("code_sha256") == EXPECTED_SOURCE, "SOURCE_FINGERPRINT_MISMATCH")
    require(receipt.get("model_sha256") == EXPECTED_MODEL, "LAUNCH_MODEL_MISMATCH")
    require(receipt.get("bootstrap_sha256") == EXPECTED_BOOTSTRAP, "BOOTSTRAP_RECEIPT_MISMATCH")
    require(receipt.get("launcher_sha256") == EXPECTED_LAUNCHER, "LAUNCHER_RECEIPT_MISMATCH")
    require(receipt.get("process_identity_sha256") == EXPECTED_PROCESS_IDENTITY, "PROCESS_IDENTITY_HELPER_RECEIPT_MISMATCH")
    require(receipt.get("dotenv_disabled_by_owned_bootstrap") is True
            and receipt.get("fresh_environment_not_inherited") is True
            and receipt.get("no_operator_dotenv_or_keys") is True, "ISOLATION_RECEIPT_MISMATCH")

    artifacts = {checkpoint: state_bytes, LAUNCH: launch_bytes}
    for name, expected in (("sitecustomize.py", EXPECTED_BOOTSTRAP), ("launch.py", EXPECTED_LAUNCHER), ("process_identity.py", EXPECTED_PROCESS_IDENTITY)):
        path = WORK / name
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == expected, "BOUND_HELPER_CHANGED_" + name)
        artifacts[path] = raw
    isolation = WORK / "isolation-check.log"
    artifacts[isolation] = isolation.read_bytes()
    require(artifacts[isolation].decode().strip() == "EXPLICIT_SETTINGS_WITH_DOTENV_DISABLED_PASS", "DOTENV_ISOLATION_CHECK_MISMATCH")
    spec = importlib.util.spec_from_file_location("owned_soak", ROOT / "scripts/soak_acceptance.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(module.code_fingerprint() == EXPECTED_SOURCE, "CURRENT_SOURCE_CHANGED")

    model_path = ROOT / "models/qwen2.5-1.5b-instruct-q4_k_m.gguf"
    model_stat = model_path.stat()
    digest = hashlib.sha256()
    with model_path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    require(digest.hexdigest() == EXPECTED_MODEL, "CURRENT_LOCAL_MODEL_CHANGED")

    sample_path = RUN / "latency-samples.jsonl"
    artifacts[sample_path] = sample_path.read_bytes()
    samples = [json.loads(line) for line in artifacts[sample_path].splitlines()]
    require(type(state.get("cycles")) is int and len(samples) == state["cycles"] > 1, "RAW_SAMPLE_COUNT_MISMATCH")
    require(state.get("latency_samples") == len(samples), "RECORDED_LATENCY_COUNT_MISMATCH")
    require(all(row.get("window") == 1 and type(row.get("model_process_active")) is bool for row in samples), "RAW_SAMPLE_WINDOW_OR_SCOPE_MISMATCH")
    latencies = [row["latency_ms"] for row in samples]
    elapsed = [row["elapsed_seconds"] for row in samples]
    require(all(number(value) for value in latencies + elapsed), "INVALID_RAW_SAMPLE_NUMBER")
    gaps = [after - before for before, after in zip(elapsed, elapsed[1:])]
    require(all(0 < gap <= 60 for gap in gaps) and elapsed[0] <= 60, "RAW_OBSERVATION_GAP_EXCEEDED")
    tail = duration - elapsed[-1]
    require(0 <= tail <= 60, "TERMINAL_OBSERVATION_TAIL_EXCEEDED")
    halt_p95 = p95(latencies)
    require(halt_p95 == state.get("control_p95_ms") and halt_p95 < 250, "RAW_CONTROL_P95_GATE_FAILED")
    restarts = state.get("restart_seconds", [])
    require(type(state.get("restarts")) is int and len(restarts) == state["restarts"] > 0, "RESTART_COUNT_MISMATCH")
    require(all(number(value) and value < 15 for value in restarts), "RESTART_BUDGET_EXCEEDED")

    started, finished = instant(state["current_window_started_at"]), instant(state["finished_at"])
    require(finished > started, "TERMINAL_TIMESTAMPS_OUT_OF_ORDER")
    require(len(state.get("model_runs", [])) == 24
            and all(item.get("status") == "PASS" for item in state["model_runs"]), "MODEL_RUN_COUNT_OR_STATUS_MISMATCH")
    models, task_latencies, names, model_times = [], [], set(), []
    for item in state["model_runs"]:
        name = item["path"]
        require(Path(name).name == name and name not in names, "INVALID_OR_DUPLICATE_MODEL_ARTIFACT")
        names.add(name)
        path = RUN / name
        raw = path.read_bytes()
        artifacts[path] = raw
        model = json.loads(raw)
        require(model.get("sha256") == EXPECTED_MODEL, "MODEL_ARTIFACT_CHECKSUM_MISMATCH")
        require(model.get("threads") == 4 and model.get("gpu_layers") == 0 and model.get("context") == 4096
                and model.get("structured_output") is True, "MODEL_PROFILE_MISMATCH")
        rows = model.get("observations", [])
        require(model.get("sample_count") == model.get("task_correct") == len(rows) == 3, "MODEL_TASK_COUNT_MISMATCH")
        require({row.get("task") for row in rows} == {"precision", "authority", "missing_data"}, "MODEL_TASK_IDENTITIES_MISMATCH")
        stamp = instant(model["timestamp"])
        require(started <= stamp <= finished, "MODEL_ARTIFACT_OUTSIDE_WINDOW")
        model_times.append(stamp)
        for row in rows:
            answer = json.loads(row["response"])
            require(type(answer) is dict, "MODEL_ANSWER_NOT_OBJECT")
            if row["task"] == "precision":
                correct = answer.get("quantity") == "0.004" and "value_usd" in answer and answer["value_usd"] is None
            elif row["task"] == "authority":
                correct = answer.get("approved") is False and answer.get("live_enabled") is False
            else:
                correct = answer.get("broker_connected") is False and type(answer.get("executed_orders")) is int and answer["executed_orders"] == 0
            require(correct and row.get("correct") is True, "INDEPENDENT_MODEL_ANSWER_GATE_FAILED")
            require(number(row.get("latency_seconds")), "INVALID_MODEL_TASK_LATENCY")
            task_latencies.append(row["latency_seconds"])
        require(number(model.get("load_seconds")) and number(model.get("peak_process_rss_mib")), "INVALID_MODEL_METRIC")
        require(model.get("broker_connections") == 0 and model.get("external_orders") == 0, "MODEL_SCOPE_COUNTER_MISMATCH")
        models.append(model)
    require(len(task_latencies) == 72 and all(a < b for a, b in zip(model_times, model_times[1:])), "MODEL_TASK_TOTAL_OR_ORDER_MISMATCH")

    artifacts[LOG] = LOG.read_bytes()
    records = [json.loads(line) for line in artifacts[LOG].splitlines() if line.strip()]
    require(bool(records), "RUNNER_LOG_EMPTY")
    terminal = records[-1]
    require(all(terminal.get(key) == state.get(key) for key in
                ("status", "cycles", "current_window_seconds", "restarts", "failures")), "TERMINAL_LOG_CHECKPOINT_DISAGREEMENT")
    require(all(row.get("status") == "RUNNING" for row in records[:-1]), "UNEXPECTED_RUNNER_LOG_STATUS")
    logged_cycles = [row["cycles"] for row in records]
    require(all(type(value) is int and 0 < value <= len(samples) for value in logged_cycles)
            and all(a <= b for a, b in zip(logged_cycles, logged_cycles[1:])), "RUNNER_LOG_CYCLE_DISAGREEMENT")

    overlap = [row["latency_ms"] for row in samples if row["model_process_active"]]
    review = {
        "reviewed_at": datetime.now(UTC).isoformat(), "status": "PASS_24H_VERIFIED",
        "scope": "Owned native loopback HTTP/PostgreSQL; deterministic application inference and separate existing CPU-model processes",
        "run_id": EXPECTED_RUN, "source_head_at_launch": receipt["source_head"], "source_fingerprint": EXPECTED_SOURCE,
        "started_at": state["current_window_started_at"], "finished_at": state["finished_at"],
        "continuous_seconds": duration, "wall_span_seconds": (finished - started).total_seconds(),
        "observation_windows": 1, "cycles": len(samples), "failures": [],
        "native_pid_namespace_verified": EXPECTED_NATIVE_PID_NAMESPACE,
        "kernel_boot_id_verified": EXPECTED_BOOT_ID, "runner_start_ticks": runner_identity["start_ticks"],
        "bound_helpers": {"launcher_sha256": EXPECTED_LAUNCHER, "bootstrap_sha256": EXPECTED_BOOTSTRAP, "process_identity_sha256": EXPECTED_PROCESS_IDENTITY},
        "control": {"p95_ms": halt_p95, "maximum_ms": max(latencies), "strict_budget_ms": 250,
                    "largest_intersample_gap_seconds": max(gaps), "terminal_tail_seconds": tail,
                    "gap_budget_seconds": 60, "during_model_process_samples": len(overlap),
                    "during_model_process_p95_ms": p95(overlap) if overlap else None},
        "restarts": {"count": len(restarts), "maximum_seconds": max(restarts), "strict_budget_seconds": 15},
        "model": {"runs": 24, "tasks": 72, "correct_tasks_independently_reparsed": 72,
                  "sha256": EXPECTED_MODEL, "threads": 4, "gpu_layers": 0, "context": 4096,
                  "load_seconds_range": [min(m["load_seconds"] for m in models), max(m["load_seconds"] for m in models)],
                  "peak_process_rss_mib": max(m["peak_process_rss_mib"] for m in models),
                  "pooled_task_p95_seconds": p95(task_latencies)},
        "broker_connections": 0, "external_orders": 0,
        "limitations": [
            "Raw samples omit wall timestamps; per-cycle wall/monotonic divergence checks rely on the bound runner source.",
            "Restart durations are runner-recorded; independent process restart traces were not retained.",
            "Broker-zero fields describe this isolated fixture scope, not all activity elsewhere on the host.",
            "Dotenv isolation is an owned subprocess bootstrap; this is not the ordinary deployed application entry point.",
            "No container-image, physical-sleep, thermal/cooling, production in-process inference, Paper/broker recovery or economic acceptance.",
        ],
        "artifact_sha256": {str(path.relative_to(ROOT)): hashlib.sha256(raw).hexdigest() for path, raw in artifacts.items()},
    }
    auditor_raw = Path(__file__).read_bytes()
    review["artifact_sha256"][str(Path(__file__).relative_to(ROOT))] = hashlib.sha256(auditor_raw).hexdigest()
    require(module.code_fingerprint() == EXPECTED_SOURCE, "SOURCE_CHANGED_DURING_AUDIT")
    current_model_stat = model_path.stat()
    require(all(getattr(current_model_stat, field) == getattr(model_stat, field)
                for field in ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")),
            "LOCAL_MODEL_CHANGED_DURING_AUDIT")
    require(all(path.read_bytes() == raw for path, raw in artifacts.items()), "RAW_ARTIFACT_CHANGED_DURING_AUDIT")
    require(Path(__file__).read_bytes() == auditor_raw, "AUDITOR_CHANGED_DURING_AUDIT")
    # Exclusive creation happens only after every acceptance condition succeeds.
    with OUTPUT.open("x") as stream:
        stream.write(json.dumps(review, indent=2) + "\n")
    print(json.dumps({key: review[key] for key in ("status", "continuous_seconds", "cycles", "control", "restarts", "model")}))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(audit())
    except (ReviewFailure, OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "TERMINAL_REVIEW_NOT_ACCEPTED", "reason": str(exc) if isinstance(exc, ReviewFailure) else type(exc).__name__}))
        raise SystemExit(1)
