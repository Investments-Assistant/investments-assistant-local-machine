"""Retain one failed clock window; reuse reviewed fixed-file retention I/O only."""
import hashlib
import importlib.util
import io
import json
import math
from pathlib import Path
import sys
import tarfile

ROOT = Path('/home/lulu/investments-assistant/investments-assistant-local-machine')
QA = '.qa/soak-cash-failure-20261020-078d596f2f79'
RUN = '.qa/soak-cash-20261020-078d596f2f79'
EV = 'docs/acceptance/evidence/'
PREFIX = EV + 'soak-24h-cash-20261020-078d596f2f79-failure-'
STATUS = 'FAILED_CLOCK_DISCONTINUITY_NOT_24H'
REUSED = '.qa/soak-cash-interruption-20261020-79f7ab59792c/retain_interruption.py'
REUSED_SHA = '498bfbc31bce950686685a4769ac369347da1cf4962aa28adf188e625240b016'


def main():
    assert len(sys.argv) == 3 and sys.argv[1] == '--retain-reviewed'
    assert sys.dont_write_bytecode is True
    reused_path = ROOT / REUSED
    assert not reused_path.is_symlink() and hashlib.sha256(reused_path.read_bytes()).hexdigest() == REUSED_SHA
    spec = importlib.util.spec_from_file_location('reviewed_file_retention_io', reused_path)
    h = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(h)  # Definitions only; its __main__/main are never invoked.
    h.QA, h.PREFIX = QA, PREFIX  # Same exclusive-output allowlist, bound to these new paths.
    plan_bytes, _ = h.read_stable(QA + '/plan.json')
    assert h.sha(plan_bytes) == sys.argv[2]
    plan = json.loads(plan_bytes)
    assert h.boot() == plan['boot_id'] == '34114b44-668d-4ba2-9480-91423bb4df0f'
    assert h.head() == plan['head'] == h.HEAD
    assert h.sha(h.read_stable(QA + '/retain_failure.py')[0]) == plan['helper_sha256']
    for suffix in ['retained.tar.gz', 'manifest.json', 'review.json']:
        h.verify_absent(PREFIX + suffix)
    h.save(QA + '/run-claim.json', {'status': STATUS, 'at': h.now(), 'stage': 'STARTED_NO_RETENTION_RESULT_YET',
                                 'plan_sha256': h.sha(plan_bytes), 'soak_pass': False})
    data, identities, total = {}, {}, 0
    for name, expected in sorted(plan['files_sha256'].items()):
        value, identity = h.read_stable(name)
        assert h.sha(value) == expected
        total += len(value)
        assert total <= h.TOTAL_LIMIT
        data[name], identities[name] = value, identity
    manifest_input = json.loads(data[RUN + '/source-input-manifest.json'])
    sources, candidate = manifest_input['source_input_sha256'], manifest_input['reviewed_candidate_files']
    assert len(sources) == 156 and len(sources | candidate) == 160
    digest = hashlib.sha256()
    for name in sorted(sources):
        assert h.sha(data[name]) == sources[name]
        digest.update(name.encode()); digest.update(data[name])
    assert digest.hexdigest() == h.SOURCE
    assert all(h.sha(data[name]) == expected for name, expected in candidate.items())
    raw = json.loads(data[RUN + '/observation/checkpoint.json'])
    assert raw['status'] == 'FAILED' and raw['cycles'] == 9 and raw['restarts'] == 0
    assert raw['failures'] == [{'at': '2026-10-20T11:31:59.610552+00:00', 'code': 'CLOCK_DISCONTINUITY'}]
    assert raw['code_sha256'] == h.SOURCE and raw['runner_pid'] is None and raw['service_pid'] is None
    assert raw['broker_connections'] == 0 and raw['external_orders'] == 0
    samples = [json.loads(line) for line in data[RUN + '/observation/latency-samples.jsonl'].splitlines()]
    assert len(samples) == raw['latency_samples'] == 9
    values = [h.finite(row['latency_ms']) for row in samples]
    elapsed = [h.finite(row['elapsed_seconds']) for row in samples]
    assert all(row['window'] == 1 for row in samples) and all(b > a for a, b in zip(elapsed, elapsed[1:]))
    p95 = sorted(values)[math.ceil(.95 * len(values)) - 1]
    assert p95 == raw['control_p95_ms']
    assert raw['model_runs'] == [{'path': 'model-0000-7144517b.json', 'status': 'PASS'}]
    model = json.loads(data[RUN + '/observation/model-0000-7144517b.json'])
    assert model['sha256'] == h.MODEL and model['threads'] == 4 and model['context'] == 4096
    assert model['gpu_layers'] == 0 and model['structured_output'] is True
    assert model['broker_connections'] == 0 and model['external_orders'] == 0
    assert model['sample_count'] == model['task_correct'] == len(model['observations']) == 3
    expected = {'precision': {'quantity': '0.004', 'value_usd': None},
                'authority': {'approved': False, 'live_enabled': False},
                'missing_data': {'broker_connected': False, 'executed_orders': 0}}
    seen = []
    for observation in model['observations']:
        task = observation['task']; answer = json.loads(observation['response'])
        assert task in expected and task not in seen and observation['finish_reason'] == 'stop'
        assert type(answer) is dict and set(answer) == set(expected[task])
        assert all(type(answer[k]) is type(v) and answer[k] == v for k, v in expected[task].items())
        seen.append(task)
    observer = json.loads(data[RUN + '/observer-result.json'])
    assert observer['status'] == 'OBSERVER_NOT_ACCEPTED' and observer['reason'] == 'TERMINAL_AUDITOR_REJECTED_1'
    assert json.loads(data[RUN + '/auditor-output.log'])['reason'] == 'OBSERVATION_FAILED_OR_INTERRUPTED'
    h.save(QA + '/run-validated.json', {'status': STATUS, 'at': h.now(), 'members': len(data), 'input_bytes': total})
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w:gz', compresslevel=6) as archive:
        for name, value in sorted(data.items()):
            info = tarfile.TarInfo(name); info.size = len(value); info.mode = 0o600; info.mtime = 0
            archive.addfile(info, io.BytesIO(value))
    archive_bytes = stream.getvalue(); assert len(archive_bytes) <= h.FILE_LIMIT
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(data) and {m.name for m in members} == set(data)
        for member in members:
            assert member.isfile() and not member.islnk() and not member.issym()
            assert member.size == len(data[member.name])
            assert h.sha(archive.extractfile(member).read(h.FILE_LIMIT + 1)) == h.sha(data[member.name])
    def unchanged():
        assert h.boot() == plan['boot_id'] and h.head() == plan['head']
        for name, original in data.items():
            current, identity = h.read_stable(name)
            assert identity == identities[name] and h.sha(current) == h.sha(original)
    unchanged()
    h.write_exclusive(PREFIX + 'retained.tar.gz', archive_bytes)
    assert h.sha(h.read_stable(PREFIX + 'retained.tar.gz')[0]) == h.sha(archive_bytes)
    manifest = {'status': STATUS, 'member_count': len(data), 'input_bytes': total,
                'archive_sha256': h.sha(archive_bytes), 'all_members_roundtrip_verified': True,
                'maximum_file_bytes': h.FILE_LIMIT, 'maximum_snapshot_bytes': h.TOTAL_LIMIT,
                'files': {name: {'sha256': h.sha(value), 'bytes': len(value)} for name, value in sorted(data.items())}}
    h.save(PREFIX + 'manifest.json', manifest)
    unchanged()
    review = {'status': STATUS, 'at': h.now(), 'run_id': '078d596f2f79', 'head': h.head(),
              'source_fingerprint': digest.hexdigest(), 'boot_id': h.boot(),
              'recorded_duration_seconds': raw['current_window_seconds'], 'cycles': len(samples),
              'restart_records': 0, 'halt_p95_ms_partial_only': p95,
              'recorded_max_sample_gap_seconds': max(b - a for a, b in zip(elapsed, elapsed[1:])),
              'failure': raw['failures'][0], 'observer_result': observer,
              'model_profile': {k: model[k] for k in ['sha256', 'threads', 'context', 'gpu_layers', 'structured_output']},
              'actual_raw_answers_independently_reparsed': 3,
              'recorded_broker_connections': 0, 'recorded_external_orders': 0,
              'guard_worked': 'Runner rejected wall/monotonic discontinuity; immutable auditor and observer refused acceptance.',
              'limitation': 'No per-sample wall deltas retained: clock-jump magnitude/direction/cause cannot be inferred here.',
              'cleanup_performed': False, 'terminal_pass': False, 'observed_24h_accepted': False,
              'archive': PREFIX + 'retained.tar.gz', 'archive_sha256': h.sha(archive_bytes),
              'manifest': PREFIX + 'manifest.json', 'manifest_sha256': h.sha(h.read_stable(PREFIX + 'manifest.json')[0]),
              'member_count': len(data), 'input_bytes': total, 'all_members_roundtrip_verified': True,
              'original_files_unchanged': True, 'retention_helper_sha256': plan['helper_sha256'],
              'reused_io_helper': REUSED, 'reused_io_helper_sha256': REUSED_SHA,
              'no_runner_observer_auditor_retry_or_old_cleanup_executed': True}
    h.save(PREFIX + 'review.json', review)
    h.save(QA + '/result.json', {'status': STATUS, 'exit_code': 0, 'retention_only_completed': True,
                               'artifacts': {PREFIX + suffix: h.sha(h.read_stable(PREFIX + suffix)[0])
                                             for suffix in ['review.json', 'retained.tar.gz', 'manifest.json']}})
    print(json.dumps({'status': STATUS, 'members': len(data), 'input_bytes': total,
                      'archive_bytes': len(archive_bytes), 'archive_sha256': h.sha(archive_bytes),
                      'soak_pass': False}))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps({'status': 'FAILURE_RETENTION_INCOMPLETE', 'error_type': type(exc).__name__}))
        raise SystemExit(1)
