"""Synthetic subprocess isolation: no dotenv or operator-private file reads."""
import os
import sys

from pydantic_settings import BaseSettings

_original_init = BaseSettings.__init__


def _without_dotenv(self, *args, **kwargs):
    kwargs["_env_file"] = None
    return _original_init(self, *args, **kwargs)


BaseSettings.__init__ = _without_dotenv


def _deny_private_files(event, arguments):
    if event != "open" or not arguments:
        return
    path = arguments[0]
    if not isinstance(path, (str, bytes, os.PathLike)):
        return
    path = os.fsdecode(path)
    if os.path.basename(path) == ".env" or "/.local-private/" in path:
        raise PermissionError("SOAK_OPERATOR_PRIVATE_FILE_READ_FORBIDDEN")


sys.addaudithook(_deny_private_files)
