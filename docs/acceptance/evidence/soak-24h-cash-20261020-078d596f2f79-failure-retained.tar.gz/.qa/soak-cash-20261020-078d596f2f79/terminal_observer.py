"""Finite, one-shot pidfd wait for one already-running, owned soak.

Never starts/restarts/signals the runner, changes acceptance or cleans resources.
Only the existing immutable terminal auditor can create the acceptance artifact.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import select
import subprocess
import sys
import time
from datetime import UTC, datetime

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
SOAK = WORK
EVIDENCE = ROOT / 'docs/acceptance/evidence'
LAUNCH = EVIDENCE / 'soak-24h-cash-20261020-078d596f2f79-launch.json'
TERMINAL = EVIDENCE / 'soak-24h-cash-20261020-078d596f2f79-terminal-review.json'
RUN_ID = '078d596f2f79'
SOURCE = '4fd1380c5c1595bfb8bbd311f02ec561fc013eac5f7da9563dc5c025151d1d30'
MODEL = '6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e'
BOOT = '34114b44-668d-4ba2-9480-91423bb4df0f'
NAMESPACE = 'pid:[4026532221]'
HEAD = 'e154a0a365ece2a9fd81657034139c43c8e0abe6'
MOUNT_NAMESPACE = 'mnt:[4026532219]'
HELPERS = {'audit_terminal.py': 'ba7b4a14b1d008c6a5a6234b07255a9fecc48c16ffe7f779c3e9a548bc1fea07', 'process_identity.py': 'be61cb68419c10faa8711ef9105224e5c85657b041b81d5640bef53253d4c5d7', 'sitecustomize.py': '4b941a89e907a4a11ea18af9740777642cc1c7b3d92a4272a6573ae94a7245c3', 'launch.py': '7e5460aa56e25ddcbe78fcf43c77a3e08f7da8c28bea60b10eda383f4fce41de', 'source-input-manifest.json': 'ccc5bcb0e6067df2ed23a84b97cc74b6e55de15bc557e905e7448ecf50c97e2c'}


class Refusal(Exception):
    pass


def require(condition, code):
    if not condition:
        raise Refusal(code)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def now():
    return datetime.now(UTC).isoformat()


def save(name, value):
    with (WORK / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def exact_environment():
    env = {
        'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8',
        'NEWS_SOURCES': 'none',
        'PYTHONPATH': str(SOAK) + ':' + str(ROOT),
        'PYTHONDONTWRITEBYTECODE': '1',
        'LD_LIBRARY_PATH': str(ROOT / '.qa/postgres-root/usr/lib/x86_64-linux-gnu'),
        'PGPASSFILE': '/dev/null', 'PGSERVICEFILE': '/dev/null',
        'NEWS_SOURCE_POLICIES': '{}', 'NEWS_SERVICE_USER_ID': '',
        'NEWSLETTER_OWNER_USER_ID': '', 'NEWSLETTER_EMAIL_USER': '',
        'NEWSLETTER_EMAIL_PASSWORD': '',
    }
    for key in ('LIVE_TRADING_ENABLED', 'IBKR_ENABLED', 'BANK_SYNC_ENABLED',
                'MCP_ENABLED', 'AUTONOMOUS_SCANS_ENABLED', 'NEWS_API_ADAPTERS_ENABLED',
                'YAHOO_MARKET_DATA_ENABLED', 'YAHOO_HISTORICAL_DATA_ENABLED'):
        env[key] = 'false'
    return env


def checked_bindings(require_frozen_binding=True):
    require(not sys.flags.optimize, 'OPTIMIZATION_REFUSED')
    require(WORK == ROOT / ('.qa/soak-cash-20261020-' + RUN_ID), 'PATH_MISMATCH')
    for name, expected in HELPERS.items():
        require(digest(SOAK / name) == expected, 'BOUND_HELPER_CHANGED_' + name)
    from process_identity import context_status
    require(context_status(BOOT, NAMESPACE) == 'MATCH', 'NATIVE_BOOT_NAMESPACE_REQUIRED')
    require(os.readlink('/proc/self/ns/mnt') == MOUNT_NAMESPACE, 'NATIVE_MOUNT_NAMESPACE_REQUIRED')
    observer_plan = json.loads((WORK / 'observer-plan.json').read_text())
    require(observer_plan['run_id'] == RUN_ID and observer_plan['source_sha256'] == SOURCE
            and observer_plan['model_sha256'] == MODEL and observer_plan['published_commit'] == HEAD,
            'OBSERVER_PLAN_MISMATCH')
    for name in ('terminal_observer.py', 'launch_observer.py'):
        require(digest(WORK / name) == observer_plan['helper_sha256'][name], 'OBSERVER_HELPER_CHANGED')
    env = exact_environment()
    require(observer_plan['clean_environment'] == env and dict(os.environ) == env,
            'INHERITED_ENVIRONMENT_REFUSED')
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, env=env, text=True).strip() == HEAD,
            'HEAD_CHANGED_NEW_EXPLICIT_BYTE_RECONCILIATION_REQUIRED')
    plan = json.loads((SOAK / 'plan.json').read_text())
    require(plan['run_id'] == RUN_ID and plan['expected_commit'] == HEAD
            and plan['expected_fingerprint'] == SOURCE and plan['expected_model_sha256'] == MODEL
            and plan['expected_boot_id'] == BOOT and plan['expected_native_pid_namespace'] == NAMESPACE
            and plan['expected_native_mount_namespace'] == MOUNT_NAMESPACE, 'SOAK_PLAN_BINDING_MISMATCH')
    if not LAUNCH.exists():
        require(plan['status'] == 'PREPARED_NOT_LAUNCHED', 'PARTIAL_LAUNCH_REQUIRES_INSPECTION')
        raise Refusal('NEW_VERIFIED_LAUNCH_PENDING_NO_OBSERVER_STARTED')
    launch = json.loads(LAUNCH.read_text())
    require(plan['status'] == launch['status'] == 'RUNNING_VERIFIED', 'NEW_LAUNCH_NOT_VERIFIED')
    require(launch['run_id'] == RUN_ID and launch['source_head'] == HEAD and launch['code_sha256'] == SOURCE
            and launch['model_sha256'] == MODEL and launch['boot_id'] == BOOT
            and launch['native_pid_namespace'] == NAMESPACE
            and launch['native_mount_namespace'] == MOUNT_NAMESPACE, 'RUN_BINDING_MISMATCH')
    require(launch['input_manifest_sha256'] == HELPERS['source-input-manifest.json']
            and launch['launcher_sha256'] == HELPERS['launch.py']
            and launch['terminal_auditor_sha256'] == HELPERS['audit_terminal.py']
            and launch['bootstrap_sha256'] == HELPERS['sitecustomize.py']
            and launch['process_identity_sha256'] == HELPERS['process_identity.py'], 'LAUNCH_HELPER_BINDING_MISMATCH')
    require(launch['no_operator_dotenv_or_keys'] is True
            and launch['dotenv_disabled_by_owned_bootstrap'] is True
            and launch['fresh_environment_not_inherited'] is True, 'ISOLATION_RECEIPT_MISMATCH')
    require(launch['database'] == plan['database'] == 'test_soak_cash_' + RUN_ID
            and launch['socket'] == plan['socket'] == str(ROOT / '.qa' / ('s-' + RUN_ID[:8]))
            and launch['port'] == plan['port'] == 55456
            and launch['output'] == str((SOAK / 'observation').relative_to(ROOT)), 'OWNED_FIXTURE_SCOPE_MISMATCH')
    expected_command = [str(ROOT / '.venv/bin/python'), 'scripts/soak_acceptance.py', '--hours', '24',
                        '--interval', '30', '--restart-every', '900', '--model',
                        'models/qwen2.5-1.5b-instruct-q4_k_m.gguf', '--output',
                        str((SOAK / 'observation').relative_to(ROOT))]
    require(launch['command'] == plan['command'] == expected_command, 'RUNNER_COMMAND_MISMATCH')
    identity = launch['runner_identity']
    require(type(identity['pid']) is int and identity['pid'] > 0
            and identity['pid'] == launch['runner_pid'] == plan['runner_pid']
            and type(identity['start_ticks']) is int and identity['start_ticks'] > 0
            and identity['boot_id'] == BOOT and identity['pid_namespace'] == NAMESPACE
            and identity['command_sha256'] == hashlib.sha256(b'\0'.join(x.encode() for x in expected_command) + b'\0').hexdigest(),
            'DYNAMIC_NEW_RUNNER_IDENTITY_INVALID')
    for field in ('pid', 'start_ticks', 'boot_id', 'pid_namespace', 'command_sha256'):
        require(identity[field] == plan['runner_identity'][field]
                and launch['postgres_identity'][field] == plan['postgres_identity'][field], 'LAUNCH_PLAN_IDENTITY_DISAGREEMENT')
    if require_frozen_binding:
        bound = json.loads((WORK / 'observer-binding.json').read_text())
        require(bound['run_id'] == RUN_ID and bound['launch_receipt_sha256'] == digest(LAUNCH)
                and bound['running_plan_sha256'] == digest(SOAK / 'plan.json')
                and bound['runner_identity'] == identity
                and bound['postgres_identity'] == launch['postgres_identity'], 'FROZEN_NEW_LAUNCH_BINDING_CHANGED')
    return observer_plan, launch, identity, env


def preflight():
    _, launch, identity, env = checked_bindings(require_frozen_binding=False)
    from process_identity import matches
    require(matches(identity) and matches(launch['postgres_identity']), 'OWNED_PROCESS_NOT_LIVE')
    require(Path('/proc/' + str(identity['pid']) + '/cwd').resolve() == ROOT, 'RUNNER_CWD_MISMATCH')
    require(not TERMINAL.exists(), 'TERMINAL_ARTIFACT_ALREADY_PRESENT')
    for name in ('observer-start.json', 'observer-result.json', 'auditor-start.json', 'auditor-execution.json',
                 'auditor-output.log', 'observer-output.log', 'observer-launch-execution.json',
                 'observer-launch-claim.json', 'observer-binding.json'):
        require(not (WORK / name).exists(), 'EXISTING_OBSERVER_OPERATION_REQUIRES_INSPECTION')
    state = json.loads((SOAK / 'observation/checkpoint.json').read_text())
    require(state.get('status') == 'RUNNING' and state.get('runner_pid') == identity['pid']
            and state.get('code_sha256') == SOURCE and state.get('failures') == [], 'RUNNING_STATE_MISMATCH')
    manifest = json.loads((SOAK / 'source-input-manifest.json').read_text())
    for name, expected in (manifest['source_input_sha256'] | manifest['reviewed_candidate_files']).items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'INVALID_INPUT_PATH')
        require(digest(ROOT / name) == expected, 'SOURCE_INPUT_CHANGED')
    for name, expected in manifest['existing_acceptance_proof_sha256'].items():
        require(digest(ROOT / name) == expected, 'PUBLISHED_ACCEPTANCE_PROOF_CHANGED')
    require(digest(ROOT / 'models/qwen2.5-1.5b-instruct-q4_k_m.gguf') == MODEL, 'MODEL_CHANGED')
    require(matches(identity), 'RUNNER_EXITED_DURING_PREFLIGHT')
    return launch, identity, env


def observe():
    _, _, identity, env = checked_bindings()
    from process_identity import capture, context_status, matches
    require(not TERMINAL.exists(), 'TERMINAL_ARTIFACT_ALREADY_PRESENT')
    require(matches(identity), 'RUNNER_ALREADY_EXITED_OR_REUSED')
    fd = os.pidfd_open(identity['pid'])
    try:
        # Refuse a process which exited or was replaced while pidfd_open raced.
        require(matches(identity), 'RUNNER_CHANGED_DURING_PIDFD_OPEN')
        state = json.loads((SOAK / 'observation/checkpoint.json').read_text())
        elapsed = state.get('current_window_seconds')
        require(state.get('status') == 'RUNNING' and state.get('runner_pid') == identity['pid']
                and state.get('code_sha256') == SOURCE and state.get('failures') == [], 'CHECKPOINT_NOT_RUNNING')
        require(type(elapsed) in (int, float) and math.isfinite(elapsed) and 0 <= elapsed < 86400,
                'INVALID_REMAINING_DURATION')
        # Grace bounds this observer only; the immutable auditor still needs >=86400s.
        timeout_seconds = 86400 - elapsed + 900
        require(0 < timeout_seconds <= 87300, 'UNBOUNDED_WAIT_REFUSED')
        observer = capture(os.getpid())
        save('observer-start.json', {
            'status': 'WAITING_FOR_BOUND_RUNNER_EXIT', 'at': now(), 'run_id': RUN_ID,
            'observer_identity': observer, 'runner_identity': identity,
            'checkpoint_seconds': elapsed, 'maximum_wait_seconds': timeout_seconds,
            'observer_sha256': digest(Path(__file__)),
            'launch_binding_sha256': digest(WORK / 'observer-binding.json'),
            'plan_sha256': digest(WORK / 'observer-plan.json'),
            'acceptance_credit': False, 'signals_or_cleanup_permitted': False,
        })
        poller = select.poll()
        poller.register(fd, select.POLLIN)
        wait_started = time.monotonic()
        events = poller.poll(math.ceil(timeout_seconds * 1000))
        waited = time.monotonic() - wait_started
        require(bool(events), 'OBSERVER_TIMEOUT_NO_ACCEPTANCE')
        require(len(events) == 1 and events[0][0] == fd
                and bool(events[0][1] & (select.POLLIN | select.POLLHUP))
                and not events[0][1] & (select.POLLNVAL | select.POLLERR), 'INVALID_PIDFD_EVENT')
        require(context_status(BOOT, NAMESPACE) == 'MATCH', 'NATIVE_CONTEXT_CHANGED')
        require(not matches(identity), 'BOUND_RUNNER_STILL_LIVE')
        checked_bindings()
        require(not TERMINAL.exists(), 'TERMINAL_ARTIFACT_ALREADY_PRESENT')
        argv = [str(ROOT / '.venv/bin/python'), '-B', str(SOAK / 'audit_terminal.py')]
        save('auditor-start.json', {'at': now(), 'run_id': RUN_ID,
                                  'argv': argv, 'waited_seconds': waited,
                                  'auditor_sha256': HELPERS['audit_terminal.py'],
                                  'maximum_auditor_seconds': 300})
        with (WORK / 'auditor-output.log').open('x') as log:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT)
            save('auditor-execution.json', {'at': now(), 'identity': capture(child.pid),
                                           'argv': argv, 'maximum_seconds': 300})
            try:
                exit_code = child.wait(timeout=300)
            except subprocess.TimeoutExpired:
                # Do not signal even this audit. Preserve its exact child receipt for inspection.
                raise Refusal('AUDITOR_TIMEOUT_INSPECT_SAVED_CHILD_NO_RETRY') from None
        require(exit_code == 0, 'TERMINAL_AUDITOR_REJECTED_' + str(exit_code))
        require(TERMINAL.is_file(), 'VERIFIED_TERMINAL_ARTIFACT_MISSING')
        review = json.loads(TERMINAL.read_text())
        duration = review.get('continuous_seconds')
        require(review.get('status') == 'PASS_24H_VERIFIED' and review.get('run_id') == RUN_ID
                and review.get('source_fingerprint') == SOURCE
                and review.get('model', {}).get('sha256') == MODEL
                and type(duration) in (int, float) and math.isfinite(duration) and duration >= 86400,
                'VERIFIED_TERMINAL_BINDING_MISMATCH')
        save('observer-result.json', {'at': now(), 'status': 'EXISTING_TERMINAL_AUDITOR_VERIFIED',
             'run_id': RUN_ID, 'auditor_exit_code': exit_code,
             'terminal_review': str(TERMINAL.relative_to(ROOT)),
             'terminal_review_sha256': digest(TERMINAL), 'continuous_seconds': duration,
             'goal_status_changed': False, 'cleanup_executed': False})
        return 0
    finally:
        os.close(fd)


if __name__ == '__main__':
    try:
        if sys.argv[1:] == ['--preflight']:
            preflight()
            print(json.dumps({'status': 'OBSERVER_PREFLIGHT_PASS_NOT_STARTED', 'run_id': RUN_ID}))
            raise SystemExit(0)
        require(sys.argv[1:] == ['--observe-once'], 'EXPLICIT_MODE_REQUIRED')
        raise SystemExit(observe())
    except (Refusal, OSError, ValueError, KeyError, TypeError) as exc:
        reason = str(exc) if isinstance(exc, Refusal) else type(exc).__name__
        result = {'at': now(), 'status': 'OBSERVER_NOT_ACCEPTED', 'run_id': RUN_ID,
                  'reason': reason, 'goal_status_changed': False, 'cleanup_executed': False}
        if sys.argv[1:] == ['--observe-once']:
            save('observer-result.json', result)
        print(json.dumps(result))
        raise SystemExit(2 if sys.argv[1:] == ['--preflight'] and reason == 'NEW_VERIFIED_LAUNCH_PENDING_NO_OBSERVER_STARTED' else 1)
