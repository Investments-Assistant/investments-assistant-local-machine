"""Finite read-only preparation checks; never initializes or launches a fixture.

Only exclusive QA preflight identity/output/result receipts are written.
An unexpected timeout preserves the child identity and never retries/signals it.
"""
from datetime import UTC, datetime
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent


def now():
    return datetime.now(UTC).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (WORK / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def main():
    assert sys.argv[1:] == ['--check-once'], 'EXPLICIT_READ_ONLY_MODE_REQUIRED'
    pins = json.loads((WORK / 'root-review-pins.json').read_text())
    for name, expected in pins['helper_sha256'].items():
        assert Path(name).name == name and digest(WORK / name) == expected, 'PREPARED_HELPER_CHANGED'
    assert digest(WORK / 'process_identity.py') == 'be61cb68419c10faa8711ef9105224e5c85657b041b81d5640bef53253d4c5d7'
    spec = importlib.util.spec_from_file_location('owned_identity', WORK / 'process_identity.py')
    identity = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(identity)
    plan = json.loads((WORK / 'plan.json').read_text())
    identity.require_context(plan['expected_boot_id'], plan['expected_native_pid_namespace'])
    assert os.readlink('/proc/self/ns/mnt') == plan['expected_native_mount_namespace']
    assert plan['status'] == 'PREPARED_NOT_LAUNCHED'
    env = json.loads((WORK / 'observer-plan.json').read_text())['clean_environment']
    assert env['PYTHONPATH'] == str(WORK) + ':' + str(ROOT)
    assert not (WORK / 'pgdata').exists() and not Path(plan['socket']).exists()
    assert not (WORK / 'observation').exists()
    prepared_plan_sha = digest(WORK / 'plan.json')
    syntax = []
    for path in sorted(WORK.glob('*.py')):
        ast.parse(path.read_text(), filename=str(path))
        syntax.append({'path': path.name, 'sha256': digest(path)})
    save('preflight-claim.json', {'at': now(), 'status': 'READ_ONLY_PREFLIGHT_CLAIMED',
         'wrapper_identity': identity.capture(os.getpid()), 'source_head': plan['expected_commit'],
         'root_review_pins_sha256': digest(WORK / 'root-review-pins.json'), 'syntax': syntax,
         'cluster_or_observer_launch_permitted': False})
    results = []
    for stem, script, expected in [('launch-preflight', 'launch.py', 0),
                                   ('observer-preflight', 'terminal_observer.py', 2),
                                   ('terminal-preflight', 'audit_terminal.py', 2)]:
        argv = [str(ROOT / '.venv/bin/python'), '-B', str(WORK / script), '--preflight']
        if script == 'audit_terminal.py':
            argv.pop()  # Immutable auditor needs no option; with no checkpoint it is pending.
        with (WORK / (stem + '.log')).open('x') as log:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT)
            save(stem + '-execution.json', {'at': now(), 'argv': argv,
                 'child_identity': identity.capture(child.pid), 'maximum_seconds': 120,
                 'command_sha256': hashlib.sha256(b'\0'.join(x.encode() for x in argv) + b'\0').hexdigest(),
                 'expected_exit': expected, 'no_fixture_initialization_or_launch': True})
            try:
                exit_code = child.wait(timeout=120)
            except subprocess.TimeoutExpired:
                save(stem + '-result.json', {'at': now(), 'status': 'TIMEOUT_INSPECT_CHILD_NO_RETRY',
                                             'child_pid': child.pid, 'signals_sent': False})
                return 1
        output = (WORK / (stem + '.log')).read_text()
        result = {'at': now(), 'exit_code': exit_code, 'expected_exit': expected,
                  'output_sha256': digest(WORK / (stem + '.log'))}
        save(stem + '-result.json', result)
        assert exit_code == expected, 'PREFLIGHT_UNEXPECTED_EXIT_' + stem
        parsed = json.loads(output)
        if stem == 'launch-preflight':
            assert parsed['status'] == 'READY_NOT_STARTED'
        elif stem == 'observer-preflight':
            assert parsed['reason'] == 'NEW_VERIFIED_LAUNCH_PENDING_NO_OBSERVER_STARTED'
        else:
            assert parsed['status'] == 'OBSERVATION_PENDING' and parsed['reason'] == 'CHECKPOINT_MISSING'
        results.append(dict(phase=stem, **result))
    assert digest(WORK / 'plan.json') == prepared_plan_sha, 'PREFLIGHT_CHANGED_LAUNCH_PLAN'
    assert not (WORK / 'pgdata').exists() and not Path(plan['socket']).exists()
    assert not (WORK / 'observation').exists() and not (WORK / 'launcher-start.json').exists()
    assert not (WORK / 'observer-launch-claim.json').exists() and not (WORK / 'observer-start.json').exists()
    public = ROOT / ('docs/acceptance/evidence/soak-24h-cash-20261020-' + plan['run_id'])
    for suffix in ('-launch.json', '-launch.log', '-terminal-review.json'):
        assert not Path(str(public) + suffix).exists()
    save('preflight-result.json', {'at': now(), 'status': 'ALL_READ_ONLY_PREPARATION_CHECKS_PASS',
         'run_id': plan['run_id'], 'phases': results, 'initialization_started': False,
         'runner_or_observer_started': False, 'prepared_plan_sha256': prepared_plan_sha})
    print(json.dumps({'status': 'ALL_READ_ONLY_PREPARATION_CHECKS_PASS', 'run_id': plan['run_id']}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
