"""Attach once to this NEW verified runner, freezing its validated receipt identity.

No scheduler, signals, runner launch, database operation, retry or cleanup.
"""
import json
import os
from pathlib import Path
import subprocess
import sys

from terminal_observer import ROOT, WORK, RUN_ID, LAUNCH, digest, now, preflight, require, save


def launch():
    require(sys.argv[1:] == ['--launch-reviewed'], 'EXPLICIT_REVIEWED_MODE_REQUIRED')
    receipt, identity, env = preflight()
    save('observer-launch-claim.json', {'at': now(), 'run_id': RUN_ID,
         'launcher_sha256': digest(Path(__file__)), 'runner_identity': identity,
         'acceptance_credit': False})
    save('observer-binding.json', {'at': now(), 'run_id': RUN_ID,
         'launch_receipt_sha256': digest(LAUNCH), 'running_plan_sha256': digest(WORK / 'plan.json'),
         'runner_identity': identity, 'postgres_identity': receipt['postgres_identity'],
         'identity_source': 'THIS_NEW_VALIDATED_RUNNING_VERIFIED_LAUNCH_RECEIPT_ONLY'})
    from process_identity import capture, matches
    require(matches(identity), 'BOUND_RUNNER_EXITED_BEFORE_OBSERVER_START')
    argv = [str(ROOT / '.venv/bin/python'), '-B', str(WORK / 'terminal_observer.py'), '--observe-once']
    with (WORK / 'observer-output.log').open('x') as log:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        save('observer-launch-execution.json', {'at': now(), 'status': 'OBSERVER_LAUNCHED_ONCE',
             'run_id': RUN_ID, 'argv': argv, 'observer_identity': capture(child.pid),
             'launcher_identity': capture(os.getpid()), 'observer_sha256': digest(WORK / 'terminal_observer.py'),
             'plan_sha256': digest(WORK / 'observer-plan.json'),
             'launch_binding_sha256': digest(WORK / 'observer-binding.json'),
             'no_runner_signal_restart_or_cleanup': True, 'acceptance_credit': False})
    print(json.dumps({'status': 'OBSERVER_LAUNCHED_ONCE', 'pid': child.pid, 'run_id': RUN_ID}))


if __name__ == '__main__':
    launch()
