"""Native process identity includes kernel boot, namespace and start ticks."""
import hashlib
import os
from pathlib import Path


def context():
    return {"boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
            "pid_namespace": os.readlink("/proc/self/ns/pid")}


def context_status(expected_boot_id, expected_namespace):
    actual = context()
    if actual["boot_id"] != expected_boot_id:
        return "BOOT_CHANGED"
    if actual["pid_namespace"] != expected_namespace:
        return "NATIVE_PROCESS_CONTEXT_REQUIRED"
    return "MATCH"


def require_context(expected_boot_id, expected_namespace):
    status = context_status(expected_boot_id, expected_namespace)
    if status != "MATCH":
        raise RuntimeError(status)


def capture(pid):
    if type(pid) is not int or pid <= 0:
        return None
    directory = Path(f"/proc/{pid}")
    try:
        stat = (directory / "stat").read_text()
        fields = stat[stat.rindex(")") + 2:].split()
        command = (directory / "cmdline").read_bytes()
        namespace = os.readlink(directory / "ns/pid")
    except (FileNotFoundError, ProcessLookupError):
        return None
    return {"pid": pid, "boot_id": context()["boot_id"], "pid_namespace": namespace,
            "start_ticks": int(fields[19]), "state": fields[0],
            "command_sha256": hashlib.sha256(command).hexdigest()}


def matches(record):
    if not isinstance(record, dict):
        return False
    actual = capture(record.get("pid"))
    if not actual or actual["state"] == "Z":
        return False
    return all(actual.get(field) == record.get(field) for field in
               ("pid", "boot_id", "pid_namespace", "start_ticks", "command_sha256"))
