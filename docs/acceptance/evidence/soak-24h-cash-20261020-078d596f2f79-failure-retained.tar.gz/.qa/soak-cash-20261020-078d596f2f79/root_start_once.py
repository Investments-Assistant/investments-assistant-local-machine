"""Durable root-reviewed launch receipts; no retries, signals or cleanup."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
BOOT = '34114b44-668d-4ba2-9480-91423bb4df0f'


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (WORK / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def main():
    assert sys.argv[1:] in (['--launch-soak-reviewed'], ['--attach-observer-reviewed'])
    assert not sys.flags.optimize
    assert ROOT == Path.cwd()
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == BOOT
    assert os.readlink('/proc/self/ns/pid') == 'pid:[4026532221]'
    assert os.readlink('/proc/self/ns/mnt') == 'mnt:[4026532219]'
    reviewed = json.loads((WORK / 'root-reviewed-launch.json').read_text())
    assert reviewed['status'] == 'ROOT_REVIEWED_FRESH_SYNTHETIC_WINDOW_READY'
    assert reviewed['root_wrapper_sha256'] == digest(Path(__file__))
    for name, expected in reviewed['helper_sha256'].items():
        assert Path(name).name == name and digest(WORK / name) == expected
    for name, expected in reviewed['interruption_proof_sha256'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert digest(ROOT / name) == expected
    mode = 'root-launch' if sys.argv[1] == '--launch-soak-reviewed' else 'root-observer-launch'
    script = 'launch.py' if mode == 'root-launch' else 'launch_observer.py'
    env = (dict(PATH='/usr/bin:/bin', LANG='C.UTF-8',
                PYTHONPATH=str(WORK) + ':' + str(ROOT), PYTHONDONTWRITEBYTECODE='1')
           if mode == 'root-launch'
           else json.loads((WORK / 'observer-plan.json').read_text())['clean_environment'])
    from process_identity import capture
    argv = [str(ROOT / '.venv/bin/python'), '-B', str(WORK / script), '--launch-reviewed']
    save(mode + '-claim.json', {'at': now(), 'mode': mode, 'argv': argv,
         'root_review_sha256': digest(WORK / 'root-reviewed-launch.json'),
         'no_retry_signals_cleanup_or_operator_actions': True})
    with (WORK / (mode + '-output.log')).open('x') as log:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True, close_fds=True)
        save(mode + '-execution.json', {'at': now(), 'argv': argv,
             'wrapper_identity': capture(os.getpid()), 'child_identity': capture(child.pid),
             'maximum_wait_seconds': 300, 'timeout_action': 'PRESERVE_CHILD_INSPECT_NO_SIGNAL_OR_RETRY'})
        try:
            code = child.wait(timeout=300)
        except subprocess.TimeoutExpired:
            save(mode + '-result.json', {'at': now(), 'status': 'WRAPPER_TIMEOUT_INSPECT_CHILD',
                 'child_identity': capture(child.pid), 'signals_sent': False, 'retry_performed': False})
            raise SystemExit(2)
    result = {'at': now(), 'status': 'CHILD_TERMINAL', 'exit_code': code,
              'mode': mode, 'output': str((WORK / (mode + '-output.log')).relative_to(ROOT))}
    save(mode + '-result.json', result)
    print(json.dumps(result))
    raise SystemExit(code)


if __name__ == '__main__':
    main()
