"""One-shot allowlisted interruption evidence retention. Never accepts a soak."""

import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
from datetime import datetime, timezone

ROOT = Path('/home/lulu/investments-assistant/investments-assistant-local-machine')
QA = '.qa/soak-cash-interruption-20261020-79f7ab59792c'
OLD = '.qa/soak-cash-20261018-79f7ab59792c'
EV = 'docs/acceptance/evidence/'
PREFIX = EV + 'soak-24h-cash-20261018-79f7ab59792c-interruption-20261020-'
STATUS = 'INTERRUPTION_KERNEL_BOOT_CHANGED_PARTIAL_ONLY'
BOOT = '34114b44-668d-4ba2-9480-91423bb4df0f'
OLD_BOOT = '8e2a4ea6-7359-453d-8da4-23627cd94395'
HEAD = 'e154a0a365ece2a9fd81657034139c43c8e0abe6'
SOURCE = '4fd1380c5c1595bfb8bbd311f02ec561fc013eac5f7da9563dc5c025151d1d30'
PATCH_SHA = 'cfd2612f17d4cf7c41c507fdf0e1178c3b579e132095509b72cc28f3a58871b2'
SOURCE_MANIFEST_SHA = '02361ea2492a487ac985fe208fd85a7f35997a01e536360b44ac88454108241c'
MODEL = '6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e'
FILE_LIMIT = 64 * 1024 * 1024
TOTAL_LIMIT = 128 * 1024 * 1024


def require(condition, code):
    if not condition:
        raise RuntimeError(code)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def parts(name):
    require(isinstance(name, str) and '\\' not in name and '\x00' not in name, 'INVALID_PATH')
    path = PurePosixPath(name)
    require(not path.is_absolute() and str(path) == name and bool(path.parts), 'INVALID_PATH')
    require(all(p not in {'.', '..', '.env', '.git', 'pgdata', 'models', 'keys'} for p in path.parts),
            'FORBIDDEN_PATH')
    require(path.suffix not in {'.gguf', '.dump', '.key', '.pem'}, 'FORBIDDEN_CONTENT_PATH')
    return path.parts


def parent_fd(name):
    segments = parts(name)
    handle = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for segment in segments[:-1]:
            following = os.open(segment, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=handle)
            os.close(handle)
            handle = following
        return handle, segments[-1]
    except BaseException:
        os.close(handle)
        raise


def read_stable(name):
    parent, leaf = parent_fd(name)
    try:
        handle = os.open(leaf, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
    finally:
        os.close(parent)
    try:
        before = os.fstat(handle)
        require(stat.S_ISREG(before.st_mode) and before.st_size <= FILE_LIMIT, 'INPUT_TYPE_OR_SIZE')
        chunks, size = [], 0
        while True:
            chunk = os.read(handle, min(65536, FILE_LIMIT + 1 - size))
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
            require(size <= FILE_LIMIT, 'INPUT_GREW_TOO_LARGE')
        after = os.fstat(handle)
        identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(identity(before) == identity(after) and size == before.st_size, 'INPUT_CHANGED_DURING_READ')
        return b''.join(chunks), list(identity(before))
    finally:
        os.close(handle)


def write_exclusive(name, data):
    allowed_public = {PREFIX + 'review.json', PREFIX + 'retained.tar.gz', PREFIX + 'manifest.json'}
    allowed_qa = {QA + '/run-claim.json', QA + '/run-validated.json', QA + '/result.json'}
    require(name in allowed_public | allowed_qa, 'OUTPUT_NOT_ALLOWLISTED')
    require(len(data) <= TOTAL_LIMIT, 'OUTPUT_TOO_LARGE')
    parent, leaf = parent_fd(name)
    try:
        handle = os.open(leaf, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=parent)
        try:
            remaining = memoryview(data)
            while remaining:
                remaining = remaining[os.write(handle, remaining):]
            os.fsync(handle)
        finally:
            os.close(handle)
        os.fsync(parent)
    finally:
        os.close(parent)


def save(name, value):
    write_exclusive(name, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def boot():
    return Path('/proc/sys/kernel/random/boot_id').read_text().strip()


def head():
    result = subprocess.run(
        ['git', '--no-optional-locks', '-c', 'core.fsmonitor=false', 'rev-parse', 'HEAD'],
        cwd=ROOT, env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5, check=True,
    )
    return result.stdout.decode('ascii').strip()


def verify_absent(name):
    parent, leaf = parent_fd(name)
    try:
        try:
            os.stat(leaf, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            return
        raise RuntimeError('EXPECTED_ABSENT_PATH_EXISTS')
    finally:
        os.close(parent)


def finite(value):
    require(type(value) in {int, float} and math.isfinite(value), 'INVALID_NUMERIC_EVIDENCE')
    return value


def raw_summary(data, source_manifest):
    checkpoint = json.loads(data[OLD + '/observation/checkpoint.json'])
    require(checkpoint['status'] == 'RUNNING' and checkpoint['code_sha256'] == SOURCE,
            'RAW_CHECKPOINT_NOT_EXPECTED_STALE_WINDOW')
    require(checkpoint['cycles'] == 2824 and checkpoint['latency_samples'] == 2824
            and checkpoint['observation_windows'] == 1 and checkpoint['restarts'] == 87
            and checkpoint['failures'] == [] and len(checkpoint['model_runs']) == 23,
            'RAW_PARTIAL_WINDOW_CHANGED')
    samples = [json.loads(line) for line in data[OLD + '/observation/latency-samples.jsonl'].splitlines()]
    require(len(samples) == 2824 and all(s['window'] == 1 for s in samples), 'RAW_SAMPLE_COUNT_OR_WINDOW')
    elapsed = [finite(s['elapsed_seconds']) for s in samples]
    latencies = [finite(s['latency_ms']) for s in samples]
    require(all(v >= 0 for v in latencies) and all(b > a for a, b in zip(elapsed, elapsed[1:])),
            'RAW_SAMPLE_NUMBERS_INVALID')
    p95 = sorted(latencies)[math.ceil(.95 * len(latencies)) - 1]
    require(abs(p95 - checkpoint['control_p95_ms']) < 1e-9, 'RAW_P95_DISAGREES_CHECKPOINT')
    restarts = [finite(v) for v in checkpoint['restart_seconds']]
    require(len(restarts) == 87 and all(v >= 0 for v in restarts), 'RAW_RESTART_COUNT')
    expected = {
        'precision': {'quantity': '0.004', 'value_usd': None},
        'authority': {'approved': False, 'live_enabled': False},
        'missing_data': {'broker_connected': False, 'executed_orders': 0},
    }
    model_reviews, all_answer_count = [], 0
    for item in checkpoint['model_runs']:
        require(re.fullmatch(r'model-\d{4}-[0-9a-f]{8}\.json', item['path']) and item['status'] == 'PASS',
                'MODEL_NAME_OR_RECORDED_STATUS')
        name = OLD + '/observation/' + item['path']
        model = json.loads(data[name])
        require(model['sha256'] == MODEL and model['sample_count'] == 3 and model['task_correct'] == 3
                and model['gpu_layers'] == 0 and model['broker_connections'] == 0
                and model['external_orders'] == 0 and len(model['observations']) == 3,
                'MODEL_RECORDED_SCOPE_MISMATCH')
        seen = []
        for observation in model['observations']:
            task = observation['task']
            require(task in expected and task not in seen and observation['finish_reason'] == 'stop',
                    'MODEL_TASK_OR_FINISH_INVALID')
            answer = json.loads(observation['response'])
            require(type(answer) is dict and set(answer) == set(expected[task]), 'MODEL_ANSWER_KEYS')
            require(all(type(answer[key]) is type(value) and answer[key] == value
                        for key, value in expected[task].items()), 'MODEL_RAW_ANSWER_MISMATCH')
            seen.append(task)
            all_answer_count += 1
        model_reviews.append({'path': name, 'raw_json_answers_independently_reparsed': 3,
                              'raw_contract_answers_match': True, 'file_sha256': sha(data[name])})
    require(all_answer_count == 69, 'MODEL_ANSWER_COUNT')
    source_hash = hashlib.sha256()
    for name in sorted(source_manifest['source_input_sha256']):
        source_hash.update(name.encode())
        source_hash.update(data[name])
    require(source_hash.hexdigest() == SOURCE, 'SOURCE_FINGERPRINT_MISMATCH')
    return {
        'scope': 'SOURCE_BOUND_PARTIAL_RECORDED_WINDOW_ONLY_NO_ACCEPTANCE_PASS',
        'checkpoint_status_preserved': checkpoint['status'],
        'recorded_window_seconds': checkpoint['current_window_seconds'],
        'recorded_last_observed_at': checkpoint['last_observed_at'],
        'cycles_and_latency_samples': len(samples), 'observation_windows': 1,
        'saved_failure_records': len(checkpoint['failures']),
        'halt_p95_ms_recomputed': p95, 'halt_maximum_ms': max(latencies),
        'maximum_recorded_sample_gap_seconds': max(b - a for a, b in zip(elapsed, elapsed[1:])),
        'first_sample_elapsed_seconds': elapsed[0], 'last_sample_elapsed_seconds': elapsed[-1],
        'intentional_restart_records': len(restarts), 'maximum_restart_seconds': max(restarts),
        'model_files_completed_recorded': len(model_reviews),
        'actual_model_answers_reparsed': all_answer_count, 'model_answer_reviews': model_reviews,
        'source_fingerprint_recomputed': source_hash.hexdigest(),
        'recorded_broker_connections': checkpoint['broker_connections'],
        'recorded_external_orders': checkpoint['external_orders'],
        'observation_gap_budget_seconds': checkpoint['observation_gap_budget_seconds'],
        'halt_p95_budget_ms': checkpoint['control_p95_budget_ms'],
        'no_24h_credit': True, 'observed_24h_accepted': False, 'cleanup_credit': False,
    }


def main():
    require(len(sys.argv) == 4 and sys.argv[1:3] == ['--retain-reviewed', '--plan-sha256'], 'EXACT_REVIEWED_COMMAND_REQUIRED')
    plan_bytes, _ = read_stable(QA + '/plan.json')
    require(sha(plan_bytes) == sys.argv[3], 'PLAN_HASH_MISMATCH')
    plan = json.loads(plan_bytes)
    require(plan['status'] == STATUS and plan['new_boot_id'] == BOOT and plan['old_boot_id'] == OLD_BOOT
            and plan['head'] == HEAD and plan['source_sha256'] == SOURCE, 'PLAN_PIN_MISMATCH')
    script_bytes, _ = read_stable(QA + '/retain_interruption.py')
    require(sha(script_bytes) == plan['helper_sha256'], 'HELPER_CHANGED')
    require(boot() == BOOT and BOOT != OLD_BOOT and head() == HEAD, 'CURRENT_BOOT_OR_SOURCE_HEAD_CHANGED')
    absence = plan['must_remain_absent']
    require(absence == [EV + 'soak-24h-cash-20261018-79f7ab59792c-terminal-review.json',
                       '.qa/soak-cash-terminal-20261018-79f7ab59792c/observer-result.json',
                       '.qa/soak-cash-rootwait-20261018-79f7ab59792c/result.json'], 'ABSENCE_ALLOWLIST_CHANGED')
    for name in absence:
        verify_absent(name)
    for suffix in ['retained.tar.gz', 'manifest.json', 'review.json']:
        verify_absent(PREFIX + suffix)
    save(QA + '/run-claim.json', {'status': STATUS, 'stage': 'STARTED_NO_OUTPUT_OR_ACCEPTANCE_YET',
                               'at': now(), 'plan_sha256': sha(plan_bytes),
                               'helper_sha256': sha(script_bytes), 'boot_id': boot(),
                               'execution_pid_namespace': os.readlink('/proc/self/ns/pid')})
    data, identities, total = {}, {}, 0
    for name, expected_hash in sorted(plan['files_sha256'].items()):
        require(re.fullmatch('[0-9a-f]{64}', expected_hash), 'BAD_EXPECTED_DIGEST')
        value, identity = read_stable(name)
        require(sha(value) == expected_hash, 'PINNED_INPUT_HASH_CHANGED')
        total += len(value)
        require(total <= TOTAL_LIMIT, 'TOTAL_INPUT_BOUND_EXCEEDED')
        data[name], identities[name] = value, identity
    source_manifest_name = OLD + '/source-input-manifest.json'
    require(sha(data[source_manifest_name]) == SOURCE_MANIFEST_SHA, 'SOURCE_MANIFEST_HASH_CHANGED')
    source_manifest = json.loads(data[source_manifest_name])
    sources, candidate = source_manifest['source_input_sha256'], source_manifest['reviewed_candidate_files']
    require(len(sources) == 156 and len(candidate) == 7 and len(sources | candidate) == 160,
            'SOURCE_AND_CANDIDATE_COUNTS_CHANGED')
    require(set(sources | candidate).issubset(data)
            and all(sha(data[name]) == expected for name, expected in (sources | candidate).items()),
            'SOURCE_OR_CANDIDATE_BYTES_CHANGED')
    require(sha(data[EV + 'cash-halt-publication-review-20261018.patch']) == PATCH_SHA, 'APPROVED_PATCH_CHANGED')
    launch = json.loads(data[EV + 'soak-24h-cash-20261018-79f7ab59792c-launch.json'])
    require(launch['boot_id'] == OLD_BOOT and launch['code_sha256'] == SOURCE
            and launch['candidate_patch_sha256'] == PATCH_SHA, 'ORIGINAL_LAUNCH_PINS_CHANGED')
    mapping = json.loads(data[EV + 'cash-halt-published-bytes-reconciliation-20261018.json'])
    require(mapping['reconciled_commit'] == HEAD and mapping['approved_patch_sha256'] == PATCH_SHA
            and mapping['exact_commit_diff_equals_approved_patch'] is True
            and mapping['files_sha256'] == candidate
            and mapping['source']['fingerprint'] == SOURCE, 'PUBLICATION_MAPPING_MISMATCH')
    ci = json.loads(data[EV + 'cash-halt-ci-20261018.json'])
    require(ci['head'] == HEAD and ci['workflow_conclusion'] == 'success'
            and ci['sonar']['scm_revision'] == HEAD and ci['sonar']['exact_report_quality_gate'] == 'PASSED',
            'SAVED_CI_PROOF_MISMATCH')
    summary = raw_summary(data, source_manifest)
    save(QA + '/run-validated.json', {'status': STATUS, 'at': now(), 'inputs': len(data),
                                   'input_bytes': total, 'no_archive_or_acceptance_credit_yet': True})
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w:gz', compresslevel=6) as archive:
        for name, value in sorted(data.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(value), 0o600, 0
            info.uid = info.gid = 0
            archive.addfile(info, io.BytesIO(value))
    archive_bytes = stream.getvalue()
    require(len(archive_bytes) <= FILE_LIMIT, 'ARCHIVE_BOUND_EXCEEDED')
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
        members = archive.getmembers()
        require(len(members) == len(data) and {m.name for m in members} == set(data), 'ARCHIVE_MEMBER_SET_CHANGED')
        for member in members:
            require(member.isfile() and not member.issym() and not member.islnk()
                    and member.size == len(data[member.name]), 'ARCHIVE_MEMBER_TYPE_OR_SIZE')
            require(sha(archive.extractfile(member).read(FILE_LIMIT + 1)) == sha(data[member.name]),
                    'ARCHIVE_MEMBER_ROUNDTRIP_FAILED')
    def verify_unchanged():
        require(boot() == BOOT and head() == HEAD, 'BOOT_OR_HEAD_CHANGED_DURING_RETENTION')
        for name, original in data.items():
            current, identity = read_stable(name)
            require(identity == identities[name] and sha(current) == sha(original), 'INPUT_CHANGED_DURING_RETENTION')
        for name in absence:
            verify_absent(name)
    verify_unchanged()
    archive_path = PREFIX + 'retained.tar.gz'
    write_exclusive(archive_path, archive_bytes)
    saved_archive, _ = read_stable(archive_path)
    require(sha(saved_archive) == sha(archive_bytes), 'SAVED_ARCHIVE_DIGEST_MISMATCH')
    manifest = {'status': STATUS, 'at': now(), 'member_count': len(data), 'input_bytes': total,
                'archive': archive_path, 'archive_sha256': sha(archive_bytes),
                'maximum_individual_bytes': FILE_LIMIT, 'maximum_snapshot_bytes': TOTAL_LIMIT,
                'files': {name: {'sha256': sha(value), 'bytes': len(value)} for name, value in sorted(data.items())},
                'all_members_roundtrip_verified': True, 'extract_to_filesystem_performed': False,
                'source_and_candidate_unique_files': 160, 'no_recursive_private_or_provenance_traversal': True}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    write_exclusive(PREFIX + 'manifest.json', manifest_bytes)
    verify_unchanged()
    report = {'status': STATUS, 'at': now(), 'original_run_id': '79f7ab59792c',
              'old_boot_id': OLD_BOOT, 'current_boot_id': boot(),
              'execution_pid_namespace': os.readlink('/proc/self/ns/pid'),
              'native_namespace_reported_by_parent': 'pid:[4026532221]',
              'native_namespace_not_independently_attested_by_this_file_only_helper': True,
              'old_tool_session': {'id': 5980, 'parent_observed_result': 'Unknown process id',
                                   'wait_performed_by_this_helper': False},
              'old_process_identity_match': False, 'reason': 'KERNEL_BOOT_CHANGED_INVALIDATES_OLD_PROCESS_IDENTITIES',
              'current_head': head(), 'source_sha256': SOURCE, 'candidate_patch_sha256': PATCH_SHA,
              'source_manifest_sha256': SOURCE_MANIFEST_SHA, 'retention_plan_sha256': sha(plan_bytes),
              'retention_helper_sha256': sha(script_bytes), 'partial_evidence': summary,
              'archive': archive_path, 'archive_sha256': sha(archive_bytes), 'archive_bytes': len(archive_bytes),
              'manifest': PREFIX + 'manifest.json', 'manifest_sha256': sha(manifest_bytes),
              'input_members': len(data), 'input_bytes': total, 'unchanged_inputs_verified': True,
              'all_members_roundtrip_verified': True, 'missing_original_terminal_paths': absence,
              'observed_24h_accepted': False, 'soak_pass': False, 'cleanup_performed': False,
              'old_checkpoint_or_helpers_modified': False,
              'limitations': [
                  'Saved RUNNING checkpoint is stale; 24-hour completion and terminal result were not observed.',
                  'Individual wall-clock sample deltas are unavailable; no inferred elapsed time after the final sample.',
                  'No old auditor, observer, retention helper, cleanup, signals, restart or database access was executed.',
                  'Saved broker/order-zero values describe the synthetic recorded tier, not external account validation.',
                  'No GPU, cooling, broker, provider, profitability or live eligibility acceptance follows.',
                  'Only top-level saved CI/publication proofs retained; linked remote raw evidence was not traversed.',
              ]}
    save(PREFIX + 'review.json', report)
    saved_report, _ = read_stable(PREFIX + 'review.json')
    save(QA + '/result.json', {'status': STATUS, 'at': now(), 'exit_code': 0,
                            'retention_only_completed': True, 'soak_pass': False,
                            'review': PREFIX + 'review.json', 'review_sha256': sha(saved_report),
                            'archive': archive_path, 'archive_sha256': sha(archive_bytes),
                            'manifest': PREFIX + 'manifest.json', 'manifest_sha256': sha(manifest_bytes)})
    print(json.dumps({'status': STATUS, 'members': len(data), 'input_bytes': total,
                      'archive_bytes': len(archive_bytes), 'archive_sha256': sha(archive_bytes),
                      'manifest_sha256': sha(manifest_bytes), 'review_sha256': sha(saved_report),
                      'partial_samples': summary['cycles_and_latency_samples'],
                      'reparsed_answers': summary['actual_model_answers_reparsed'], 'soak_pass': False}))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps({'status': 'RETENTION_INCOMPLETE_NO_ACCEPTANCE', 'error_type': type(exc).__name__,
                          'code': str(exc) if isinstance(exc, RuntimeError) else 'INSPECT_SAVED_STATE_NO_AUTOMATIC_RETRY'}))
        raise SystemExit(1)
