"""Coinbase Advanced Trade brokerage tool."""

from __future__ import annotations

from typing import Any

from src.security.errors import safe_exception_code
from src.agent.utils.logger import get_logger
from src.execution.external import disabled_external_write
from src.tools.broker_accounts import BrokerAccountConfig

logger = get_logger(__name__)


def _config(account: BrokerAccountConfig | None) -> dict:
    if account is None or not account.id or not account.user_id or account.broker != "coinbase":
        return {}
    return account.config


def _configured(account: BrokerAccountConfig | None = None) -> bool:
    config = _config(account)
    return bool(config.get("api_key") and config.get("api_secret"))


def _not_configured(account: BrokerAccountConfig | None = None) -> dict:
    return {"broker": "coinbase", "error": "Coinbase credentials are not configured"}


def _get_client(account: BrokerAccountConfig | None = None):
    from coinbase.rest import RESTClient

    config = _config(account)
    return RESTClient(api_key=config["api_key"], api_secret=config["api_secret"])


def get_coinbase_account(account: BrokerAccountConfig | None = None) -> dict:
    if not _configured(account):
        return _not_configured(account)
    try:
        client = _get_client(account)
        accounts = client.get_accounts()
        balances = []
        for acc in accounts.get("accounts", []):
            avail = acc.get("available_balance", {})
            hold = acc.get("hold", {})
            val = float(avail.get("value", 0))
            if val > 0.0001:
                balances.append(
                    {
                        "currency": avail.get("currency"),
                        "available": val,
                        "hold": float(hold.get("value", 0)),
                    }
                )
        return {"broker": "coinbase", "balances": balances}
    except Exception as exc:
        code = safe_exception_code(exc, fallback="COINBASE_ACCOUNT_UNAVAILABLE")
        logger.error("Coinbase account fetch failed: %s", code)
        return {"broker": "coinbase", "available": False, "error": code, "error_code": code}


def get_coinbase_positions(account: BrokerAccountConfig | None = None) -> list[dict]:
    """For Coinbase, positions = non-zero crypto holdings."""
    result = get_coinbase_account(account)
    if "error" in result:
        return [result]
    return result.get("balances", [])


def get_coinbase_orders(account: BrokerAccountConfig | None = None) -> list[dict]:
    if not _configured(account):
        return [_not_configured(account)]
    try:
        client = _get_client(account)
        resp = client.list_orders(order_status="FILLED")
        orders = resp.get("orders", [])
        return [
            {
                "order_id": o.get("order_id"),
                "product_id": o.get("product_id"),
                "side": o.get("side"),
                "order_type": o.get("order_type"),
                "filled_size": o.get("filled_size"),
                "average_filled_price": o.get("average_filled_price"),
                "status": o.get("status"),
                "created_time": o.get("created_time"),
            }
            for o in orders[:50]
        ]
    except Exception as exc:
        code = safe_exception_code(exc, fallback="COINBASE_ORDERS_UNAVAILABLE")
        logger.error("Coinbase orders fetch failed: %s", code)
        return [{"available": False, "error": code, "error_code": code}]


@disabled_external_write
def submit_coinbase_order(
    symbol: str,
    side: str,
    quantity: float,
    order_type: str = "market",
    limit_price: float | None = None,
    account: BrokerAccountConfig | None = None,
) -> dict:
    """
    symbol: Coinbase product ID, e.g. 'BTC-USD'
    side: 'buy' or 'sell'
    """
    if not _configured(account):
        return _not_configured(account)
    try:
        import uuid

        client = _get_client(account)
        client_order_id = str(uuid.uuid4())
        product_id = symbol.upper()

        config: dict[str, Any]
        if order_type == "market":
            if side.lower() == "buy":
                config = {"market_market_ioc": {"quote_size": str(quantity)}}
            else:
                config = {"market_market_ioc": {"base_size": str(quantity)}}
        elif order_type == "limit":
            if limit_price is None:
                return {"error": "limit_price required for limit orders"}
            config = {
                "limit_limit_gtc": {
                    "base_size": str(quantity),
                    "limit_price": str(limit_price),
                    "post_only": False,
                }
            }
        else:
            return {"error": f"Unsupported order type: {order_type}"}

        resp = client.create_order(
            client_order_id=client_order_id,
            product_id=product_id,
            side=side.upper(),
            order_configuration=config,
        )
        success = resp.get("success", False)
        return {
            "success": success,
            "order_id": resp.get("order_id") or resp.get("success_response", {}).get("order_id"),
            "product_id": product_id,
            "side": side,
            "error": "COINBASE_ORDER_REJECTED" if not success else None,
        }
    except Exception as exc:
        code = safe_exception_code(exc, fallback="COINBASE_SUBMISSION_UNAVAILABLE")
        logger.error("Coinbase order submission failed: %s", code)
        return {"success": False, "error": code, "error_code": code}


@disabled_external_write
def cancel_coinbase_order(
    order_id: str, account: BrokerAccountConfig | None = None
) -> dict:
    if not _configured(account):
        return _not_configured(account)
    try:
        client = _get_client(account)
        resp = client.cancel_orders(order_ids=[order_id])
        results = resp.get("results", [])
        if results:
            r = results[0]
            return {"success": r.get("success", False), "order_id": order_id}
        return {"success": False, "error": "No result returned"}
    except Exception as exc:
        code = safe_exception_code(exc, fallback="COINBASE_CANCELLATION_UNAVAILABLE")
        return {"success": False, "error": code, "error_code": code}
