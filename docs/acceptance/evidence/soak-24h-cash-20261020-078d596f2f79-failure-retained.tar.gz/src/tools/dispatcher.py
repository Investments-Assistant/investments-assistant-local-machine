"""Tool dispatcher — maps tool names to their Python implementations."""

from __future__ import annotations

import re
from copy import deepcopy
import json
import math
import time
import uuid
import asyncio
from decimal import Decimal, InvalidOperation
import inspect
import secrets
from datetime import UTC, datetime
from contextlib import contextmanager
from contextvars import ContextVar

from sqlalchemy import select, update

from src.config import settings
from src.db.models import Trade, DailyPnL, SimulationResult
from src.tools.nft import assess_nft_risk
from src.tools.news import search_market_news
from src.db.database import async_session
from src.tools.forex import get_forex_data, get_forex_rates, get_central_bank_rates
from src.tools.brokers import (
    ibkr as ibkr_tool,
    alpaca as alpaca_tool,
    binance as binance_tool,
    coinbase,
)
from src.security.errors import safe_exception_code
from src.tools.portfolio import get_account_info, get_trade_history, get_portfolio_summary
from src.tools.simulator import run_simulation_async
from src.tools.market_data import (
    search_ticker,
    get_stock_data,
    get_crypto_data,
    get_options_chain,
    get_market_overview,
    get_earnings_calendar,
    get_technical_indicators,
)
from src.tools.news_memory import get_latest_news, search_stored_news
from src.agent.utils.logger import get_logger
from src.operations.workloads import WorkloadBusy, market_read_work, broker_query_work
from src.tools.broker_accounts import (
    BrokerAccountConfig,
    BrokerVaultUnavailable,
    capability_unavailable,
    load_user_broker_accounts,
)

logger = get_logger(__name__)

_tool_session_id: ContextVar[str | None] = ContextVar("tool_session_id", default=None)
_tool_user_id: ContextVar[str | None] = ContextVar("tool_user_id", default=None)
_tool_trading_mode: ContextVar[str | None] = ContextVar("tool_trading_mode", default=None)
_pending_trade_proposals: dict[str, dict] = {}
_PROPOSAL_TTL_SECONDS = 15 * 60
_VALID_BROKERS = {"alpaca", "ibkr", "coinbase", "binance"}
_VALID_ORDER_TYPES = {"market", "limit", "stop_limit"}
_READ_TIMEOUT_SECONDS = 30


@contextmanager
def tool_context(
    session_id: str,
    user_id: str | None = None,
    trading_mode: str | None = None,
):
    """Attach the authenticated user and chat session to agent tool calls."""
    session_token = _tool_session_id.set(session_id)
    user_token = _tool_user_id.set(user_id)
    mode_token = _tool_trading_mode.set(trading_mode)
    try:
        yield
    finally:
        _tool_user_id.reset(user_token)
        _tool_session_id.reset(session_token)
        _tool_trading_mode.reset(mode_token)


async def dispatch_tool(tool_name: str, tool_input: dict) -> str:
    """Call the appropriate tool and return a JSON string result."""
    logger.info("Tool call: %s", tool_name if re.fullmatch(r"[a-z_]{1,64}", tool_name) else "invalid")
    try:
        if settings.is_production is True and _tool_user_id.get():
            from src.security.sessions import check_tool_authority
            await check_tool_authority(_tool_user_id.get())
        result = await _dispatch(tool_name, tool_input)
        if settings.is_production is True and _tool_user_id.get():
            await check_tool_authority(_tool_user_id.get())
    except WorkloadBusy as exc:
        code = safe_exception_code(exc, fallback="TOOL_BUSY", allowed_codes={"MARKET_READ_BUSY", "BROKER_QUERY_BUSY"})
        logger.warning("Tool admission rejected: %s", code)
        result = {"available": False, "error": code, "tool": tool_name}
    except TimeoutError:
        logger.warning("Tool request deadline exceeded")
        result = {"available": False, "error": "TOOL_TIMEOUT", "tool": tool_name}
    except Exception as exc:
        code = safe_exception_code(exc, fallback="TOOL_UNAVAILABLE")
        logger.error("Tool failed: %s", code)
        result = {"available": False, "error": code, "tool": tool_name}
    return json.dumps(result, default=str, ensure_ascii=False)


# Synchronous tools mapped by name to a callable that receives the raw input dict.
_SYNC_DISPATCH: dict[str, object] = {
    "get_stock_data": lambda inp: get_stock_data(**inp),
    "get_crypto_data": lambda inp: get_crypto_data(**inp),
    "get_forex_data": lambda inp: get_forex_data(**inp),
    "get_forex_rates": lambda inp: get_forex_rates(pairs=inp.get("pairs")),
    "get_central_bank_rates": lambda inp: get_central_bank_rates(currencies=inp.get("currencies")),
    "get_market_overview": lambda _: get_market_overview(),
    "get_technical_indicators": lambda inp: get_technical_indicators(**inp),
    "get_options_chain": lambda inp: get_options_chain(**inp),
    "search_ticker": lambda inp: search_ticker(**inp),
    "get_earnings_calendar": lambda inp: get_earnings_calendar(**inp),
    "search_market_news": lambda inp: search_market_news(**inp),
    "assess_nft_risk": lambda inp: assess_nft_risk(**inp),
}

# Async tools that can't live in _SYNC_DISPATCH (they are awaited in _dispatch)
_ASYNC_DISPATCH: dict[str, object] = {
    "search_stored_news": lambda inp: search_stored_news(**inp),
    "get_latest_news": lambda inp: get_latest_news(limit=inp.get("limit", 20)),
    # run_simulation is CPU-bound but needs async DB persistence afterward
    "run_simulation": lambda inp: _run_simulation_and_persist(inp),
}


async def _dispatch(name: str, inp: dict) -> object:
    if name in {"get_portfolio_summary", "get_account_info", "get_trade_history"}:
        return await _dispatch_broker_read(name, inp)
    if name in _SYNC_DISPATCH:
        # yfinance, broker SDKs, and PDF generation are synchronous.  Keep
        # them off FastAPI's event loop so one slow network call cannot freeze
        # the UI or the scheduler.
        return await market_read_work.arun(_SYNC_DISPATCH[name], inp, timeout=_READ_TIMEOUT_SECONDS)  # type: ignore[arg-type]
    if name in _ASYNC_DISPATCH:
        return await _ASYNC_DISPATCH[name](inp)  # type: ignore[operator]
    if name == "execute_trade":
        return await _execute_trade(inp)
    if name == "confirm_trade":
        return await _confirm_trade(inp)
    if name == "cancel_order":
        return await _cancel_order_for_user(inp)
    if name == "generate_report":
        return await _generate_report(inp)
    if name == "set_trading_mode":
        return await _set_trading_mode(inp["mode"])
    return {"error": f"Unknown tool: {name}"}


async def _load_current_user_accounts(
    broker: str | None = None,
    account_id: str | None = None,
) -> tuple[list[BrokerAccountConfig] | None, dict | None]:
    """Require explicit user ownership; never fall back to global credentials."""
    user_id = _tool_user_id.get()
    if not user_id:
        return None, {"blocked": True, "reason": "Authenticated user identity required."}
    try:
        return await load_user_broker_accounts(user_id, broker=broker, account_id=account_id), None
    except BrokerVaultUnavailable as exc:
        logger.warning("Broker vault unavailable (%s)", type(exc).__name__)
        return None, {
            "available": False,
            "capability": "brokerage access",
            "error": "BROKER_VAULT_UNAVAILABLE",
        }
    except Exception as exc:
        logger.error("Broker account lookup failed (%s)", type(exc).__name__)
        return None, {
            "available": False,
            "capability": "brokerage access",
            "error": "Brokerage account data is temporarily unavailable. Try again later.",
        }


async def _resolve_single_account(
    broker: str,
    account_id: str | None,
    capability: str,
) -> tuple[BrokerAccountConfig | None, dict | None]:
    """Resolve one account or return a safe, actionable model-facing result."""
    accounts, error = await _load_current_user_accounts(broker=broker, account_id=account_id)
    if error:
        return None, error
    if accounts is None:
        return None, None
    if not accounts:
        if account_id:
            return None, {
                "available": False,
                "broker": broker,
                "capability": capability,
                "error": (
                    "The requested brokerage account was not found or is inactive for this user."
                ),
            }
        return None, capability_unavailable(broker, capability)
    if len(accounts) > 1 and not account_id:
        return None, {
            "available": False,
            "broker": broker,
            "capability": capability,
            "account_id_required": True,
            "accounts": [account.public for account in accounts],
            "error": (
                f"More than one active {broker} account is configured. Ask the user to choose "
                "an account_id from the account list before continuing."
            ),
        }
    return accounts[0], None


async def _dispatch_broker_read(name: str, inp: dict) -> object:
    broker = str(inp.get("broker", "")).lower().strip() or None
    account_id = str(inp.get("account_id", "")).strip() or None
    if broker and broker not in _VALID_BROKERS:
        return {"error": f"Unknown broker: {broker}"}

    if name == "get_portfolio_summary":
        accounts, error = await _load_current_user_accounts(broker=broker, account_id=account_id)
        if error:
            return error
        if accounts is None:
            return await broker_query_work.arun(get_portfolio_summary, broker=broker, timeout=_READ_TIMEOUT_SECONDS)
        if not accounts:
            return capability_unavailable(broker or "any", "portfolio summary")
        return await broker_query_work.arun(
            get_portfolio_summary,
            broker=broker,
            accounts=accounts,
            timeout=_READ_TIMEOUT_SECONDS,
        )

    if not broker:
        return {"error": "broker is required for this account operation"}
    account, error = await _resolve_single_account(
        broker,
        account_id,
        "account information" if name == "get_account_info" else "trade history",
    )
    if error:
        return error
    if name == "get_account_info":
        return await broker_query_work.arun(
            get_account_info, broker=broker, account=account, timeout=_READ_TIMEOUT_SECONDS,
        )
    return await broker_query_work.arun(
        get_trade_history,
        broker=broker,
        days=inp.get("days", 30),
        account=account,
        timeout=_READ_TIMEOUT_SECONDS,
    )


# ── Daily loss-limit helpers ─────────────────────────────────────────────────


async def _is_daily_halted() -> bool:
    """Return True if auto-trading has been halted for today."""
    try:
        user_id = _tool_user_id.get()
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        user_filter = (
            DailyPnL.user_id == user_id
            if user_id
            else DailyPnL.user_id.is_(None)
        )
        async with async_session() as session:
            result = await session.execute(
                select(DailyPnL).where(
                    user_filter,
                    DailyPnL.date == today,
                )
            )
            record = result.scalar_one_or_none()
            if inspect.isawaitable(record):
                record = await record
            return bool(
                record is not None
                and getattr(record, "auto_trading_halted", False) is True
            )
    except Exception as exc:
        # A safety control must fail closed.  A temporary database outage must
        # never turn into permission to trade without a loss-limit check.
        logger.error("Failed to check daily halt flag; blocking auto-trading (%s)", type(exc).__name__)
        return True


async def _check_and_enforce_daily_limit(realized_delta_usd: float) -> None:
    """Update today's realized P&L and set halt flag if limit is breached."""
    try:
        user_id = _tool_user_id.get()
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        user_filter = (
            DailyPnL.user_id == user_id
            if user_id
            else DailyPnL.user_id.is_(None)
        )
        async with async_session() as session:
            result = await session.execute(
                select(DailyPnL).where(
                    user_filter,
                    DailyPnL.date == today,
                )
            )
            record = result.scalar_one_or_none()
            if record is None:
                record = DailyPnL(user_id=user_id, date=today, realized_usd=0.0)
                session.add(record)

            record.realized_usd = (record.realized_usd or 0.0) + realized_delta_usd

            if record.realized_usd < -abs(settings.auto_daily_loss_limit_usd):
                record.auto_trading_halted = True
                logger.warning(
                    "Daily loss limit breached (%.2f USD). Auto-trading halted for %s.",
                    record.realized_usd,
                    today,
                )

            await session.commit()
    except Exception as exc:
        logger.warning("Failed to update daily P&L (%s)", type(exc).__name__)


# ── Trade execution ──────────────────────────────────────────────────────────


def _validate_trade_input(inp: dict) -> tuple[dict | None, str | None]:
    """Validate and normalise an order before it reaches any broker SDK."""
    broker = str(inp.get("broker", "")).lower().strip()
    symbol = str(inp.get("symbol", "")).upper().strip()
    side = str(inp.get("side", "")).lower().strip()
    order_type = str(inp.get("order_type", "market")).lower().strip()
    try:
        quantity = float(str(inp.get("quantity")))
    except (TypeError, ValueError):
        quantity = 0.0
    if broker not in _VALID_BROKERS:
        return None, f"Unknown broker: {broker or 'missing'}"
    account_id = str(inp.get("account_id", "")).strip() or None
    if account_id and not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", account_id):
        return None, "Invalid account_id"
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9.\-/]{0,31}", symbol):
        return None, "Invalid symbol"
    if side not in {"buy", "sell"}:
        return None, "side must be 'buy' or 'sell'"
    if not math.isfinite(quantity) or quantity <= 0:
        return None, "quantity must be a positive finite number"
    if order_type not in _VALID_ORDER_TYPES:
        return None, f"Unsupported order type: {order_type}"

    def numeric(name: str) -> float | None:
        value = inp.get(name)
        if value is None or value == "":
            return None
        try:
            parsed = float(value)
        except (TypeError, ValueError):
            return None
        return parsed if math.isfinite(parsed) and parsed > 0 else None

    limit_price = numeric("limit_price")
    stop_price = numeric("stop_price")
    if order_type == "limit" and limit_price is None:
        return None, "limit_price is required for limit orders"
    if order_type == "stop_limit" and (limit_price is None or stop_price is None):
        return None, "limit_price and stop_price are required for stop_limit orders"

    asset_type = str(inp.get("asset_type", "")).lower().strip()
    if not asset_type:
        has_option_fields = any(
            inp.get(field) not in (None, "")
            for field in ("option_expiry", "option_strike", "option_right")
        )
        if has_option_fields:
            asset_type = "option"
        elif broker == "ibkr" and re.fullmatch(r"[A-Z]{3}[/-]?[A-Z]{3}", symbol):
            asset_type = "forex"
        else:
            asset_type = "stock"
    if asset_type not in {"stock", "etf", "option", "forex", "crypto"}:
        return None, f"Unsupported asset_type: {asset_type}"
    if asset_type in {"option", "forex"} and broker != "ibkr":
        return None, f"{asset_type} orders require broker='ibkr'"
    if asset_type == "crypto" and broker not in {"coinbase", "binance"}:
        return None, "crypto orders require broker='coinbase' or broker='binance'"

    option_expiry = str(inp.get("option_expiry", "")).strip()
    option_right = str(inp.get("option_right", "")).upper().strip()
    option_strike = numeric("option_strike")
    if asset_type == "option":
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", option_expiry):
            return None, "option_expiry must use YYYY-MM-DD format"
        try:
            datetime.strptime(option_expiry, "%Y-%m-%d")
        except ValueError:
            return None, "option_expiry must be a valid calendar date"
        if option_strike is None:
            return None, "option_strike must be a positive finite number"
        if option_right not in {"C", "P"}:
            return None, "option_right must be 'C' or 'P'"
    elif any(
        inp.get(field) not in (None, "")
        for field in ("option_expiry", "option_strike", "option_right")
    ):
        return None, "option fields are only valid when asset_type='option'"

    estimated_notional = inp.get("estimated_notional_usd")
    if estimated_notional not in (None, ""):
        try:
            estimated_notional = float(str(estimated_notional))
        except (TypeError, ValueError):
            return None, "estimated_notional_usd must be a positive finite number"
        if not math.isfinite(estimated_notional) or estimated_notional <= 0:
            return None, "estimated_notional_usd must be a positive finite number"
    return {
        "broker": broker,
        "account_id": account_id,
        "symbol": symbol,
        "asset_type": asset_type,
        "side": side,
        "quantity": quantity,
        "order_type": order_type,
        "limit_price": limit_price,
        "stop_price": stop_price,
        "option_expiry": option_expiry or None,
        "option_strike": option_strike,
        "option_right": option_right or None,
        "reason": str(inp.get("reason", "")).strip()[:2_000],
        "estimated_notional_usd": estimated_notional,
    }, None


def _setting_number(name: str, default: float) -> float:
    try:
        value = float(getattr(settings, name))
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


def _live_route_allowed(broker: str, account: BrokerAccountConfig | None = None) -> bool:
    """External execution is unavailable until independently accepted and authorized.

    A boolean setting or network port cannot attest to an account environment.
    Simulator execution uses its own isolated ledger, never a broker SDK.
    """
    return False


def _auto_notional_ok(trade: dict) -> tuple[bool, str | None]:
    """Reject excessive lower-bound limit notionals; this never grants authority.

    Legacy callers lack qualified quotes/FX. This preliminary check can reject
    risk but cannot authorize a broker write. Caller estimates are ignored.
    """
    if trade.get("order_type") not in {"limit", "stop_limit"}:
        return False, "A trusted priced order is required; market orders are not authorized."
    try:
        quantity = Decimal(str(trade.get("quantity")))
        price = Decimal(str(trade.get("limit_price")))
        cap = Decimal(str(settings.auto_max_trade_usd))
        values = (quantity, price, cap)
        if any(not value.is_finite() or value <= 0 for value in values):
            raise ValueError("Invalid risk input")
        notional = quantity * price
        if notional > cap:
            return False, "Order notional exceeds the configured cap."
    except (InvalidOperation, ValueError, TypeError):
        return False, "Finite positive quantity, price and risk cap required."
    return False, "Qualified contract, quote, multiplier and dated FX required for authorization."


def _remember_proposal(trade: dict) -> str:
    now = time.time()
    for proposal_id, proposal in list(_pending_trade_proposals.items()):
        if proposal["expires_at"] <= now:
            _pending_trade_proposals.pop(proposal_id, None)
    proposal_id = secrets.token_urlsafe(18)
    _pending_trade_proposals[proposal_id] = {
        "session_id": _tool_session_id.get(),
        "user_id": _tool_user_id.get(),
        "trade": deepcopy(trade),
        "expires_at": now + _PROPOSAL_TTL_SECONDS,
    }
    return proposal_id


async def _create_trade_intent(trade: dict, mode: str) -> str | None:
    """Persist an auditable pending intent before contacting a broker.

    A broker order should never be submitted when the audit database is down.
    The follow-up update can still fail after a broker accepts an order, so
    that condition is reported loudly rather than pretending the audit trail
    is complete.
    """
    intent_id = str(uuid.uuid4())
    try:
        async with async_session() as session:
            added = session.add(
                Trade(
                    id=intent_id,
                    broker=trade["broker"],
                    symbol=trade["symbol"],
                    side=trade["side"],
                    quantity=trade["quantity"],
                    price=trade.get("limit_price"),
                    order_type=trade["order_type"],
                    status="pending",
                    mode=mode,
                    user_id=_tool_user_id.get(),
                    broker_account_id=trade.get("account_id"),
                    reason=trade.get("reason", ""),
                )
            )
            if inspect.isawaitable(added):
                await added
            await session.commit()
        return intent_id
    except Exception as exc:
        logger.error("Trade intent was not persisted; order was not sent (%s)", type(exc).__name__)
        return None


async def _finalize_trade_intent(intent_id: str, result: dict) -> bool:
    """Update the pre-trade intent with the broker response."""
    try:
        status = result.get("status") or ("rejected" if "error" in result else "submitted")
        async with async_session() as session:
            await session.execute(
                update(Trade)
                .where(Trade.id == intent_id)
                .values(
                    status=status,
                    broker_order_id=result.get("order_id"),
                    price=result.get("filled_avg_price"),
                )
            )
            await session.commit()
        return True
    except Exception as exc:
        logger.error("Trade audit finalization failed (%s)", type(exc).__name__)
        return False


async def _execute_validated_trade(
    trade: dict,
    mode: str,
    account: BrokerAccountConfig | None = None,
) -> dict:
    if not _live_route_allowed(trade["broker"], account):
        return {
            "blocked": True,
            "reason": (
                "Live broker routing is disabled. Enable LIVE_TRADING_ENABLED only after "
                "paper/testnet validation and an explicit risk review."
            ),
        }
    intent_id = await _create_trade_intent(trade, mode)
    if intent_id is None:
        return {
            "blocked": True,
            "reason": "Trade audit database is unavailable; the order was not sent.",
        }
    try:
        route_args = (
            trade["broker"],
            trade["symbol"],
            trade["side"],
            trade["quantity"],
            trade["order_type"],
            trade.get("limit_price"),
            trade.get("stop_price"),
            trade.get("asset_type"),
            trade.get("option_expiry"),
            trade.get("option_strike"),
            trade.get("option_right"),
        )
        if account is None:
            result = await asyncio.to_thread(_route_order, *route_args)
        else:
            result = await asyncio.to_thread(_route_order, *route_args, account=account)
    except Exception as exc:
        logger.error("Broker route failed (%s)", type(exc).__name__)
        result = {"error": "BROKER_ROUTE_UNAVAILABLE"}
    result["reason"] = trade.get("reason", "")
    result["audit_intent_id"] = intent_id
    if not await _finalize_trade_intent(intent_id, result):
        result["audit_warning"] = "Broker response received, but database finalization failed."
    realized = result.get("realized_pnl_usd", result.get("pnl_usd"))
    try:
        if realized is not None and math.isfinite(float(realized)):
            await _check_and_enforce_daily_limit(float(realized))
    except (TypeError, ValueError):
        logger.warning("Ignoring invalid realized P&L returned by broker")
    return result


async def _execute_trade(inp: dict) -> dict:
    trade, error = _validate_trade_input(inp)
    if error or trade is None:
        return {"blocked": True, "reason": error}

    account, account_error = await _resolve_single_account(
        trade["broker"],
        trade.get("account_id"),
        "trade execution",
    )
    if account_error:
        return account_error

    trading_mode = _tool_trading_mode.get() or settings.trading_mode
    if trading_mode == "recommend":
        confirmation_id = _remember_proposal(trade)
        return {
            "status": "pending_confirmation",
            "message": (
                f"RECOMMENDATION: {trade['side'].upper()} {trade['quantity']} {trade['symbol']} "
                f"via {trade['broker']} ({trade['order_type']} order). "
                f"Reason: {trade['reason']}. Reply with the confirmation ID and explicit approval."
            ),
            "confirmation_id": confirmation_id,
            "trade_details": trade,
        }

    # AUTO mode — check safety guards before executing
    if (
        settings.auto_allowed_symbols_set
        and trade["symbol"] not in settings.auto_allowed_symbols_set
    ):
        return {
            "blocked": True,
            "reason": f"{trade['symbol']} is not in the auto-trading allowed symbols list.",
        }

    if await _is_daily_halted():
        return {
            "blocked": True,
            "reason": (
                f"Auto-trading is halted for today: daily loss limit of "
                f"{settings.auto_daily_loss_limit_usd} USD has been reached."
            ),
        }
    notional_ok, notional_error = _auto_notional_ok(trade)
    if not notional_ok:
        return {"blocked": True, "reason": notional_error}
    return await _execute_validated_trade(trade, "auto", account)


async def _confirm_trade(inp: dict) -> dict:
    """A tool call, including a same-session token, is not a human approval."""
    return {
        "blocked": True,
        "reason": ("Independent authenticated human approval is required; "
                   "tool confirmation is disabled."),
        "reason_code": "HUMAN_APPROVAL_REQUIRED",
    }


def _route_order(
    broker: str,
    symbol: str,
    side: str,
    quantity: float,
    order_type: str,
    limit_price: float | None,
    stop_price: float | None,
    asset_type: str | None = None,
    option_expiry: str | None = None,
    option_strike: float | None = None,
    option_right: str | None = None,
    account: BrokerAccountConfig | None = None,
) -> dict:
    if not _live_route_allowed(broker, account):
        return {"blocked": True, "reason": "External broker execution is not authorized."}
    if broker == "alpaca":
        if account is None:
            return alpaca_tool.submit_alpaca_order(
                symbol, side, quantity, order_type, limit_price, stop_price
            )
        return alpaca_tool.submit_alpaca_order(
            symbol, side, quantity, order_type, limit_price, stop_price, account=account
        )
    if broker == "ibkr":
        if account is None:
            return ibkr_tool.submit_ibkr_order(
                symbol,
                side,
                quantity,
                order_type,
                limit_price,
                stop_price,
                asset_type=asset_type,
                option_expiry=option_expiry,
                option_strike=option_strike,
                option_right=option_right,
            )
        return ibkr_tool.submit_ibkr_order(
            symbol,
            side,
            quantity,
            order_type,
            limit_price,
            stop_price,
            asset_type=asset_type,
            option_expiry=option_expiry,
            option_strike=option_strike,
            option_right=option_right,
            account=account,
        )
    if broker == "coinbase":
        if account is None:
            return coinbase.submit_coinbase_order(
                symbol, side, quantity, order_type, limit_price
            )
        return coinbase.submit_coinbase_order(
            symbol, side, quantity, order_type, limit_price, account=account
        )
    if broker == "binance":
        if account is None:
            return binance_tool.submit_binance_order(
                symbol, side, quantity, order_type, limit_price
            )
        return binance_tool.submit_binance_order(
            symbol, side, quantity, order_type, limit_price, account=account
        )
    return {"error": f"Unknown broker: {broker}"}


def _cancel_order(inp: dict, account: BrokerAccountConfig | None = None) -> dict:
    if not _live_route_allowed(inp.get("broker", ""), account):
        return {"blocked": True, "reason": "External order cancellation is not authorized."}
    broker = inp["broker"]
    order_id = inp["order_id"]
    if broker == "alpaca":
        return (
            alpaca_tool.cancel_alpaca_order(order_id)
            if account is None
            else alpaca_tool.cancel_alpaca_order(order_id, account=account)
        )
    if broker == "ibkr":
        return (
            ibkr_tool.cancel_ibkr_order(order_id)
            if account is None
            else ibkr_tool.cancel_ibkr_order(order_id, account=account)
        )
    if broker == "coinbase":
        return (
            coinbase.cancel_coinbase_order(order_id)
            if account is None
            else coinbase.cancel_coinbase_order(order_id, account=account)
        )
    if broker == "binance":
        return (
            binance_tool.cancel_binance_order(order_id)
            if account is None
            else binance_tool.cancel_binance_order(order_id, account=account)
        )
    return {"error": f"Unknown broker: {broker}"}


async def _cancel_order_for_user(inp: dict) -> dict:
    broker = str(inp.get("broker", "")).lower().strip()
    if broker not in _VALID_BROKERS:
        return {"error": f"Unknown broker: {broker or 'missing'}"}
    account, error = await _resolve_single_account(
        broker,
        str(inp.get("account_id", "")).strip() or None,
        "order cancellation",
    )
    if error:
        return error
    normalized_input = {**inp, "broker": broker}
    return await asyncio.to_thread(_cancel_order, normalized_input, account)


async def _set_trading_mode(mode: str) -> dict:
    return {
        "blocked": True,
        "reason": "Tools cannot change trading authority. Use an independently approved mandate.",
        "reason_code": "OPERATOR_AUTHORITY_REQUIRED",
    }


async def _generate_report(inp: dict) -> dict:
    from src.scheduler.reporter import generate_report

    return await generate_report(
        period_start=inp["period_start"],
        period_end=inp.get("period_end"),
    )


# ── Simulation with DB persistence ──────────────────────────────────────────


async def _run_simulation_and_persist(inp: dict) -> dict:
    """Run a backtest simulation and persist the result to the DB."""
    result = await run_simulation_async(**inp)
    if "error" in result:
        return result

    try:
        async with async_session() as session:
            sim = SimulationResult(
                user_id=_tool_user_id.get(),
                name=result["name"],
                strategy=result["strategy"],
                initial_capital=result["initial_capital"],
                final_value=result["final_value"],
                total_return_pct=result.get("total_return_pct", 0.0),
                sharpe_ratio=result.get("sharpe_ratio"),
                max_drawdown_pct=result.get("max_drawdown_pct"),
                trades_count=result["trades_count"],
                period_start=result["period_start"],
                period_end=result["period_end"],
                equity_curve=result["equity_curve"],
            )
            session.add(sim)
            await session.commit()
            result["simulation_id"] = sim.id
            logger.info("Simulation '%s' persisted (id=%s)", sim.name, sim.id)
    except Exception as exc:
        logger.warning("Failed to persist simulation result: %s", type(exc).__name__)
        result["status"] = "partial_failure"
        result["persistence_error"] = "Simulation calculated but not persisted."

    return result
