"""Portfolio aggregator — combines holdings across all brokers."""

from __future__ import annotations

from decimal import Decimal, localcontext

from src.tools.brokers import (
    ibkr as ibkr_tool,
    alpaca as alpaca_tool,
    binance as binance_tool,
    coinbase,
)
from src.security.errors import safe_exception_code
from src.agent.utils.logger import get_logger
from src.finance.normalization import usd_decimal_value
from src.tools.broker_accounts import BrokerAccountConfig

logger = get_logger(__name__)

_SAFE_BROKER_ERRORS = frozenset({
    "ALPACA_ACCOUNT_UNAVAILABLE", "ALPACA_POSITIONS_UNAVAILABLE", "ALPACA_ORDERS_UNAVAILABLE",
    "COINBASE_ACCOUNT_UNAVAILABLE", "COINBASE_ORDERS_UNAVAILABLE",
    "BINANCE_ACCOUNT_UNAVAILABLE", "BINANCE_ORDERS_UNAVAILABLE",
    "AUTHENTICATED_ACCOUNT_REQUIRED", "IBKR_READ_CONSENT_REQUIRED",
    "EXPLICIT_BROKER_ACCOUNT_AND_ENVIRONMENT_REQUIRED", "DEDICATED_NONZERO_CLIENT_ID_REQUIRED",
    "BROKER_ACCOUNT_NOT_MANAGED", "IBKR_CLIENT_BUSY", "IBKR_SYNC_ADAPTER_REQUIRES_WORKER_THREAD",
    "INCOMPLETE_CONTRACT", "AMBIGUOUS_CONTRACT", "CONTRACT_MISMATCH",
    "AMBIGUOUS_CONTRACT_DETAILS", "CONTRACT_PRECISION_UNAVAILABLE",
    "IBKR_SESSION_CONFIGURATION_CHANGED", "IBKR_SESSION_STOPPING", "IBKR_SESSION_NOT_READY",
    "IBKR_READ_QUEUE_FULL", "IBKR_READ_UNAVAILABLE",
})


def _safe_read_error(value: dict, fallback: str) -> str:
    return safe_exception_code(
        RuntimeError(value.get("error_code", value.get("error"))),
        fallback=fallback, allowed_codes=_SAFE_BROKER_ERRORS,
    )


def _enrich_position(pos: dict, symbol_key: str = "symbol") -> dict:
    """Add current market price to a position if not already present."""
    import yfinance as yf

    sym = pos.get(symbol_key)
    if not sym or pos.get("current_price"):
        return pos
    try:
        ticker = yf.Ticker(sym)
        info = ticker.info or {}
        pos["current_price"] = info.get("regularMarketPrice") or info.get("currentPrice")
    except Exception:
        pass
    return pos


_BROKER_FUNNELS = [
    ("alpaca", alpaca_tool.get_alpaca_positions, alpaca_tool.get_alpaca_account),
    ("ibkr", ibkr_tool.get_ibkr_positions, ibkr_tool.get_ibkr_account),
    ("coinbase", coinbase.get_coinbase_positions, coinbase.get_coinbase_account),
    ("binance", binance_tool.get_binance_positions, binance_tool.get_binance_account),
]


def _call_for_account(fn, account: BrokerAccountConfig | None):
    """Call legacy broker functions without changing their no-argument API."""
    return fn() if account is None else fn(account=account)


def _collect_broker(
    name: str,
    positions_fn,
    account_fn,
    result: dict,
    account: BrokerAccountConfig | None = None,
) -> None:
    """Fetch positions and account info for one broker, accumulating into result."""
    result.setdefault("errors", [])
    context = {
        "broker": name,
        "account_id": account.id if account else None,
        "account_name": account.display_name if account else None,
    }
    try:
        acc = _call_for_account(account_fn, account)
        if "error" not in acc:
            if account:
                acc["account_id"] = account.id
                acc["account_name"] = account.display_name
            result["accounts"].append(acc)
        else:
            code = _safe_read_error(acc, "BROKER_ACCOUNT_UNAVAILABLE")
            result["errors"].append({**context, "error": code, "error_code": code})
        positions = _call_for_account(positions_fn, account)
        for p in positions:
            if "error" not in p:
                p["broker"] = name
                if account:
                    p["account_id"] = account.id
                    p["account_name"] = account.display_name
                result["positions"].append(p)
                for target, source_value in (
                    ("total_market_value_usd", p.get("market_value")),
                    ("total_unrealized_pnl_usd", p.get("unrealized_pnl", p.get("unrealized_pl"))),
                ):
                    exact_target = target + "_exact"
                    value = usd_decimal_value(source_value, p)
                    if value is None:
                        result[target] = None
                        result[exact_target] = None
                        result["valuation_status"] = "partial"
                    elif result.get(target) is not None:
                        with localcontext() as ctx:
                            ctx.prec = 100
                            total = Decimal(str(result.get(exact_target, result[target]))) + value
                        result[exact_target] = str(total)
                        result[target] = float(total)
            else:
                error = _safe_read_error(p, "BROKER_POSITIONS_UNAVAILABLE")
                if not any(
                    item["broker"] == name
                    and item.get("account_id") == context["account_id"]
                    and item["error"] == error
                    for item in result["errors"]
                ):
                    result["errors"].append({**context, "error": error, "error_code": error})
    except Exception as exc:
        code = safe_exception_code(exc, fallback="BROKER_READ_UNAVAILABLE")
        logger.warning("%s portfolio fetch failed: %s", name, code)
        result["errors"].append({**context, "error": code, "error_code": code})


def get_portfolio_summary(
    broker: str | None = None,
    accounts: list[BrokerAccountConfig] | None = None,
) -> dict:
    """Aggregate positions across all (or a specific) broker/account."""
    result: dict = {
        "positions": [],
        "accounts": [],
        "errors": [],
        "total_market_value_usd": 0.0,
        "total_unrealized_pnl_usd": 0.0,
        "total_market_value_usd_exact": "0",
        "total_unrealized_pnl_usd_exact": "0",
    }
    if accounts is None:
        result["errors"].append({"error": "AUTHENTICATED_ACCOUNT_REQUIRED"})
    else:
        functions = {name: (pos_fn, acc_fn) for name, pos_fn, acc_fn in _BROKER_FUNNELS}
        for account in accounts:
            if broker is not None and broker != account.broker:
                continue
            pos_fn, acc_fn = functions[account.broker]
            _collect_broker(account.broker, pos_fn, acc_fn, result, account)
    if result["errors"]:
        result["valuation_status"] = "partial"
        result["total_market_value_usd"] = None
        result["total_unrealized_pnl_usd"] = None
        result["total_market_value_usd_exact"] = None
        result["total_unrealized_pnl_usd_exact"] = None
    else:
        result.setdefault("valuation_status", "complete")
    return result


def get_account_info(broker: str, account: BrokerAccountConfig | None = None) -> dict:
    if account is None or account.broker != broker or not account.user_id or not account.id:
        return {"error": "AUTHENTICATED_ACCOUNT_REQUIRED"}
    dispatch = {
        "alpaca": alpaca_tool.get_alpaca_account,
        "ibkr": ibkr_tool.get_ibkr_account,
        "coinbase": coinbase.get_coinbase_account,
        "binance": binance_tool.get_binance_account,
    }
    fn = dispatch.get(broker)
    if not fn:
        return {"error": f"Unknown broker: {broker}"}
    return _call_for_account(fn, account)


def get_trade_history(broker: str, days: int = 30, account: BrokerAccountConfig | None = None) -> list[dict]:
    if account is None or account.broker != broker or not account.user_id or not account.id:
        return [{"error": "AUTHENTICATED_ACCOUNT_REQUIRED"}]
    if broker == "alpaca":
        return alpaca_tool.get_alpaca_orders(days, account=account) if account else alpaca_tool.get_alpaca_orders(days)
    if broker == "ibkr":
        return ibkr_tool.get_ibkr_orders(account=account) if account else ibkr_tool.get_ibkr_orders()
    if broker == "coinbase":
        return coinbase.get_coinbase_orders(account=account) if account else coinbase.get_coinbase_orders()
    if broker == "binance":
        return binance_tool.get_binance_orders(account=account) if account else binance_tool.get_binance_orders()
    return [{"error": f"Unknown broker: {broker}"}]
