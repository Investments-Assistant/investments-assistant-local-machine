"""Central application configuration via pydantic-settings (reads from .env)."""

from __future__ import annotations

import base64
from typing import Literal
import binascii
from functools import lru_cache
import ipaddress
from contextlib import suppress

from pydantic import Field, computed_field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ────────────────────────────────────────────────────────────
    environment: Literal["development", "production"] = "production"
    log_level: str = "INFO"
    app_host: str = "0.0.0.0"
    app_port: int = 8000

    # ── Security ───────────────────────────────────────────────────────────────
    allowed_ips: str = (
        "10.8.0.0/24"  # NOSONAR — private WireGuard VPN subnet; override via ALLOWED_IPS env var
    )
    # Nginx is the only public entry point in the Compose deployment.  Keep
    # proxy headers enabled there, but make the trust decision explicit so a
    # future direct deployment does not accidentally trust user-supplied XFF.
    trust_proxy_headers: bool = True
    trusted_proxy_ips: str = "127.0.0.1/32,::1/128"

    # Browser authentication.  Passwords are stored as scrypt hashes generated
    # by scripts/create_auth_hash.py; the clear-text password is never needed by
    # the application process.
    auth_username: str = "admin"
    # Optional literal UTF-8 transport for dotenv/Compose. Both parsers support
    # base64 ASCII, while their quoting/interpolation rules differ for ${...}.
    auth_username_base64: str | None = Field(None, repr=False, exclude=True)
    auth_password_hash: str = ""
    auth_session_secret: str = ""
    auth_session_ttl_minutes: int = Field(480, ge=5, le=7 * 24 * 60)
    auth_require_login: bool = True
    auth_cookie_secure: bool = True
    auth_allow_signup: bool = True
    max_chat_message_chars: int = Field(8_000, ge=1_000, le=32_000)

    @model_validator(mode="after")
    def literal_auth_username(self):
        if self.auth_username_base64 is not None:
            try:
                self.auth_username = base64.b64decode(
                    self.auth_username_base64, validate=True,
                ).decode("utf-8")
            except (binascii.Error, UnicodeError, ValueError) as exc:
                raise ValueError("AUTH_USERNAME_BASE64 must encode a literal UTF-8 login ID") from exc
        if not self.auth_username or "\x00" in self.auth_username:
            raise ValueError("A nonempty login ID without NUL is required")
        return self
    # Fernet key used to encrypt per-user brokerage credentials at rest.
    # Generate with scripts/create_broker_key.py and keep it outside the DB.
    broker_credentials_key: str = ""

    # Optional, separately scoped access for the local MCP bridge.  It is off
    # by default because the browser UI is the primary control surface.
    # External bank API access requires a separate operator decision and bank consent.
    bank_sync_enabled: bool = False
    bank_credentials_key: str = Field("", repr=False)
    gocardless_secret_id: str = Field("", repr=False)
    gocardless_secret_key: str = Field("", repr=False)
    bank_consent_redirect: str = ""
    bank_sync_interval_seconds: int = Field(21600, ge=900, le=86400)

    mcp_enabled: bool = False
    mcp_auth_token: str = ""
    mcp_user_id: str = ""  # Explicit local account binding; no bootstrap fallback.

    @computed_field  # type: ignore[prop-decorator]
    @property
    def allowed_networks(self) -> list[ipaddress.IPv4Network | ipaddress.IPv6Network]:
        networks = []
        for entry in self.allowed_ips.split(","):
            entry = entry.strip()
            if not entry:
                continue
            with suppress(ValueError):
                networks.append(ipaddress.ip_network(entry, strict=False))
        return networks

    def is_ip_allowed(self, ip: str) -> bool:
        """Return True if *ip* matches any configured CIDR / host entry."""
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return False
        return any(addr in net for net in self.allowed_networks)

    # ── LLM backend (local GGUF via llama.cpp — no external APIs) ─────────────
    # Qwen 7B Q4_K_M is currently distributed as two GGUF shards. The
    # downloader prints this first-shard path after fetching both files.
    llm_model_path: str = "/app/models/qwen2.5-1.5b-instruct-q4_k_m.gguf"
    # The full local tool catalog plus the system prompt needs more than 4096
    # tokens before conversation history is added. Reduce this only when using
    # a smaller tool catalog or model configuration.
    llm_context_size: int = 4096
    llm_queue_capacity: int = Field(4, ge=1, le=16)
    llm_queue_wait_seconds: float = Field(15, gt=0, le=120)
    llm_inference_timeout_seconds: float = Field(120, gt=0, le=600)
    # GPU layers to offload: 0 = CPU only (Pi 5 has no GPU), -1 = all to GPU.
    llm_n_gpu_layers: int = 0
    # CPU worker threads for llama.cpp. Pi 5 has 4 Cortex-A76 cores.
    llm_n_threads: int = 4
    # Prompt-processing batch size. Lower this if memory pressure appears.
    llm_n_batch: int = 128
    # Native llama.cpp JSON-schema tool calling is optional because its grammar
    # compiler can be prohibitively slow on CPU-only local deployments.
    llm_native_tool_calling: bool = False

    # Normal answers need room to finish structured market/news summaries;
    # 256 tokens can cut off a response halfway through the asset list.
    agent_max_tokens: int = Field(768, ge=128, le=16_384)
    report_max_tokens: int = Field(1_536, ge=256, le=16_384)
    agent_temperature: float = 0.1
    # The orchestrator trims history before each call so the configured local
    # context remains bounded.
    agent_max_context_messages: int = 15
    agent_max_tool_rounds: int = Field(8, ge=1, le=32)
    agent_max_tool_result_chars: int = Field(12_000, ge=1_000, le=100_000)

    # ── Trading ────────────────────────────────────────────────────────────────
    trading_mode: Literal["recommend", "auto"] = "recommend"
    auto_max_trade_usd: float = Field(500.0, gt=0)
    auto_daily_loss_limit_usd: float = Field(1000.0, gt=0)
    auto_allowed_symbols: str = ""  # empty = all allowed
    auto_allow_market_orders: bool = False
    live_trading_enabled: bool = False
    autonomous_scans_enabled: bool = True
    autonomous_scan_interval_minutes: int = Field(60, ge=1)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def auto_allowed_symbols_set(self) -> set[str]:
        if not self.auto_allowed_symbols.strip():
            return set()
        return {s.strip().upper() for s in self.auto_allowed_symbols.split(",")}

    # ── Database ───────────────────────────────────────────────────────────────
    database_url_override: str = Field("", validation_alias="DATABASE_URL", repr=False)
    postgres_host: str = "postgres"
    postgres_port: int = 5432
    postgres_db: str = "investment_assistant"
    postgres_user: str = "ia_user"
    postgres_password: str = "change_me"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def database_url(self) -> str:
        if self.database_url_override:
            return self.database_url_override
        return (
            f"postgresql+asyncpg://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    # ── Alpaca ─────────────────────────────────────────────────────────────────
    alpaca_api_key: str = ""
    alpaca_secret_key: str = ""
    alpaca_paper: bool = True

    # ── Interactive Brokers ────────────────────────────────────────────────────
    ibkr_host: str = "127.0.0.1"
    ibkr_port: int = 4002
    ibkr_client_id: int = 1
    ibkr_enabled: bool = False

    # ── Coinbase ───────────────────────────────────────────────────────────────
    coinbase_api_key: str = ""
    coinbase_api_secret: str = ""

    # ── Binance ────────────────────────────────────────────────────────────────
    binance_api_key: str = ""
    binance_secret_key: str = ""
    binance_testnet: bool = True

    # ── News ───────────────────────────────────────────────────────────────────
    newsapi_key: str = ""
    guardian_api_key: str = ""  # free key at https://open-platform.theguardian.com/

    # ── Newsletter email ingestion (IMAP) ──────────────────────────────────────
    # Works with Gmail (enable IMAP + create an App Password if 2FA is on),
    # Outlook, and any standard IMAP server.
    newsletter_imap_server: str = "imap.gmail.com"
    newsletter_imap_port: int = 993
    newsletter_owner_user_id: str = ""  # explicit active application owner, never inferred
    newsletter_email_user: str = Field(default="", repr=False)  # your email address
    newsletter_email_password: str = Field(default="", repr=False)  # app password, not your main password
    newsletter_sender_filter: str = ""  # only ingest emails FROM this address

    # NewsAPI/Guardian are retained as optional adapters for compatibility, but
    # public RSS and HTML sources do not require API keys but still need explicit
    # source permission policies. Leave API credentials empty for local-only use.
    news_api_adapters_enabled: bool = False
    # Exact source identities require an operator-reviewed permission policy.
    # Catalog entries alone never authorize persistent collection.
    news_source_policies: dict[str, dict] = Field(default_factory=dict)

    # Yahoo/yfinance history is a third-party egress path. Keep it unavailable
    # until the operator has reviewed the applicable data rights and explicitly
    # enabled its research use. This is not a license assertion by the app.
    yahoo_historical_data_enabled: bool = False
    # Scheduled/on-demand prices, FX, search and options require their own
    # operator rights review. Neither Yahoo permission flag enables the other.
    yahoo_market_data_enabled: bool = False

    # ── Scheduler ─────────────────────────────────────────────────────────────
    market_data_refresh_minutes: int = Field(5, ge=1)
    news_ingestion_minutes: int = Field(60, ge=1, le=1440)
    news_service_user_id: str = ""  # explicitly provisioned active ingestion principal
    weekly_report_day: int = 6  # weekday index: Monday is 0, Sunday is 6
    weekly_report_hour: int = 18
    weekly_report_minute: int = 0

    # ── Reports ────────────────────────────────────────────────────────────────
    reports_dir: str = "/app/reports"
    storage_minimum_free_bytes: int = Field(1073741824, ge=1048576)
    report_maximum_bytes: int = Field(16777216, ge=1024, le=67108864)

    @property
    def is_development(self) -> bool:
        return self.environment == "development"

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @property
    def authentication_ready(self) -> bool:
        """Return whether production browser authentication can be enforced."""
        return bool(self.auth_username and self.auth_password_hash and self.auth_session_secret)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


# Convenience singleton
settings = get_settings()
