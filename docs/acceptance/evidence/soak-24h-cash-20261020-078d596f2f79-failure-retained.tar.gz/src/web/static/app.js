/* Investment Assistant – WebSocket Chat Client */

// Keep the active conversation tab-scoped while storing every conversation on
// the server. This lets the sidebar resume old chats without merging tabs.
let activeConversationId = sessionStorage.getItem('ia_active_conversation_id') || '';
let conversationWorkspace = { projects: [], unassigned: [], recent: [], total: 0 };
let conversationSearchTimer = null;
let conversationLoadToken = 0;

let ws = null;
let currentAssistantBubble = null;
let currentAssistantText = '';
const messageQueue = [];
const MAX_QUEUED_MESSAGES = 4;
let activeMessage = null;
let reconnectTimer = null;
let reconnectDelay = 1000;
const MAX_RECONNECT = 30000;
let portfolioSnapshot = null;
let portfolioLoading = false;
let portfolioSortKey = 'value_usd';
let portfolioSortDirection = 'desc';
let portfolioVisiblePositions = [];
let selectedPortfolioPosition = null;
let expenseSnapshot = null;
let expensesLoading = false;
let expenseStream = null;
const simulationRuns = new Map();
const SIDEBAR_WIDTH_KEY = 'ia_sidebar_width';
const SIDEBAR_WIDTH_MIN = 220;
const SIDEBAR_WIDTH_MAX = 480;

// ── WebSocket ──────────────────────────────────────────────────────────────────

function connect() {
  if (!activeConversationId) return;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const url = `${proto}://${location.host}/ws/chat/${activeConversationId}`;

  setStatus('connecting');
  setSendEnabled(false);
  ws = new WebSocket(url);

  ws.onopen = () => {
    setStatus('online');
    setSendEnabled(true);
    processMessageQueue();
    reconnectDelay = 1000;
    clearTimeout(reconnectTimer);
    console.log('WebSocket connected');
  };

  ws.onclose = (e) => {
    setStatus('offline');
    setSendEnabled(false);
    if (activeMessage) {
      discardAssistantMessage();
      appendErrorMessage('The connection closed while this request was running. It was not retried automatically.');
      activeMessage = null;
    }
    updateQueueStatus();
    if (e.code === 4001 || e.code === 4003) {
      window.location.assign('/login');
      return;
    }
    if (e.code !== 1000) {
      reconnectTimer = setTimeout(() => {
        reconnectDelay = Math.min(reconnectDelay * 1.5, MAX_RECONNECT);
        connect();
      }, reconnectDelay);
    }
  };

  ws.onerror = (e) => console.error('WS error', e);

  ws.onmessage = (e) => {
    const event = JSON.parse(e.data);
    handleEvent(event);
  };
}

function handleEvent(event) {
  switch (event.type) {
    case 'final_answer':
      // The server emits this only after the agent has completed its tool
      // work and validated the response as a final answer.
      discardAssistantMessage();
      if (event.text) appendAssistantMessage(event.text);
      appendTurnEvidence(event.turn);
      break;
    case 'text_delta':
      // Never render raw model deltas. Only the server's validated
      // final_answer event may create an assistant chat bubble.
      break;
    case 'tool_call':
      appendToolCall(event.name, event.input);
      break;
    case 'tool_result':
      appendToolResult(event.name, event.result);
      break;
    case 'done':
      finaliseAssistantMessage();
      activeMessage = null;
      updateQueueStatus();
      processMessageQueue();
      loadConversationWorkspace();
      break;
    case 'error':
      discardAssistantMessage();
      appendErrorMessage(event.message);
      activeMessage = null;
      updateQueueStatus();
      processMessageQueue();
      break;
  }
}

// ── Message Rendering ─────────────────────────────────────────────────────────

function appendUserMessage(text) {
  const div = document.createElement('div');
  div.className = 'msg user';
  div.innerHTML = `
    <div class="msg-bubble">${escapeHtml(text)}</div>
    <div class="msg-time">${timeNow()}</div>
  `;
  messagesEl().appendChild(div);
  scrollBottom();
}

function appendStoredUserMessage(text, createdAt = null) {
  const div = document.createElement('div');
  div.className = 'msg user';
  div.innerHTML = `
    <div class="msg-bubble">${escapeHtml(text)}</div>
    <div class="msg-time">${formatMessageTime(createdAt)}</div>
  `;
  messagesEl().appendChild(div);
  scrollBottom();
}

function appendAssistantMessage(text, createdAt = null) {
  const div = document.createElement('div');
  div.className = 'msg assistant';
  div.innerHTML = `
    <div class="msg-bubble">${markdownToHtml(text)}</div>
    <div class="msg-time">${formatMessageTime(createdAt)}</div>
  `;
  messagesEl().appendChild(div);
  scrollBottom();
}

function startAssistantMessage() {
  // Typing indicator first
  currentAssistantText = '';
  const div = document.createElement('div');
  div.className = 'msg assistant';
  div.innerHTML = `
    <div class="msg-bubble" id="streaming-bubble">
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
    </div>
    <div class="msg-time">${timeNow()}</div>
  `;
  messagesEl().appendChild(div);
  currentAssistantBubble = div.querySelector('#streaming-bubble');
  currentAssistantBubble.removeAttribute('id');
  scrollBottom();
}

function appendAssistantDelta(text) {
  if (!currentAssistantBubble) startAssistantMessage();
  currentAssistantText += text;
  currentAssistantBubble.innerHTML = markdownToHtml(currentAssistantText);
  scrollBottom();
}

function finaliseAssistantMessage() {
  if (currentAssistantBubble && currentAssistantText) {
    currentAssistantBubble.innerHTML = markdownToHtml(currentAssistantText);
  }
  currentAssistantBubble = null;
  currentAssistantText = '';
  scrollBottom();
}

function discardAssistantMessage() {
  if (currentAssistantBubble) {
    currentAssistantBubble.closest('.msg')?.remove();
  }
  currentAssistantBubble = null;
  currentAssistantText = '';
}

function appendToolCall(name, input) {
  const el = document.createElement('div');
  el.className = 'tool-call';
  el.innerHTML = `<span class="tool-icon">🔧</span> Calling <strong>${escapeHtml(name)}</strong>&hellip;`;
  messagesEl().appendChild(el);
  scrollBottom();
}

function appendToolResult(name, resultStr) {
  let preview = resultStr;
  try {
    const obj = JSON.parse(resultStr);
    preview = JSON.stringify(obj, null, 0).slice(0, 120) + (resultStr.length > 120 ? '…' : '');
  } catch (_) { /* resultStr is not valid JSON — use the raw string as preview */ }
  const el = document.createElement('div');
  el.className = 'tool-call result';
  el.innerHTML = `<span class="tool-icon">✅</span> <strong>${escapeHtml(name)}</strong> → ${escapeHtml(preview)}`;
  messagesEl().appendChild(el);
  scrollBottom();
}

function appendErrorMessage(msg) {
  const div = document.createElement('div');
  div.className = 'msg assistant';
  div.innerHTML = `<div class="msg-bubble" style="border-color:#ef4444;color:#ef4444;">⚠️ Error: ${escapeHtml(msg)}</div>`;
  messagesEl().appendChild(div);
  scrollBottom();
}

// ── Send ──────────────────────────────────────────────────────────────────────

function sendMessage() {
  const input = document.getElementById('user-input');
  const text = input.value.trim();
  if (!text) return;
  if (!activeConversationId) {
    appendErrorMessage('Create a new chat before sending a message.');
    return;
  }
  if (ws?.readyState !== WebSocket.OPEN) {
    appendErrorMessage('The assistant is disconnected. Please wait for it to reconnect.');
    return;
  }
  if (messageQueue.length >= MAX_QUEUED_MESSAGES) {
    appendErrorMessage(`The assistant can queue up to ${MAX_QUEUED_MESSAGES} messages.`);
    return;
  }

  input.value = '';
  input.style.height = '';
  appendUserMessage(text);
  messageQueue.push(text);
  updateQueueStatus();
  processMessageQueue();
}

function processMessageQueue() {
  if (activeMessage || !messageQueue.length || ws?.readyState !== WebSocket.OPEN) {
    updateQueueStatus();
    return;
  }
  activeMessage = messageQueue.shift();
  startAssistantMessage();
  updateQueueStatus();
  ws.send(JSON.stringify({ message: activeMessage }));
}

function updateQueueStatus() {
  const el = document.getElementById('queue-status');
  if (!el) return;
  if (activeMessage && messageQueue.length) {
    el.textContent = `Working · ${messageQueue.length} queued`;
  } else if (activeMessage) {
    el.textContent = 'Working…';
  } else if (messageQueue.length) {
    el.textContent = `${messageQueue.length} queued`;
  } else {
    el.textContent = '';
  }
}

function sendQuick(text) {
  document.getElementById('user-input').value = text;
  sendMessage();
}

function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
  // Auto-resize textarea
  const ta = e.target;
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
}

// ── Trading Mode ──────────────────────────────────────────────────────────────

async function setMode(mode) {
  const statusEl = document.getElementById('mode-status');
  statusEl.textContent = 'Saving trading mode…';
  try {
    const resp = await fetch('/api/profile/trading-mode', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken(),
      },
      body: JSON.stringify({ mode }),
    });
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) {
      const detail = await resp.json().catch(() => ({}));
      throw new Error(detail.detail || 'Trading mode could not be saved.');
    }
    document.getElementById('btn-recommend').classList.toggle('active', mode === 'recommend');
    document.getElementById('btn-auto').classList.toggle('active', mode === 'auto');
    statusEl.textContent = mode === 'auto'
      ? '⚡ Auto mode — only bounded, configured trades can execute.'
      : '✋ Recommend mode — agent proposes, you confirm.';
  } catch (error) {
    statusEl.textContent = error.message;
    appendErrorMessage(error.message);
  }
}

// ── Market Snapshot ────────────────────────────────────────────────────────────

async function loadSnapshot() {
  const el = document.getElementById('market-snapshot');
  el.textContent = 'Loading…';
  try {
    const resp = await fetch('/api/market/snapshot');
    if (resp.status === 401) { window.location.assign('/login'); return; }
    const data = await resp.json();
    if (data.message) { el.textContent = data.message; return; }
    const overview = data.market_overview || {};
    if (overview.error || overview.available === false) {
      el.textContent = (overview.error_code || overview.error) === 'YAHOO_MARKET_DATA_DISABLED_PENDING_OPERATOR_REVIEW'
        ? 'Market data is unavailable until this source is reviewed and approved for use.'
        : 'Market data is unavailable. A verified snapshot could not be collected.';
      return;
    }
    const markets = data.market_overview?.markets || {};
    let html = '';
    for (const [name, info] of Object.entries(markets)) {
      const price = info.price ? info.price.toLocaleString(undefined, { maximumFractionDigits: 2 }) : 'N/A';
      const chg = info.change_pct;
      let cls = '';
      if (chg > 0) cls = 'up';
      else if (chg < 0) cls = 'down';
      const sign = chg > 0 ? '+' : '';
      const chgStr = chg == null ? '' : ` (${sign}${chg}%)`;
      html += `<div class="market-row"><span class="name">${name}</span><span class="price ${cls}">${price}${chgStr}</span></div>`;
    }
    el.innerHTML = html || 'No data available';
  } catch (e) {
    console.error('Snapshot load failed', e);
    el.textContent = 'Failed to load snapshot.';
  }
}

// ── Portfolio and simulation dashboards ──────────────────────────────────────

function switchView(view) {
  const isPortfolio = view === 'portfolio';
  const isExpenses = view === 'expenses';
  const isSimulation = view === 'simulation';
  document.getElementById('chat-view').hidden = isPortfolio || isExpenses || isSimulation;
  document.getElementById('portfolio-view').hidden = !isPortfolio;
  document.getElementById('expenses-view').hidden = !isExpenses;
  document.getElementById('simulation-view').hidden = !isSimulation;
  document.querySelectorAll('.view-tab').forEach((button) => {
    const active = button.dataset.view === view;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  if (isPortfolio) {
    loadPortfolio();
  } else if (isExpenses) {
    loadExpenses();
    connectExpenseStream();
  } else if (isSimulation) {
    loadSimulations();
  } else {
    document.getElementById('user-input')?.focus();
  }
}

async function loadPortfolio(force = false) {
  if (portfolioLoading || (!force && portfolioSnapshot)) {
    if (!portfolioSnapshot) renderPortfolioLoading();
    return;
  }
  portfolioLoading = true;
  renderPortfolioLoading();
  const refreshButton = document.getElementById('portfolio-refresh');
  if (refreshButton) refreshButton.disabled = true;
  try {
    const resp = await fetch('/api/portfolio', { cache: 'no-store' });
    if (resp.status === 401) { window.location.assign('/login'); return; }
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.detail || 'Portfolio data could not be loaded.');
    renderPortfolio(data);
  } catch (error) {
    console.error('Portfolio load failed', error);
    renderPortfolioError(error.message);
  } finally {
    portfolioLoading = false;
    if (refreshButton) refreshButton.disabled = false;
  }
}

function renderPortfolioLoading() {
  const status = document.getElementById('portfolio-status');
  if (!status) return;
  status.className = 'portfolio-status neutral';
  status.textContent = 'Loading…';
  document.getElementById('portfolio-updated').textContent = 'Fetching live broker data…';
}

function renderPortfolioError(message) {
  const status = document.getElementById('portfolio-status');
  status.className = 'portfolio-status error';
  status.textContent = 'Unavailable';
  document.getElementById('portfolio-updated').textContent = message;
  document.getElementById('portfolio-alerts').innerHTML = `<div class="portfolio-alert error">${escapeHtml(message)}</div>`;
  document.getElementById('portfolio-empty').hidden = false;
  document.getElementById('portfolio-content').hidden = true;
  document.getElementById('portfolio-empty-title').textContent = 'Portfolio data is unavailable';
  document.getElementById('portfolio-empty-copy').textContent = 'Check the deployment and broker connection, then refresh this dashboard.';
}

function renderPortfolio(data) {
  portfolioSnapshot = data;
  const status = document.getElementById('portfolio-status');
  const statusLabel = data.status === 'ready' ? 'Live' : data.status === 'warning' ? 'Partial data' : data.status === 'error' ? 'Error' : 'Not connected';
  status.className = `portfolio-status ${data.status === 'ready' ? 'ready' : data.status === 'warning' ? 'warning' : data.status === 'error' ? 'error' : 'neutral'}`;
  status.textContent = statusLabel;
  document.getElementById('portfolio-updated').textContent = data.updated_at
    ? `Last refreshed ${formatMessageTime(data.updated_at)} · Values are supplied by your brokers`
    : 'Values are supplied by your brokers';

  const alerts = data.errors || [];
  document.getElementById('portfolio-alerts').innerHTML = alerts.length
    ? alerts.map((error) => `<div class="portfolio-alert ${data.status === 'error' ? 'error' : ''}"><strong>${escapeHtml(formatBrokerName(error.broker))}</strong>${error.account_name ? ` · ${escapeHtml(error.account_name)}` : ''}: ${escapeHtml(error.error)}</div>`).join('')
    : '';

  document.getElementById('portfolio-equity').textContent = formatCurrency(data.total_equity_usd);
  document.getElementById('portfolio-market-value').textContent = formatCurrency(data.total_market_value_usd);
  const pnl = document.getElementById('portfolio-pnl');
  pnl.textContent = formatCurrency(data.total_unrealized_pnl_usd);
  pnl.classList.toggle('up', Number(data.total_unrealized_pnl_usd) > 0);
  pnl.classList.toggle('down', Number(data.total_unrealized_pnl_usd) < 0);
  document.getElementById('portfolio-cash').textContent = formatCurrency(data.cash_usd);
  document.getElementById('portfolio-equity-note').textContent = data.total_equity_usd == null
    ? 'Broker does not report equity'
    : `${(data.connected_accounts || []).length} active account${(data.connected_accounts || []).length === 1 ? '' : 's'}`;
  document.getElementById('portfolio-pnl-note').textContent = data.positions?.some((position) => position.pnl_usd != null)
    ? 'Broker-reported positions'
    : 'No position P&L reported';

  renderPortfolioFilters(data);
  renderPortfolioHoldings();
  renderPortfolioAllocation(data);
  renderPortfolioAccounts(data);

  const showEmpty = data.empty_state === 'connect_broker' || data.empty_state === 'provider_error';
  const empty = document.getElementById('portfolio-empty');
  empty.hidden = !showEmpty;
  document.getElementById('portfolio-content').hidden = showEmpty;
  if (showEmpty) {
    const providerError = data.empty_state === 'provider_error';
    document.getElementById('portfolio-empty-title').textContent = providerError
      ? 'Broker data is unavailable'
      : 'Connect a brokerage account';
    document.getElementById('portfolio-empty-copy').textContent = providerError
      ? 'The account is configured, but the broker did not return a usable snapshot. Review the connection message above.'
      : 'Your live portfolio will appear here after an active broker account is configured.';
  }
}

function renderPortfolioFilters(data) {
  const select = document.getElementById('portfolio-broker-filter');
  const current = select.value;
  const brokers = [...new Set((data.positions || []).map((position) => position.broker).filter(Boolean))].sort();
  select.innerHTML = '<option value="all">All brokers</option>'
    + brokers.map((broker) => `<option value="${escapeHtml(broker)}">${escapeHtml(formatBrokerName(broker))}</option>`).join('');
  select.value = brokers.includes(current) ? current : 'all';
}

function renderPortfolioHoldings() {
  const body = document.getElementById('portfolio-holdings-body');
  const empty = document.getElementById('portfolio-holdings-empty');
  if (!body || !portfolioSnapshot) return;
  const search = (document.getElementById('portfolio-search').value || '').trim().toLowerCase();
  const broker = document.getElementById('portfolio-broker-filter').value;
  const positions = (portfolioSnapshot.positions || []).filter((position) => {
    const haystack = `${position.symbol || ''} ${position.broker || ''} ${position.account_name || ''}`.toLowerCase();
    return (!search || haystack.includes(search)) && (broker === 'all' || position.broker === broker);
  });
  positions.sort((left, right) => {
    const a = left[portfolioSortKey];
    const b = right[portfolioSortKey];
    if (portfolioSortKey === 'symbol') {
      return portfolioSortDirection === 'asc'
        ? String(a || '').localeCompare(String(b || ''))
        : String(b || '').localeCompare(String(a || ''));
    }
    const aNumber = a == null ? -Infinity : Number(a);
    const bNumber = b == null ? -Infinity : Number(b);
    return portfolioSortDirection === 'asc' ? aNumber - bNumber : bNumber - aNumber;
  });
  portfolioVisiblePositions = positions;
  document.getElementById('portfolio-position-count').textContent = String(positions.length);
  body.innerHTML = positions.map((position, index) => {
    const selected = selectedPortfolioPosition === position;
    const pnl = position.pnl_usd;
    const pnlClass = pnl > 0 ? 'up' : pnl < 0 ? 'down' : '';
    return `<tr tabindex="0" class="${selected ? 'selected' : ''}" onclick="selectPortfolioPosition(${index})" onkeydown="if(event.key === 'Enter' || event.key === ' ') { event.preventDefault(); selectPortfolioPosition(${index}); }">
      <td><div class="asset-cell"><span class="asset-symbol">${escapeHtml(position.symbol)}</span><span class="asset-meta">${escapeHtml(formatBrokerName(position.broker))}${position.account_name ? ` · ${escapeHtml(position.account_name)}` : ''}</span></div></td>
      <td>${formatQuantity(position.quantity)}</td>
      <td>${formatCurrency(position.price_usd)}</td>
      <td class="${position.value_usd == null ? 'value-unavailable' : ''}">${formatCurrency(position.value_usd)}</td>
      <td class="${pnlClass}">${formatCurrency(pnl)}</td>
    </tr>`;
  }).join('');
  empty.hidden = positions.length > 0;
  renderPortfolioDetail(selectedPortfolioPosition && positions.includes(selectedPortfolioPosition) ? selectedPortfolioPosition : null);
  document.querySelectorAll('.sort-btn').forEach((button) => {
    const indicator = button.querySelector('span');
    indicator.textContent = button.dataset.sort === portfolioSortKey ? (portfolioSortDirection === 'asc' ? '↑' : '↓') : '↕';
  });
}

function sortPortfolioBy(key) {
  if (portfolioSortKey === key) portfolioSortDirection = portfolioSortDirection === 'asc' ? 'desc' : 'asc';
  else { portfolioSortKey = key; portfolioSortDirection = key === 'symbol' ? 'asc' : 'desc'; }
  renderPortfolioHoldings();
}

function selectPortfolioPosition(index) {
  selectedPortfolioPosition = portfolioVisiblePositions[index] || null;
  renderPortfolioHoldings();
}

function renderPortfolioAllocation(data) {
  const allocation = data.allocation || [];
  const colors = ['#60a5fa', '#34d399', '#fbbf24', '#f472b6', '#a78bfa', '#fb7185', '#22d3ee'];
  const donut = document.getElementById('portfolio-donut');
  const label = document.getElementById('portfolio-donut-label');
  const legend = document.getElementById('portfolio-allocation-legend');
  if (!allocation.length) {
    donut.style.background = 'conic-gradient(var(--border) 0 100%)';
    label.textContent = '—';
    legend.innerHTML = '<div class="table-empty">No USD allocation available.</div>';
    return;
  }
  let cursor = 0;
  const segments = allocation.map((item, index) => {
    const end = cursor + Number(item.percentage || 0);
    const segment = `${colors[index % colors.length]} ${cursor}% ${end}%`;
    cursor = end;
    return segment;
  });
  donut.style.background = `conic-gradient(${segments.join(', ')})`;
  label.textContent = `${Math.round(allocation.reduce((sum, item) => sum + Number(item.percentage || 0), 0))}%`;
  legend.innerHTML = allocation.slice(0, 7).map((item, index) => `<div class="legend-row"><span class="legend-swatch" style="background:${colors[index % colors.length]}"></span><span class="legend-label">${escapeHtml(item.symbol)}</span><span class="legend-value">${formatCurrency(item.value_usd)} · ${formatPct(item.percentage)}</span></div>`).join('');
}

function renderPortfolioAccounts(data) {
  const list = document.getElementById('portfolio-accounts-list');
  const accounts = data.connected_accounts || [];
  if (!accounts.length) {
    list.innerHTML = '<div class="table-empty">No active broker accounts.</div>';
    return;
  }
  list.innerHTML = accounts.map((account) => {
    const isError = account.status === 'error';
    return `<div class="portfolio-account"><div class="portfolio-account-main"><div class="portfolio-account-name">${escapeHtml(account.display_name)}</div><div class="portfolio-account-meta">${escapeHtml(formatBrokerName(account.broker))}</div></div><span class="account-state ${isError ? 'error' : ''}">${isError ? 'Needs attention' : 'Connected'}</span></div>`;
  }).join('');
}

function renderPortfolioDetail(position) {
  const title = document.getElementById('portfolio-detail-title');
  const broker = document.getElementById('portfolio-detail-broker');
  const body = document.getElementById('portfolio-detail-body');
  if (!position) {
    title.textContent = 'Select a holding';
    broker.textContent = '—';
    body.textContent = 'Choose a row above to inspect its broker-reported details.';
    return;
  }
  title.textContent = position.symbol;
  broker.textContent = formatBrokerName(position.broker);
  const pnlClass = position.pnl_usd > 0 ? 'up' : position.pnl_usd < 0 ? 'down' : '';
  body.innerHTML = `<div class="detail-metrics">
    <div class="detail-metric"><span>Quantity</span><strong>${formatQuantity(position.quantity)}</strong></div>
    <div class="detail-metric"><span>Price</span><strong>${formatCurrency(position.price_usd)}</strong></div>
    <div class="detail-metric"><span>Market value</span><strong>${formatCurrency(position.value_usd)}</strong></div>
    <div class="detail-metric"><span>Unrealized P&amp;L</span><strong class="${pnlClass}">${formatCurrency(position.pnl_usd)}</strong></div>
  </div><p class="card-note">Account: ${escapeHtml(position.account_name || 'Broker account')} · Values are read-only broker data.</p>`;
}

function focusBrokerAccounts() {
  const section = document.getElementById('broker-section');
  if (!section) return;
  document.getElementById('sidebar').classList.remove('hidden');
  section.scrollIntoView({ behavior: 'smooth', block: 'center' });
  window.setTimeout(() => document.getElementById('broker-provider')?.focus(), 350);
}

function formatCurrency(value) {
  if (value == null || Number.isNaN(Number(value))) return '—';
  return new Intl.NumberFormat(undefined, { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(Number(value));
}

function formatQuantity(value) {
  if (value == null || Number.isNaN(Number(value))) return '—';
  return Number(value).toLocaleString(undefined, { maximumFractionDigits: 6 });
}

function formatPct(value) {
  if (value == null || Number.isNaN(Number(value))) return '—';
  return `${Number(value).toFixed(1)}%`;
}

function formatBrokerName(broker) {
  return String(broker || 'Unknown').replaceAll('_', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}

async function loadSafety() {
  try {
    const resp = await fetch('/api/safety');
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) return;
    const policy = await resp.json();
    const mode = policy.trading_mode;
    document.getElementById('btn-recommend').classList.toggle('active', mode === 'recommend');
    document.getElementById('btn-auto').classList.toggle('active', mode === 'auto');
    document.getElementById('mode-status').textContent = policy.daily_halted
      ? '🛑 Auto-trading is halted for today.'
      : mode === 'auto'
        ? `Auto mode · cap $${policy.auto_max_trade_usd} · live ${policy.live_trading_enabled ? 'enabled' : 'disabled'}`
        : 'Recommend mode — every order needs explicit confirmation.';
  } catch (e) {
    console.error('Safety policy load failed', e);
  }
}

function csrfToken() {
  const match = document.cookie.match(/(?:^|; )ia_csrf=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : '';
}

async function activateKillSwitch() {
  if (!window.confirm('Block all future autonomous orders for the rest of today?')) return;
  try {
    const resp = await fetch('/api/safety/kill-switch', {
      method: 'POST',
      headers: {'X-CSRF-Token': csrfToken()},
    });
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) throw new Error('Kill switch could not be persisted.');
    const data = await resp.json();
    document.getElementById('mode-status').textContent = `🛑 ${data.message}`;
  } catch (error) {
    appendErrorMessage(error.message);
  }
}

// ── Durable user experience ─────────────────────────────────────────────────

async function loadProfile() {
  const statusEl = document.getElementById('profile-status');
  try {
    const resp = await fetch('/api/profile');
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) throw new Error('Profile unavailable');
    const profile = await resp.json();
    document.getElementById('profile-display-name').value = profile.display_name || '';
    document.getElementById('profile-description').value = profile.description || '';
    document.getElementById('profile-preferences').value = JSON.stringify(
      profile.preferences || {}, null, 2
    );
    statusEl.textContent = 'Profile loaded';
    statusEl.className = 'profile-status saved';
  } catch (error) {
    console.error('Profile load failed', error);
    statusEl.textContent = 'Profile could not be loaded.';
    statusEl.className = 'profile-status error';
  }
}

async function saveProfile() {
  const statusEl = document.getElementById('profile-status');
  let preferences;
  try {
    preferences = JSON.parse(document.getElementById('profile-preferences').value || '{}');
  } catch (_) {
    statusEl.textContent = 'Preferences must be valid JSON.';
    statusEl.className = 'profile-status error';
    return;
  }
  if (!preferences || Array.isArray(preferences) || typeof preferences !== 'object') {
    statusEl.textContent = 'Preferences must be a JSON object.';
    statusEl.className = 'profile-status error';
    return;
  }
  statusEl.textContent = 'Saving…';
  statusEl.className = 'profile-status';
  try {
    const resp = await fetch('/api/profile', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken(),
      },
      body: JSON.stringify({
        display_name: document.getElementById('profile-display-name').value,
        description: document.getElementById('profile-description').value,
        preferences,
      }),
    });
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) {
      const detail = await resp.json().catch(() => ({}));
      throw new Error(detail.detail || 'Profile could not be saved.');
    }
    const saved = await resp.json();
    document.getElementById('profile-preferences').value = JSON.stringify(
      saved.preferences || {}, null, 2
    );
    statusEl.textContent = 'Profile saved';
    statusEl.className = 'profile-status saved';
  } catch (error) {
    console.error('Profile save failed', error);
    statusEl.textContent = error.message;
    statusEl.className = 'profile-status error';
  }
}

// ── Per-user brokerage accounts ─────────────────────────────────────────────

const DEFAULT_BROKER_PROVIDERS = {
  alpaca: {fields: ['api_key', 'paper', 'secret_key'], secret_fields: ['api_key', 'secret_key']},
  ibkr: {fields: ['broker_account_id', 'environment', 'read_authorized', 'client_id', 'enabled', 'host', 'port'], secret_fields: ['broker_account_id']},
  coinbase: {fields: ['api_key', 'api_secret'], secret_fields: ['api_key', 'api_secret']},
  binance: {fields: ['api_key', 'secret_key', 'testnet'], secret_fields: ['api_key', 'secret_key']},
};
let brokerProviders = {...DEFAULT_BROKER_PROVIDERS};
let brokerAccounts = [];
let editingBrokerAccountId = null;
let editingBrokerAccount = null;

function brokerLabel(broker) {
  return {alpaca: 'Alpaca', ibkr: 'Interactive Brokers', coinbase: 'Coinbase', binance: 'Binance'}[broker] || broker;
}

function brokerFieldLabel(field) {
  return field.replaceAll('_', ' ').replace(/\b\w/g, char => char.toUpperCase());
}

function renderBrokerFields() {
  const provider = document.getElementById('broker-provider').value;
  const definition = brokerProviders[provider] || DEFAULT_BROKER_PROVIDERS[provider];
  const secretFields = new Set(definition.secret_fields || []);
  const publicConfig = editingBrokerAccount?.broker === provider
    ? (editingBrokerAccount.masked_fields || {}) : {};
  const configured = editingBrokerAccount?.broker === provider
    ? (editingBrokerAccount.configured_fields || {}) : {};
  const fieldsEl = document.getElementById('broker-fields');
  fieldsEl.innerHTML = (definition.fields || []).map(field => {
    const isBoolean = ['paper', 'testnet', 'enabled', 'read_authorized'].includes(field);
    const inputType = secretFields.has(field) ? 'password' : isBoolean ? 'checkbox' : field === 'port' || field === 'client_id' ? 'number' : 'text';
    if (isBoolean) {
      const defaultChecked = editingBrokerAccountId ? Boolean(publicConfig[field]) : provider !== 'ibkr';
      return `<label class="broker-field broker-check"><input id="broker-field-${field}" data-broker-field="${field}" type="checkbox" ${defaultChecked ? 'checked' : ''} /> ${escapeHtml(brokerFieldLabel(field))}</label>`;
    }
    const placeholder = secretFields.has(field)
      ? configured[field] ? 'Configured — leave blank to keep it' : 'Required credential'
      : publicConfig[field] ?? '';
    const value = secretFields.has(field) ? '' : publicConfig[field] ?? (field === 'port' ? '4002' : field === 'client_id' ? '1' : '');
    return `<label class="broker-field">${escapeHtml(brokerFieldLabel(field))}<input id="broker-field-${field}" data-broker-field="${field}" type="${inputType}" value="${escapeHtml(value)}" placeholder="${escapeHtml(String(placeholder))}" /></label>`;
  }).join('');
}

function renderBrokerAccounts() {
  const el = document.getElementById('broker-accounts-list');
  if (!brokerAccounts.length) {
    el.textContent = 'No active brokerage accounts. Market analysis still works without them.';
    return;
  }
  el.innerHTML = brokerAccounts.map(account => {
    const fields = Object.entries(account.masked_fields || {})
      .filter(([field]) => account.configured_fields?.[field] || account.masked_fields[field] !== '')
      .map(([field, value]) => `${escapeHtml(brokerFieldLabel(field))}: ${escapeHtml(String(value))}`)
      .join(' · ');
    return `<div class="broker-account">
      <div class="broker-account-head"><span class="broker-account-name">${escapeHtml(account.display_name)}</span><span class="broker-account-provider">${escapeHtml(brokerLabel(account.broker))}</span></div>
      <div class="broker-account-fields">${fields || 'No fields configured'}</div>
      <div class="broker-account-actions"><button data-edit-account="${escapeHtml(account.id)}">Edit</button><button data-delete-account="${escapeHtml(account.id)}">Disable</button>${account.broker === 'ibkr' ? `<button data-broker-evidence="${escapeHtml(account.id)}">Saved execution evidence</button><button data-broker-refresh="${escapeHtml(account.id)}">Read broker evidence</button>` : ''}</div><pre class="broker-evidence" data-broker-result="${escapeHtml(account.id)}" hidden></pre>
    </div>`;
  }).join('');
  el.querySelectorAll('[data-broker-evidence]').forEach(button => {
    button.addEventListener('click', () => brokerExecutionEvidence(button, false));
  });
  el.querySelectorAll('[data-broker-refresh]').forEach(button => {
    button.addEventListener('click', () => brokerExecutionEvidence(button, true));
  });
  el.querySelectorAll('[data-edit-account]').forEach(button => {
    button.addEventListener('click', () => editBrokerAccount(button.dataset.editAccount));
  });
  el.querySelectorAll('[data-delete-account]').forEach(button => {
    button.addEventListener('click', () => deleteBrokerAccount(button.dataset.deleteAccount));
  });
}

async function brokerExecutionEvidence(button, refresh) {
  const accountId = refresh ? button.dataset.brokerRefresh : button.dataset.brokerEvidence;
  const account = brokerAccounts.find(item => item.id === accountId);
  if (!account) return;
  if (refresh && !window.confirm(`Connect read-only to ${account.display_name} and collect available executions, fees, positions and currency cash balances? This does not verify paper/live status or submit orders.`)) return;
  const output = button.closest('.broker-account').querySelector('[data-broker-result]');
  output.hidden = false;
  output.textContent = refresh ? 'Reading available broker evidence…' : 'Loading saved evidence…';
  button.disabled = true;
  try {
    const url = `/api/broker-accounts/${encodeURIComponent(accountId)}/observations`;
    const cursor = !refresh && button.dataset.cursor;
    const readUrl = cursor ? `${url}?cursor=${encodeURIComponent(cursor)}` : url;
    const response = await fetch(refresh ? `${url}/refresh` : readUrl, refresh ? {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({confirm_broker_read: true}),
    } : {});
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail?.reason_code || 'Broker evidence unavailable');
    output.textContent = 'Available evidence only; history and late fees may be incomplete. External order ownership is unverified.\n' + JSON.stringify(result, null, 2);
    if (!refresh) {
      button.dataset.cursor = result.next_cursor || '';
      button.textContent = result.next_cursor ? 'Next saved evidence page' : 'Saved execution evidence';
    } else {
      const saved = button.closest('.broker-account').querySelector('[data-broker-evidence]');
      saved.dataset.cursor = '';
      saved.textContent = 'Saved execution evidence';
    }
  } catch (error) {
    output.textContent = error.message;
  } finally {
    button.disabled = false;
  }
}

function setBrokerStatus(message, kind = '') {
  const el = document.getElementById('broker-status');
  el.textContent = message;
  el.className = `profile-status ${kind}`;
}

async function loadBrokerAccounts() {
  try {
    const providerResp = await fetch('/api/broker-accounts/providers');
    if (providerResp.ok) {
      const providerData = await providerResp.json();
      brokerProviders = providerData.providers || brokerProviders;
    }
    renderBrokerFields();
    const resp = await fetch('/api/broker-accounts');
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) {
      const detail = await resp.json().catch(() => ({}));
      throw new Error(detail.detail || 'Brokerage account management is unavailable.');
    }
    const data = await resp.json();
    brokerAccounts = Array.isArray(data.accounts) ? data.accounts : [];
    renderBrokerAccounts();
    setBrokerStatus('Encrypted account settings ready', 'saved');
  } catch (error) {
    console.error('Broker account load failed', error);
    document.getElementById('broker-accounts-list').textContent = error.message;
    setBrokerStatus(error.message, 'error');
  }
}

function editBrokerAccount(accountId) {
  const account = brokerAccounts.find(item => item.id === accountId);
  if (!account) return;
  editingBrokerAccountId = account.id;
  editingBrokerAccount = account;
  const providerEl = document.getElementById('broker-provider');
  providerEl.value = account.broker;
  providerEl.disabled = true;
  document.getElementById('broker-display-name').value = account.display_name || '';
  document.getElementById('broker-cancel').hidden = false;
  renderBrokerFields();
  setBrokerStatus('Editing account — blank secrets keep the existing values');
}

function resetBrokerForm() {
  editingBrokerAccountId = null;
  editingBrokerAccount = null;
  document.getElementById('broker-provider').disabled = false;
  document.getElementById('broker-display-name').value = '';
  document.getElementById('broker-cancel').hidden = true;
  renderBrokerFields();
  setBrokerStatus('');
}

function collectBrokerConfig() {
  const config = {};
  document.querySelectorAll('[data-broker-field]').forEach(input => {
    if (input.type === 'checkbox') config[input.dataset.brokerField] = input.checked;
    else if (input.value !== '') config[input.dataset.brokerField] = input.type === 'number' ? Number(input.value) : input.value;
    else if (editingBrokerAccountId) config[input.dataset.brokerField] = '';
  });
  return config;
}

async function saveBrokerAccount() {
  const provider = document.getElementById('broker-provider').value;
  const body = {
    broker: provider,
    display_name: document.getElementById('broker-display-name').value.trim(),
    config: collectBrokerConfig(),
  };
  setBrokerStatus('Saving encrypted settings…');
  try {
    const url = editingBrokerAccountId ? `/api/broker-accounts/${encodeURIComponent(editingBrokerAccountId)}` : '/api/broker-accounts';
    const resp = await fetch(url, {
      method: editingBrokerAccountId ? 'PUT' : 'POST',
      headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify(body),
    });
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) {
      const detail = await resp.json().catch(() => ({}));
      throw new Error(detail.detail || 'Brokerage account could not be saved.');
    }
    resetBrokerForm();
    await loadBrokerAccounts();
  } catch (error) {
    setBrokerStatus(error.message, 'error');
  }
}

async function deleteBrokerAccount(accountId) {
  if (!window.confirm('Disable this brokerage account? Its encrypted record will be retained.')) return;
  try {
    const resp = await fetch(`/api/broker-accounts/${encodeURIComponent(accountId)}`, {
      method: 'DELETE', headers: {'X-CSRF-Token': csrfToken()},
    });
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) {
      const detail = await resp.json().catch(() => ({}));
      throw new Error(detail.detail || 'Brokerage account could not be disabled.');
    }
    if (editingBrokerAccountId === accountId) resetBrokerForm();
    await loadBrokerAccounts();
  } catch (error) {
    setBrokerStatus(error.message, 'error');
  }
}

// ── Projects and chat history ───────────────────────────────────────────────

function persistActiveConversation(id) {
  activeConversationId = id || '';
  if (activeConversationId) sessionStorage.setItem('ia_active_conversation_id', activeConversationId);
  else sessionStorage.removeItem('ia_active_conversation_id');
}

async function createConversation(projectId = null) {
  const resp = await fetch('/api/conversations', {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
    body: JSON.stringify({ project_id: projectId || null }),
  });
  if (resp.status === 401) { window.location.assign('/login'); return null; }
  if (!resp.ok) {
    const detail = await resp.json().catch(() => ({}));
    throw new Error(detail.detail || 'A new chat could not be created.');
  }
  return resp.json();
}

async function loadConversationWorkspace(search = null) {
  const searchEl = document.getElementById('conversation-search');
  const query = search === null ? (searchEl?.value || '') : search;
  try {
    const resp = await fetch(`/api/projects?search=${encodeURIComponent(query)}`);
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) throw new Error('Conversation history unavailable');
    conversationWorkspace = await resp.json();
    const visibleIds = new Set((conversationWorkspace.recent || []).map(item => item.id));
    if (!activeConversationId && conversationWorkspace.recent?.length) {
      persistActiveConversation(conversationWorkspace.recent[0].id);
    }
    if (activeConversationId && !query && !visibleIds.has(activeConversationId)) {
      if (conversationWorkspace.recent?.length) {
        persistActiveConversation(conversationWorkspace.recent[0].id);
      } else {
        const created = await createConversation();
        if (created) persistActiveConversation(created.id);
      }
      const refreshed = await fetch('/api/projects');
      if (refreshed.ok) conversationWorkspace = await refreshed.json();
    }
    if (!activeConversationId && !query) {
      const created = await createConversation();
      if (created) persistActiveConversation(created.id);
      const refreshed = await fetch('/api/projects');
      if (refreshed.ok) conversationWorkspace = await refreshed.json();
    }
    renderConversationSidebar();
    renderConversationProjectSelect();
  } catch (error) {
    console.error('Conversation workspace load failed', error);
    const el = document.getElementById('conversation-history-error');
    if (el) el.textContent = error.message;
  }
}

function scheduleConversationSearch() {
  clearTimeout(conversationSearchTimer);
  conversationSearchTimer = setTimeout(() => loadConversationWorkspace(), 180);
}

function renderConversationSidebar() {
  const projectsEl = document.getElementById('conversation-projects');
  const unassignedEl = document.getElementById('conversation-unassigned');
  if (!projectsEl || !unassignedEl) return;
  const projects = conversationWorkspace.projects || [];
  projectsEl.innerHTML = projects.length
    ? projects.map(project => `
      <section class="history-project">
        <button class="history-project-title" onclick="toggleProjectHistory('${escapeHtml(project.id)}')">
          <span class="project-chevron" id="project-chevron-${escapeHtml(project.id)}">⌄</span>
          <span>${escapeHtml(project.name)}</span>
          <span class="history-count">${project.conversations?.length || 0}</span>
        </button>
        <div class="history-project-chats" id="project-chats-${escapeHtml(project.id)}">
          ${(project.conversations || []).map(renderConversationRow).join('') || '<div class="history-empty">No chats yet</div>'}
        </div>
      </section>
    `).join('')
    : '<div class="history-empty">Create a project to organise chats.</div>';
  unassignedEl.innerHTML = (conversationWorkspace.unassigned || []).length
    ? `<div class="history-group-label">Other chats</div>${conversationWorkspace.unassigned.map(renderConversationRow).join('')}`
    : '';
  const errorEl = document.getElementById('conversation-history-error');
  if (errorEl) errorEl.textContent = '';
}

function renderConversationRow(conversation) {
  const active = conversation.id === activeConversationId ? ' active' : '';
  const preview = conversation.preview || 'No messages yet';
  return `
    <div class="conversation-row-wrap">
      <button class="conversation-row${active}" onclick="selectConversation('${escapeHtml(conversation.id)}')">
        <span class="conversation-row-main">
          <span class="conversation-row-title">${escapeHtml(conversation.title || 'New chat')}</span>
          <span class="conversation-row-preview">${escapeHtml(preview)}</span>
        </span>
        <span class="conversation-row-meta">${relativeTime(conversation.last_message_at || conversation.updated_at)}</span>
      </button>
      <button class="conversation-delete-btn" type="button" onclick="deleteConversation(event, '${escapeHtml(conversation.id)}')" aria-label="Delete chat" title="Delete chat">
        <svg class="conversation-delete-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7l1-3h4l1 3" />
        </svg>
      </button>
    </div>
  `;
}

function toggleProjectHistory(projectId) {
  const chats = document.getElementById(`project-chats-${projectId}`);
  const chevron = document.getElementById(`project-chevron-${projectId}`);
  if (!chats) return;
  const collapsed = chats.hidden;
  chats.hidden = !collapsed;
  if (chevron) chevron.textContent = collapsed ? '⌄' : '›';
}

function renderConversationProjectSelect(projectId = null) {
  const select = document.getElementById('conversation-project');
  if (!select) return;
  const current = projectId || select.dataset.selected || '';
  select.innerHTML = '<option value="">No project</option>'
    + (conversationWorkspace.projects || []).map(project =>
      `<option value="${escapeHtml(project.id)}">${escapeHtml(project.name)}</option>`
    ).join('');
  select.value = current;
  select.dataset.selected = current;
}

function updateConversationHeader(conversation = null) {
  const titleEl = document.getElementById('conversation-title');
  const subtitleEl = document.getElementById('conversation-subtitle');
  if (titleEl) titleEl.textContent = conversation?.title || 'New chat';
  if (subtitleEl) subtitleEl.textContent = conversation?.project_name || 'Personal workspace';
  renderConversationProjectSelect(conversation?.project_id || '');
}

async function startNewConversation() {
  if (activeMessage || messageQueue.length) {
    appendErrorMessage('Wait for the current chat queue to finish before starting another chat.');
    return;
  }
  try {
    const created = await createConversation();
    if (created) await selectConversation(created.id);
  } catch (error) {
    appendErrorMessage(error.message);
  }
}

async function selectConversation(id) {
  if (!id || id === activeConversationId) return;
  if (activeMessage || messageQueue.length) {
    appendErrorMessage('Wait for the current chat queue to finish before switching chats.');
    return;
  }
  clearTimeout(reconnectTimer);
  if (ws) {
    ws.onerror = null;
    ws.onclose = null;
    ws.close(1000);
    ws = null;
  }
  persistActiveConversation(id);
  currentAssistantBubble = null;
  currentAssistantText = '';
  messagesEl().replaceChildren();
  updateConversationHeader();
  renderConversationSidebar();
  setStatus('connecting');
  setSendEnabled(false);
  await loadHistory();
  renderConversationSidebar();
  connect();
}

async function renameActiveConversation() {
  if (!activeConversationId) return;
  const current = document.getElementById('conversation-title')?.textContent || 'New chat';
  const title = window.prompt('Conversation name', current);
  if (title === null) return;
  try {
    const resp = await fetch(`/api/conversations/${encodeURIComponent(activeConversationId)}`, {
      method: 'PATCH',
      headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({ title: title.trim() || 'New chat' }),
    });
    if (!resp.ok) throw new Error('Conversation could not be renamed.');
    const conversation = await resp.json();
    updateConversationHeader(conversation);
    await loadConversationWorkspace();
  } catch (error) {
    appendErrorMessage(error.message);
  }
}

function conversationTitleById(conversationId) {
  const conversations = [
    ...(conversationWorkspace.unassigned || []),
    ...(conversationWorkspace.recent || []),
    ...(conversationWorkspace.projects || []).flatMap((project) => project.conversations || []),
  ];
  return conversations.find((conversation) => conversation.id === conversationId)?.title || 'this chat';
}

async function deleteConversation(event, conversationId) {
  event?.stopPropagation();
  const title = conversationTitleById(conversationId);
  if (!window.confirm(`Delete “${title}” permanently?`)) return;
  const wasActive = conversationId === activeConversationId;
  try {
    const resp = await fetch(`/api/conversations/${encodeURIComponent(conversationId)}`, {
      method: 'DELETE',
      headers: {'X-CSRF-Token': csrfToken()},
    });
    if (resp.status === 401) { window.location.assign('/login'); return; }
    const detail = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(detail.detail || 'Chat could not be deleted.');

    if (wasActive) {
      if (ws) {
        ws.onerror = null;
        ws.onclose = null;
        ws.close(1000);
        ws = null;
      }
      persistActiveConversation('');
      currentAssistantBubble = null;
      currentAssistantText = '';
      messagesEl().replaceChildren();
    }
    await loadConversationWorkspace();
    if (wasActive) {
      await loadHistory();
      connect();
    }
    renderConversationSidebar();
  } catch (error) {
    const errorEl = document.getElementById('conversation-history-error');
    if (errorEl) errorEl.textContent = error.message;
    console.error('Conversation deletion failed', error);
  }
}

async function createProject() {
  const name = window.prompt('Project name');
  if (name === null || !name.trim()) return;
  try {
    const resp = await fetch('/api/projects', {
      method: 'POST',
      headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({ name: name.trim() }),
    });
    if (!resp.ok) {
      const detail = await resp.json().catch(() => ({}));
      throw new Error(detail.detail || 'Project could not be created.');
    }
    await loadConversationWorkspace();
  } catch (error) {
    appendErrorMessage(error.message);
  }
}

async function moveActiveConversation(projectId) {
  if (!activeConversationId) return;
  try {
    const resp = await fetch(`/api/conversations/${encodeURIComponent(activeConversationId)}`, {
      method: 'PATCH',
      headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({ project_id: projectId || null }),
    });
    if (!resp.ok) throw new Error('Conversation could not be moved.');
    const conversation = await resp.json();
    updateConversationHeader(conversation);
    await loadConversationWorkspace();
  } catch (error) {
    appendErrorMessage(error.message);
    renderConversationProjectSelect();
  }
}

function appendWelcomeMessage() {
  appendAssistantMessage(
    '**Welcome to your Investment Assistant! 📈**\n\n'
    + 'I can analyse scoped portfolio evidence, news, reports and simulations. Order practice uses separately approved simulator actions.\n\n'
    + 'Use the quick prompts on the left, or ask me anything.'
  );
}

function relativeTime(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const seconds = Math.max(0, (Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return 'now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  if (seconds < 172800) return 'yesterday';
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

async function loadHistory() {
  if (!activeConversationId) return false;
  try {
    const resp = await fetch(`/api/conversations/${encodeURIComponent(activeConversationId)}`);
    if (resp.status === 401) { window.location.assign('/login'); return false; }
    if (!resp.ok) throw new Error('Conversation history unavailable');
    const conversation = await resp.json();
    messagesEl().replaceChildren();
    for (const message of conversation.messages || []) {
      if (message.role === 'user') appendStoredUserMessage(message.content, message.created_at);
      if (message.role === 'assistant') {
        appendAssistantMessage(message.content || 'This turn has no completed answer.', message.created_at);
        appendTurnEvidence(message.turn);
      }
    }
    updateConversationHeader(conversation);
    if (!conversation.messages?.length) appendWelcomeMessage();
    return Boolean(conversation.messages?.length);
  } catch (error) {
    console.error('Conversation history load failed', error);
    return false;
  }
}

async function loadReports() {
  const el = document.getElementById('reports-list');
  try {
    const resp = await fetch('/api/reports');
    if (resp.status === 401) { window.location.assign('/login'); return; }
    const reports = await resp.json();
    if (!reports.length) { el.textContent = 'No reports yet.'; return; }
    el.innerHTML = reports.slice(0, 5).map(r => `
      <div class="report-item">
        <span>${r.period_start.slice(0, 10)} → ${r.period_end.slice(0, 10)}</span>
        <span class="report-status">${r.generation_status === 'complete' ? 'Generation complete' :
          r.generation_status === 'retired' ? 'Content removed by owner' :
          r.generation_status === 'retention_pending' ? 'Content removed — PDF cleanup pending' :
          r.generation_status === 'partial_failure' ? 'Partial report — review data gaps' :
          'Historical report — completion unverified'}</span>
        ${r.pdf_available ? `<a href="/api/reports/${r.id}/pdf" target="_blank">PDF ↗</a>` : ''}
      </div>
    `).join('');
  } catch (e) {
    console.error('Reports load failed', e);
    el.textContent = 'Could not load reports.';
  }
}

let reportRetentionPlan = null;
function resetReportRetention() {
  reportRetentionPlan = null;
  const approval = document.getElementById('report-retention-confirm');
  approval.checked = false; approval.disabled = true;
  document.getElementById('report-retention-apply').disabled = true;
  document.getElementById('report-retention-status').textContent = 'Choose an age and preview before approving removal.';
}
function updateReportRetentionApproval() {
  document.getElementById('report-retention-apply').disabled =
    !reportRetentionPlan || !document.getElementById('report-retention-confirm').checked;
}
async function previewReportRetention() {
  resetReportRetention();
  const days = Number(document.getElementById('report-retain-days').value);
  const status = document.getElementById('report-retention-status');
  if (!Number.isInteger(days) || days < 1 || days > 36525) {
    status.textContent = 'Enter a whole number of days between 1 and 36525.'; return;
  }
  const button = document.getElementById('report-retention-preview'); button.disabled = true;
  try {
    const response = await fetch('/api/reports/retention/preview', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({retain_days: days}),
    });
    if (!response.ok) throw new Error('Report retention preview unavailable.');
    const plan = await response.json();
    if (Number(document.getElementById('report-retain-days').value) !== days) return;
    if (!plan.count) { status.textContent = 'No reports match this age.'; return; }
    reportRetentionPlan = plan;
    status.textContent = `${plan.count} reports in this batch. Preview expires after 10 minutes. ` +
      'Report IDs and dates, source records and chat copies remain. ' +
      (plan.may_have_more ? 'Additional reports may need another preview.' : '');
    document.getElementById('report-retention-confirm').disabled = false;
  } catch (error) { status.textContent = error.message; }
  finally { button.disabled = false; }
}
async function applyReportRetention() {
  if (!reportRetentionPlan || !document.getElementById('report-retention-confirm').checked) return;
  const plan = reportRetentionPlan;
  resetReportRetention();
  const status = document.getElementById('report-retention-status');
  try {
    const response = await fetch('/api/reports/retention/apply', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({policy: plan.policy, plan_sha256: plan.plan_sha256, confirm_report_content_removal: true}),
    });
    if (!response.ok) throw new Error('Removal was not confirmed. Reload reports and preview again to check status.');
    const result = await response.json();
    status.textContent = `Removed content from ${result.content_removed} reports; ${result.pending} PDF cleanups pending. ` +
      (result.pending ? 'Review storage access and preview again to retry.' : 'Report tombstones remain.');
    await loadReports();
  } catch (error) { status.textContent = error.message; }
}

let chatRetentionPlan = null;
function resetChatRetention() {
  chatRetentionPlan = null;
  const approval = document.getElementById('chat-retention-confirm');
  approval.checked = false; approval.disabled = true;
  document.getElementById('chat-retention-apply').disabled = true;
  document.getElementById('chat-retention-status').textContent = 'Choose an age and preview before approving removal.';
}
function updateChatRetentionApproval() {
  document.getElementById('chat-retention-apply').disabled =
    !chatRetentionPlan || !document.getElementById('chat-retention-confirm').checked;
}
async function previewChatRetention() {
  resetChatRetention();
  const days = Number(document.getElementById('chat-retain-days').value);
  const status = document.getElementById('chat-retention-status');
  if (!Number.isInteger(days) || days < 1 || days > 36525) {
    status.textContent = 'Enter a whole number of days between 1 and 36525.'; return;
  }
  const button = document.getElementById('chat-retention-preview'); button.disabled = true;
  try {
    const response = await fetch('/api/chat/retention/preview', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({retain_days: days}),
    });
    if (!response.ok) throw new Error('Chat retention preview unavailable.');
    const plan = await response.json();
    if (Number(document.getElementById('chat-retain-days').value) !== days) return;
    if (!plan.message_count) { status.textContent = 'No inactive chats match this age. Unfinished turns are excluded.'; return; }
    chatRetentionPlan = plan;
    status.textContent = `${plan.message_count} messages in this batch. Preview expires after 10 minutes. ` +
      'Chat IDs, dates and digests remain; reports and source records are separate. Unfinished turns are excluded. ' +
      (plan.may_have_more ? 'Additional messages may need another preview.' : '');
    document.getElementById('chat-retention-confirm').disabled = false;
  } catch (error) { status.textContent = error.message; }
  finally { button.disabled = false; }
}
async function applyChatRetention() {
  if (!chatRetentionPlan || !document.getElementById('chat-retention-confirm').checked) return;
  const plan = chatRetentionPlan;
  resetChatRetention();
  const status = document.getElementById('chat-retention-status');
  try {
    const response = await fetch('/api/chat/retention/apply', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({policy: plan.policy, plan_sha256: plan.plan_sha256, confirm_chat_content_removal: true}),
    });
    if (!response.ok) throw new Error('Removal was not confirmed. Reload chats and preview again to check status.');
    const result = await response.json();
    status.textContent = `Removed ${result.removed_messages} chat messages. Tombstones remain; unfinished turns were excluded. ` +
      (result.may_have_more ? 'Preview again for another batch.' : '');
    await loadConversationWorkspace();
    if (!activeMessage && !messageQueue.length) await loadHistory();
  } catch (error) { status.textContent = error.message; }
}

// ── Expense dashboard ────────────────────────────────────────────────────────

function formatExpenseMoney(value, currency) {
  if (value == null || !Number.isFinite(Number(value)) || !currency) return '—';
  return new Intl.NumberFormat(undefined, {
    style: 'currency',
    currency,
    maximumFractionDigits: 2,
  }).format(Number(value));
}

async function loadExpenseCategories() {
  const select = document.getElementById('expenses-category');
  if (!select || select.options.length > 1) return;
  try {
    const resp = await fetch('/api/expenses/categories');
    if (!resp.ok) return;
    const data = await resp.json();
    select.innerHTML = '<option value="">All categories</option>'
      + (data.categories || []).map((category) => `<option value="${escapeHtml(category.key)}">${escapeHtml(category.label)}</option>`).join('');
  } catch (error) {
    console.error('Expense category load failed', error);
  }
}

let pendingExpenseRefresh = null;

async function loadExpenses(force = false, offset = null) {
  offset = offset ?? (expenseSnapshot?.offset || 0);
  if (expensesLoading) {
    if (force) pendingExpenseRefresh = {offset};
    return;
  }
  if (!force && expenseSnapshot) return;
  expensesLoading = true;
  const status = document.getElementById('expenses-status');
  const refreshButton = document.getElementById('expenses-refresh');
  if (status) {
    status.className = 'portfolio-status neutral';
    status.textContent = 'Loading…';
  }
  if (refreshButton) refreshButton.disabled = true;
  await loadExpenseCategories();
  const period = document.getElementById('expenses-period')?.value || 'month';
  const category = document.getElementById('expenses-category')?.value || '';
  const query = new URLSearchParams({period, offset: String(offset), limit: '200'});
  if (category) query.set('category', category);
  try {
    const resp = await fetch(`/api/expenses?${query.toString()}`, {cache: 'no-store'});
    if (resp.status === 401) { window.location.assign('/login'); return; }
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.detail || 'Expenses could not be loaded.');
    renderExpenses(data);
    void loadBankConnections();
  } catch (error) {
    console.error('Expense load failed', error);
    renderExpensesError(error.message);
  } finally {
    expensesLoading = false;
    if (refreshButton) refreshButton.disabled = false;
    if (pendingExpenseRefresh) {
      const pending = pendingExpenseRefresh;
      pendingExpenseRefresh = null;
      void loadExpenses(true, pending.offset);
    }
  }
}

function renderExpensesError(message) {
  const status = document.getElementById('expenses-status');
  if (status) {
    status.className = 'portfolio-status error';
    status.textContent = 'Unavailable';
  }
  document.getElementById('expenses-updated').textContent = message;
  document.getElementById('expenses-alerts').innerHTML = `<div class="portfolio-alert error">${escapeHtml(message)}</div>`;
}

function renderExpenseCategoryBars(categories, currency) {
  const el = document.getElementById('expenses-category-bars');
  const count = document.getElementById('expenses-category-count');
  if (!el) return;
  count.textContent = String(categories.length);
  if (!categories.length) {
    el.innerHTML = '<div class="table-empty">No spending categories in this period.</div>';
    return;
  }
  const max = Math.max(...categories.map((item) => Number(item.amount) || 0), 1);
  el.innerHTML = categories.map((item) => {
    const width = Math.max(4, Math.round((Number(item.amount) / max) * 100));
    return `<div class="expense-category-row">
      <div class="expense-category-head"><span>${escapeHtml(item.label)}</span><strong>${formatExpenseMoney(item.amount, currency)}</strong></div>
      <div class="expense-category-track"><span style="width:${width}%"></span></div>
      <div class="expense-category-meta">${Number(item.percentage || 0).toFixed(1)}% · ${item.transaction_count} transaction${item.transaction_count === 1 ? '' : 's'}</div>
    </div>`;
  }).join('');
}

function renderExpenseTransactions(transactions, currency) {
  const body = document.getElementById('expenses-transactions-body');
  const empty = document.getElementById('expenses-transactions-empty');
  const count = document.getElementById('expenses-transaction-count');
  if (!body) return;
  const rows = (transactions || []).slice(0, 200);
  count.textContent = `${rows.length} record${rows.length === 1 ? '' : 's'}`;
  body.innerHTML = rows.map((transaction) => {
    const isIncome = ['income', 'refund'].includes(transaction.transaction_type);
    const isTransfer = transaction.transaction_type === 'transfer';
    const amountClass = isIncome ? 'up' : isTransfer ? '' : 'down';
    const signed = transaction.signed_amount;
    const amountPrefix = signed != null ? (String(signed).startsWith('-') ? '−' : '+') : isIncome ? '+' : isTransfer ? '' : '−';
    const date = new Date(transaction.occurred_at);
    const dateLabel = Number.isNaN(date.getTime()) ? '—' : date.toLocaleDateString([], {month: 'short', day: 'numeric'});
    return `<tr>
      <td><div class="asset-cell"><span class="asset-symbol">${escapeHtml(transaction.merchant)}</span><span class="asset-meta">${escapeHtml(transaction.description || transaction.provider || '')}</span></div></td>
      <td><label class="asset-meta" for="category-${escapeHtml(transaction.id)}">Category</label>
      <select id="category-${escapeHtml(transaction.id)}" data-transaction="${escapeHtml(transaction.id)}" onchange="changeExpenseCategory(this)">
      ${Array.from(document.getElementById('expenses-category').options).filter(option => option.value).map(option => `<option value="${escapeHtml(option.value)}" ${option.value === transaction.category ? 'selected' : ''}>${escapeHtml(option.textContent)}</option>`).join('')}
      </select><span class="asset-meta">${escapeHtml(transaction.subcategory || '')}</span></td>
      <td>${escapeHtml(transaction.account_name || 'Bank account')}</td>
      <td>${escapeHtml(dateLabel)}${transaction.pending ? ' · pending' : ''}
        ${transaction.pending ? `<button class="dashboard-btn" data-transaction="${escapeHtml(transaction.id)}" onclick="selectPendingReconciliation(this.dataset.transaction)">Resolve pending</button>`
          : expensePendingId && ['booked', 'revised'].includes(transaction.lifecycle)
            ? `<button class="dashboard-btn" data-transaction="${escapeHtml(transaction.id)}" onclick="previewPendingReconciliation(this.dataset.transaction)">Review as booked match</button>` : ''}
      </td>
      <td class="${amountClass}">${amountPrefix}${formatExpenseMoney(transaction.amount_exact ?? transaction.amount, transaction.currency)}</td>
    </tr>`;
  }).join('');
  empty.hidden = rows.length > 0;
}

function renderExpenses(data) {
  expenseSnapshot = data;
  const currency = data.currency;
  const categories = data.category_totals || [];
  const transactions = data.transactions || [];
  const sync = data.sync || {};
  const hasData = transactions.length > 0 || Number(data.total_expenses || 0) > 0 || Number(data.total_income || 0) > 0;
  const status = document.getElementById('expenses-status');
  status.className = `portfolio-status ${hasData ? 'ready' : 'neutral'}`;
  status.textContent = hasData ? 'Imported data' : 'Not connected';
  document.getElementById('expenses-updated').textContent = sync.provider_last_success_at
    ? `Latest provider success ${formatMessageTime(sync.provider_last_success_at)} · ${data.period_start} → ${data.period_end}`
    : `${data.period_start} → ${data.period_end} · ${sync.message || 'Waiting for a bank feed'}`;
  document.getElementById('expenses-total').textContent = formatExpenseMoney(data.total_expenses, currency);
  document.getElementById('expenses-income').textContent = formatExpenseMoney(data.total_income, currency);
  const net = document.getElementById('expenses-net');
  net.textContent = formatExpenseMoney(data.net_cashflow, currency);
  net.classList.toggle('up', Number(data.net_cashflow) > 0);
  net.classList.toggle('down', Number(data.net_cashflow) < 0);
  document.getElementById('expenses-count').textContent = `${data.transaction_count || 0} expense transaction${data.transaction_count === 1 ? '' : 's'}`;
  const top = categories[0];
  document.getElementById('expenses-top-category').textContent = top?.label || '—';
  document.getElementById('expenses-top-category-note').textContent = top
    ? formatExpenseMoney(top.amount, currency)
    : 'Waiting for data';
  document.getElementById('expenses-sync-message').textContent = sync.message || 'Connect a provider to receive transaction updates.';
  document.getElementById('expenses-stream-state').textContent = expenseStream?.readyState === EventSource.OPEN ? 'Streaming' : 'Ready';
  document.getElementById('expenses-stream-state').className = `account-state ${hasData ? '' : 'error'}`;
  renderExpenseCategoryBars(categories, currency);
  renderExpenseTransactions(transactions, currency);
  document.getElementById('expenses-empty').hidden = hasData;
  document.getElementById('expenses-content').hidden = !hasData && !data.offset;
  document.getElementById('expenses-prev').disabled = !data.offset;
  document.getElementById('expenses-next').disabled = data.next_offset == null;
  const currencyTotals = Object.entries(data.totals_by_currency || {});
  const notes = currencyTotals.length > 1
    ? currencyTotals.map(([code, values]) => `${code}: expenses ${values.total_expenses}, income ${values.total_income}`).join(' · ')
    : '';
  document.getElementById('expenses-alerts').textContent = [notes,
    data.summary_scope === 'page' ? 'Totals cover the displayed page.' : '',
    data.next_offset != null ? 'More transactions are available through pagination.' : '',
    sync.last_received_at ? `Application received data ${formatMessageTime(sync.last_received_at)}.` : '',
    sync.provider_last_success_at ? 'The latest provider timestamp covers your connections; it does not guarantee every account is current.' : 'No successful provider synchronization recorded.'
  ].filter(Boolean).join(' ');
}

function connectExpenseStream() {
  if (expenseStream && [EventSource.OPEN, EventSource.CONNECTING].includes(expenseStream.readyState)) return;
  if (expenseStream) expenseStream.close();
  expenseStream = new EventSource('/api/expenses/stream');
  expenseStream.onopen = () => {
    const state = document.getElementById('expenses-stream-state');
    if (state) { state.textContent = 'Streaming'; state.className = 'account-state'; }
  };
  expenseStream.addEventListener('expenses_updated', () => loadExpenses(true));
  expenseStream.onerror = () => {
    const state = document.getElementById('expenses-stream-state');
    if (state) { state.textContent = 'Reconnecting'; state.className = 'account-state error'; }
  };
}

function showExpenseSyncHelp() {
  document.getElementById('expenses-alerts').innerHTML = '<div class="portfolio-alert"><strong>How this becomes live:</strong> a bank-data provider asks you to consent at your bank, fetches transactions, and sends them through the expense import contract. GoCardless Bank Account Data is the first provider boundary, covering EEA PSD2 banks; bank rate limits and consent renewal still apply. <a href="https://developer.gocardless.com/bank-account-data/overview/" target="_blank" rel="noopener">Read the provider docs ↗</a></div>';
}

// ── Fake-money simulation dashboard ─────────────────────────────────────────

function updateSimulationFields() {
  const strategy = document.getElementById('simulation-strategy')?.value;
  const showSma = strategy === 'sma_crossover';
  const showMomentum = strategy === 'momentum';
  ['simulation-fast-wrap', 'simulation-slow-wrap'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.hidden = !showSma;
  });
  ['simulation-lookback-wrap', 'simulation-topn-wrap'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.hidden = !showMomentum;
  });
}

function defaultSimulationStart() {
  const date = new Date();
  date.setFullYear(date.getFullYear() - 1);
  return date.toISOString().slice(0, 10);
}

function setSimulationStatus(text, state = 'neutral') {
  const el = document.getElementById('simulation-status');
  if (!el) return;
  el.className = `portfolio-status ${state}`;
  el.textContent = text;
}

function renderSimulationCurve(curve, currency) {
  const el = document.getElementById('simulation-equity-curve');
  if (!el) return;
  if (!curve?.length) {
    el.textContent = 'No equity curve was returned.';
    return;
  }
  const values = curve.map((point) => Number(point.value) || 0);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = Math.max(1, max - min);
  el.innerHTML = curve.slice(-24).map((point) => {
    const value = Number(point.value) || 0;
    const height = Math.max(8, Math.round(((value - min) / span) * 92) + 8);
    return `<div class="simulation-bar-wrap" title="${escapeHtml(point.date)}: ${formatExpenseMoney(value, currency)}">
      <div class="simulation-bar" style="height:${height}%"></div><span>${escapeHtml(point.date.slice(5))}</span></div>`;
  }).join('');
}

function renderSimulationResult(result) {
  document.getElementById('simulation-result').hidden = false;
  document.getElementById('simulation-result-title').textContent = result.name || 'Latest run';
  document.getElementById('sim-result-period').textContent = `${result.period_start} → ${result.period_end}`;
  const currency = result.base_currency || result.strategy?.base_currency;
  document.getElementById('sim-final-value').textContent = formatExpenseMoney(result.final_value, currency);
  const research = result.research_summary;
  document.getElementById('simulation-research-note').textContent = research
    ? `Research evidence is insufficient for live use. Fees: ${formatExpenseMoney(research.fees, currency)}. Dividend cash received: ${research.dividends_paid == null ? 'unavailable' : formatExpenseMoney(research.dividends_paid, currency)}; unpaid receivables: ${research.dividend_receivable == null ? 'unavailable' : formatExpenseMoney(research.dividend_receivable, currency)}. Valuation: ${research.valuation_status || 'unverified'}. Open positions are marked, not recorded as sales. ${(research.source?.limitations || []).join('. ')}`
    : 'Legacy result: source currency and cost-aware evidence are unavailable.';
  const evidenceLink = document.getElementById('simulation-evidence-link');
  evidenceLink.hidden = !result.evidence_available;
  if (result.evidence_available) evidenceLink.href = `/api/simulations/${encodeURIComponent(result.id)}/evidence`;
  document.getElementById('sim-return').textContent = `${Number(result.total_return_pct || 0) >= 0 ? '+' : ''}${Number(result.total_return_pct || 0).toFixed(2)}%`;
  document.getElementById('sim-drawdown').textContent = result.max_drawdown_pct == null ? 'n/a' : `${Number(result.max_drawdown_pct).toFixed(2)}%`;
  document.getElementById('sim-trades').textContent = String(result.trades_count ?? 0);
  renderSimulationCurve(result.equity_curve, currency);
}

function renderSimulationHistory(runs) {
  const el = document.getElementById('simulation-history');
  if (!el) return;
  if (!runs?.length) {
    el.textContent = 'No simulations saved yet.';
    return;
  }
  simulationRuns.clear();
  runs.forEach((run) => simulationRuns.set(run.id, run));
  el.innerHTML = runs.map((run) => `
    <button class="simulation-history-row" onclick="showSimulationRun('${escapeHtml(run.id)}')">
      <span><strong>${escapeHtml(run.name)}</strong><small>${escapeHtml(run.period_start)} → ${escapeHtml(run.period_end)}</small></span>
      <span class="${Number(run.total_return_pct) >= 0 ? 'up' : 'down'}">${Number(run.total_return_pct) >= 0 ? '+' : ''}${Number(run.total_return_pct).toFixed(2)}%</span>
    </button>`).join('');
}

function showSimulationRun(id) {
  const run = simulationRuns.get(id);
  if (run) renderSimulationResult(run);
}

async function loadSimulations() {
  const el = document.getElementById('simulation-history');
  if (!el) return;
  try {
    const resp = await fetch('/api/simulations', {cache: 'no-store'});
    if (resp.status === 401) { window.location.assign('/login'); return; }
    if (!resp.ok) throw new Error('Simulation history unavailable.');
    renderSimulationHistory(await resp.json());
  } catch (error) {
    el.textContent = error.message;
  }
}

async function submitSimulation(event) {
  event.preventDefault();
  const strategyType = document.getElementById('simulation-strategy').value;
  const params = {};
  if (strategyType === 'sma_crossover') {
    params.fast = Number(document.getElementById('simulation-fast').value);
    params.slow = Number(document.getElementById('simulation-slow').value);
  } else if (strategyType === 'momentum') {
    params.lookback_days = Number(document.getElementById('simulation-lookback').value);
    params.top_n = Number(document.getElementById('simulation-topn').value);
  }
  const button = document.getElementById('simulation-run-btn');
  button.disabled = true;
  setSimulationStatus('Running…', 'neutral');
  try {
    const resp = await fetch('/api/simulations', {
      method: 'POST',
      headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({
        name: `${strategyType.replaceAll('_', ' ')} — ${document.getElementById('simulation-symbols').value}`,
        symbols: document.getElementById('simulation-symbols').value,
        strategy: {type: strategyType, params},
        initial_capital: Number(document.getElementById('simulation-capital').value),
        base_currency: document.getElementById('simulation-currency').value,
        period_start: document.getElementById('simulation-start').value,
        period_end: document.getElementById('simulation-end').value || null,
      }),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.detail || 'Simulation failed.');
    renderSimulationResult(data);
    setSimulationStatus('Complete', 'ready');
    await loadSimulations();
  } catch (error) {
    setSimulationStatus(error.message, 'error');
  } finally {
    button.disabled = false;
  }
}

// ── Utilities ──────────────────────────────────────────────────────────────────

function messagesEl() { return document.getElementById('messages'); }
function scrollBottom() {
  const el = messagesEl();
  el.scrollTop = el.scrollHeight;
}
function setSendEnabled(enabled) {
  const canSend = enabled && ws?.readyState === WebSocket.OPEN;
  document.getElementById('send-btn').disabled = !canSend;
  document.getElementById('user-input').disabled = !canSend;
}
function setStatus(state) {
  const el = document.getElementById('connection-status');
  el.className = 'conn-status ' + state;
  if (state === 'online') el.textContent = 'Connected';
  else if (state === 'connecting') el.textContent = 'Connecting…';
  else el.textContent = 'Disconnected';
}
function timeNow() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function formatMessageTime(value) {
  const date = value ? new Date(value) : new Date();
  return Number.isNaN(date.getTime())
    ? timeNow()
    : date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function escapeHtml(str) {
  return String(str).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
}

/**
 * Replace fenced code blocks (``` … ```) using a linear indexOf scan.
 * Regex-based approaches require backtracking over the block content and are
 * vulnerable to super-linear runtime when there is no closing fence.
 */
function replaceCodeBlocks(html) {
  const FENCE = '```';
  let result = '';
  let pos = 0;
  while (pos < html.length) {
    const open = html.indexOf(FENCE, pos);
    if (open === -1) { result += html.slice(pos); break; }
    result += html.slice(pos, open);
    const bodyStart = open + FENCE.length;
    const close = html.indexOf(FENCE, bodyStart);
    if (close === -1) { result += html.slice(open); break; } // unclosed fence — leave as-is
    const body = html.slice(bodyStart, close);
    const nl = body.indexOf('\n');
    const code = (nl >= 0 ? body.slice(nl + 1) : body).trim(); // strip optional language hint
    result += `<pre><code>${code}</code></pre>`;
    pos = close + FENCE.length;
  }
  return result;
}

/** Very minimal Markdown → HTML for chat messages. */
function markdownToHtml(md) {
  let html = escapeHtml(md);
  // Code blocks — handled by linear scan above (no regex backtracking)
  html = replaceCodeBlocks(html);
  // Inline code
  html = html.replaceAll(/`([^`]+)`/g, '<code>$1</code>');
  // Bold
  html = html.replaceAll(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  // Italic
  html = html.replaceAll(/\*(.+?)\*/g, '<em>$1</em>');
  // Headers
  html = html.replaceAll(/^### (.+)$/gm, '<h3>$1</h3>');
  html = html.replaceAll(/^## (.+)$/gm, '<h2>$1</h2>');
  html = html.replaceAll(/^# (.+)$/gm, '<h1>$1</h1>');
  // Unordered list
  html = html.replaceAll(/^[-*] (.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>)+/s, '<ul>$&</ul>');
  // Ordered list
  html = html.replaceAll(/^\d+\. (.+)$/gm, '<li>$1</li>');
  // Horizontal rule
  html = html.replaceAll(/^---$/gm, '<hr>');
  // Paragraphs (blank lines)
  html = html.replaceAll(/\n\n+/g, '</p><p>');
  html = html.replaceAll('\n', '<br>');
  return `<p>${html}</p>`;
}

function clampPanelSize(value, min, max) {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue)) return min;
  return Math.min(Math.max(numericValue, min), max);
}

function readStoredPanelSize(key, fallback, min, max) {
  try {
    const storedValue = Number(globalThis.localStorage.getItem(key));
    return Number.isFinite(storedValue) ? clampPanelSize(storedValue, min, max) : fallback;
  } catch {
    return fallback;
  }
}

function storePanelSize(key, value) {
  try {
    globalThis.localStorage.setItem(key, String(Math.round(value)));
  } catch {
    // Private browsing and locked-down web views can disable local storage.
  }
}

function setSidebarWidth(width, persist = false) {
  const value = clampPanelSize(width, SIDEBAR_WIDTH_MIN, SIDEBAR_WIDTH_MAX);
  document.documentElement.style.setProperty('--sidebar-w', `${value}px`);
  const resizer = document.getElementById('sidebar-resizer');
  resizer?.setAttribute('aria-valuenow', String(Math.round(value)));
  if (persist) storePanelSize(SIDEBAR_WIDTH_KEY, value);
  return value;
}

function setupPanelResizers() {
  setSidebarWidth(readStoredPanelSize(SIDEBAR_WIDTH_KEY, 280, SIDEBAR_WIDTH_MIN, SIDEBAR_WIDTH_MAX));

  const sidebarResizer = document.getElementById('sidebar-resizer');
  if (sidebarResizer) {
    let resizeState = null;
    const stopSidebarResize = () => {
      if (!resizeState) return;
      setSidebarWidth(resizeState.width, true);
      resizeState = null;
      sidebarResizer.classList.remove('is-active');
      document.body.classList.remove('is-resizing-sidebar');
    };

    sidebarResizer.addEventListener('pointerdown', (event) => {
      if (globalThis.matchMedia?.('(max-width: 768px)').matches) return;
      event.preventDefault();
      const currentWidth = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--sidebar-w')) || 280;
      resizeState = { startX: event.clientX, width: currentWidth };
      sidebarResizer.classList.add('is-active');
      document.body.classList.add('is-resizing-sidebar');
      sidebarResizer.setPointerCapture?.(event.pointerId);
    });
    sidebarResizer.addEventListener('pointermove', (event) => {
      if (!resizeState) return;
      resizeState.width = setSidebarWidth(resizeState.width + event.clientX - resizeState.startX);
      resizeState.startX = event.clientX;
    });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((eventName) => {
      sidebarResizer.addEventListener(eventName, stopSidebarResize);
    });
    sidebarResizer.addEventListener('keydown', (event) => {
      const currentWidth = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--sidebar-w')) || 280;
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault();
        setSidebarWidth(currentWidth + (event.key === 'ArrowRight' ? 16 : -16), true);
      } else if (event.key === 'Home' || event.key === 'End') {
        event.preventDefault();
        setSidebarWidth(event.key === 'End' ? SIDEBAR_WIDTH_MAX : SIDEBAR_WIDTH_MIN, true);
      }
    });
  }

}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('hidden');
}

// ── Init ──────────────────────────────────────────────────────────────────────

globalThis.addEventListener('DOMContentLoaded', async () => {
  setupPanelResizers();
  if (window.matchMedia?.('(max-width: 768px)').matches) {
    document.getElementById('sidebar').classList.add('hidden');
  }
  await loadConversationWorkspace();
  await loadHistory();
  await loadProfile();
  loadBrokerAccounts();
  connect();
  loadSnapshot();
  loadSafety();
  loadReports();
  const startInput = document.getElementById('simulation-start');
  if (startInput) startInput.value = defaultSimulationStart();
  updateSimulationFields();
  setInterval(loadSnapshot, 5 * 60 * 1000); // auto-refresh every 5 min
  setInterval(() => {
    if (!document.getElementById('expenses-view')?.hidden) loadExpenses(true);
  }, 30 * 1000); // bank feeds are refreshed as often as provider limits allow
  setSendEnabled(true);
});

// Synthetic order practice uses separate human actions; chat tools cannot approve.
let executionFixture = null;
let executionProposal = null;
async function fixtureRequest(path, body = {}) {
  const response = await fetch('/api/simulator' + path, {method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
    body: JSON.stringify(body)});
  const result = await response.json();
  if (!response.ok) throw new Error(result.detail?.reason_code || result.detail || 'Simulator unavailable');
  return result;
}
function fixtureDisplay(value) {
  document.getElementById('fixture-approve').disabled = true;
  document.getElementById('fixture-mandate-approve').disabled = true;
  document.getElementById('fixture-details').textContent = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
}
async function createExecutionFixture() {
  try {
    executionFixture = await fixtureRequest('/fixtures', {manual_sales: document.getElementById('fixture-allow-sales').checked});
    document.querySelector('#fixture-side option[value="sell"]').disabled = !executionFixture.manual_sales;
    document.getElementById('fixture-side').value = 'buy';
    executionProposal = null;
    executionMandate = null;
    document.getElementById('fixture-valuation-capture').disabled = false;
    document.getElementById('fixture-valuation-compare').disabled = true;
    document.getElementById('fixture-valuation-start').replaceChildren();
    document.getElementById('fixture-valuation-end').replaceChildren();
    document.getElementById('fixture-valuation-status').textContent = 'No saved observations for this practice account.';
    document.getElementById('fixture-mandate-review').disabled = false;
    fixtureDisplay(executionFixture);
    document.getElementById('fixture-propose').disabled = false;
    document.getElementById('fixture-halt').disabled = false;
    document.getElementById('fixture-approve').disabled = true;
    document.getElementById('fixture-tick').disabled = true;
  } catch (error) { fixtureDisplay(error.message); }
}
async function proposeFixtureOrder() {
  try {
    executionProposal = await fixtureRequest(`/accounts/${executionFixture.account_id}/proposals`, {
      instrument_id: executionFixture.instrument_id, side: document.getElementById('fixture-side').value,
      quantity: '1', limit_price: '100', idempotency_key: crypto.randomUUID()});
    // Nonce is kept in memory, not rendered or stored in browser persistence.
    const {nonce, ...display} = executionProposal;
    fixtureDisplay(display);
    document.getElementById('fixture-approve').disabled = false;
  } catch (error) { fixtureDisplay(error.message); }
}
async function approveFixtureOrder() {
  document.getElementById('fixture-approve').disabled = true;
  try {
    fixtureDisplay(await fixtureRequest(`/accounts/${executionFixture.account_id}/orders/${executionProposal.order_id}/approve`, {
      nonce: executionProposal.nonce, details_hash: executionProposal.details_hash}));
    document.getElementById('fixture-tick').disabled = false;
  } catch (error) { fixtureDisplay(error.message); }
}
async function tickFixtureOrder() {
  document.getElementById('fixture-tick').disabled = true;
  try { fixtureDisplay(await fixtureRequest(`/accounts/${executionFixture.account_id}/orders/${executionProposal.order_id}/tick`)); }
  catch (error) { fixtureDisplay(error.message); }
}
async function haltFixtureAccount() {
  try {
    fixtureDisplay(await fixtureRequest(`/accounts/${executionFixture.account_id}/halt`));
    document.getElementById('fixture-propose').disabled = true;
    await loadOperationalAlerts();
  } catch (error) { fixtureDisplay(error.message); }
}

// A desktop sidebar must not obscure the main workflow after a narrow resize.
globalThis.matchMedia?.('(max-width: 768px)').addEventListener('change', (event) => {
  if (event.matches) document.getElementById('sidebar').classList.add('hidden');
});

async function loadOperationalAlerts() {
  const target = document.getElementById('operational-alerts');
  try {
    const response = await fetch('/api/alerts', {cache: 'no-store'});
    if (!response.ok) throw new Error('Alerts unavailable');
    const alerts = await response.json();
    target.replaceChildren();
    for (const alert of alerts) {
      const row = document.createElement('div');
      row.textContent = `${alert.severity}: ${alert.message} (${alert.status}) `;
      if (alert.status === 'open') {
        const button = document.createElement('button');
        button.className = 'dashboard-btn';
        button.textContent = 'Acknowledge';
        button.onclick = async () => {
          const result = await fetch(`/api/alerts/${encodeURIComponent(alert.id)}/acknowledge`, {
            method: 'POST', headers: {'X-CSRF-Token': csrfToken()}});
          if (result.ok) await loadOperationalAlerts();
          else target.textContent = 'Alert acknowledgment failed';
        };
        row.append(button);
      }
      target.append(row);
    }
    if (!alerts.length) target.textContent = 'No monitoring alerts.';
  } catch (error) { target.textContent = error.message; }
}

let executionMandate = null;
async function reviewFixtureMandate() {
  document.getElementById('fixture-mandate-approve').disabled = true;
  try {
    const strategy = document.getElementById('fixture-mandate-strategy').value;
    const thresholds = strategy === 'price_band_fixture' ? {
      buy_below: document.getElementById('fixture-buy-below').value,
      sell_above: document.getElementById('fixture-sell-above').value
    } : {};
    executionMandate = await fixtureRequest(`/accounts/${executionFixture.account_id}/mandates`, {
      environment: 'simulator', strategy, strategy_version: '1', ...thresholds,
      instrument_ids: [executionFixture.instrument_id], capital_limit: '500', max_position: '300',
      max_order: '150', daily_loss_limit: '25', drawdown_limit: '40', max_orders_per_day: 3,
      min_interval_seconds: 60, max_quote_age_seconds: 30, max_fee_bps: '10', max_spread_bps: '5',
      trading_timezone: 'UTC', start_hour: 0, end_hour: 24, weekdays: [0,1,2,3,4,5,6],
      expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString(), quantity_per_order: '1'
    });
    const {nonce, ...display} = executionMandate;
    fixtureDisplay(display);
    document.getElementById('fixture-mandate-approve').disabled = false;
  } catch (error) { fixtureDisplay(error.message); }
}
async function approveFixtureMandate() {
  document.getElementById('fixture-mandate-approve').disabled = true;
  try {
    fixtureDisplay(await fixtureRequest(`/accounts/${executionFixture.account_id}/mandates/${executionMandate.mandate_id}/approve`, {
      nonce: executionMandate.nonce, details_hash: executionMandate.details_hash
    }));
  } catch (error) { fixtureDisplay(error.message); }
}

async function importExpenseFile() {
  const file = document.getElementById('expense-import-file').files[0];
  const status = document.getElementById('expense-import-status');
  const button = document.getElementById('expense-import-submit');
  button.disabled = true;
  try {
    if (!file) throw new Error('Choose a JSON file first.');
    if (file.size > 1024 * 1024) throw new Error('Import files must be at most 1 MiB.');
    const body = JSON.parse(await file.text());
    if (!body || !Array.isArray(body.transactions)) throw new Error('Expected an object with a transactions array.');
    const response = await fetch('/api/expenses/import', {method: 'POST',
      headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify(body)});
    const result = await response.json();
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : 'Import unavailable.');
    status.textContent = `Imported ${result.imported}; updated ${result.updated}; skipped retired ${result.suppressed_retired || 0}. Bank connectivity is unchanged.`;
    await loadExpenses(true);
  } catch (error) {
    status.textContent = error instanceof SyntaxError ? 'The file is not valid JSON.' : error.message;
  } finally { button.disabled = false; }
}

async function changeExpenseCategory(control) {
  control.disabled = true;
  try {
    const response = await fetch(`/api/expenses/${encodeURIComponent(control.dataset.transaction)}/category`, {
      method: 'PATCH', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({category: control.value})});
    const result = await response.json();
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : 'Category update failed.');
    await loadExpenses(true, expenseSnapshot?.offset || 0);
  } catch (error) {
    document.getElementById('expense-import-status').textContent = error.message;
    await loadExpenses(true, expenseSnapshot?.offset || 0);
  } finally { control.disabled = false; }
}
function exportExpensePage() {
  if (!expenseSnapshot) return;
  const data = {scope: 'displayed_page', period_start: expenseSnapshot.period_start,
    period_end: expenseSnapshot.period_end, offset: expenseSnapshot.offset,
    next_offset: expenseSnapshot.next_offset, transactions: expenseSnapshot.transactions};
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'}));
  const link = document.createElement('a');
  link.href = url; link.download = 'expense-page.json'; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function bankRequest(path, method = 'GET', body) {
  const response = await fetch(`/api/banks${path}`, {method, cache: 'no-store',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
    ...(body === undefined ? {} : {body: JSON.stringify(body)})});
  const result = await response.json();
  if (!response.ok) throw new Error(result.detail?.reason_code || (typeof result.detail === 'string' ? result.detail : 'Bank service unavailable.'));
  return result;
}

async function loadBankConnections() {
  const status = document.getElementById('bank-access-status');
  const button = document.getElementById('bank-consent');
  button.disabled = true;
  try {
    const data = await bankRequest('');
    button.disabled = !data.consent_setup_available;
    status.textContent = data.external_access_enabled
      ? (data.consent_setup_available ? 'Provider access configured. Bank consent and account selection are still required.' : 'Bank access enabled, but provider consent credentials are unavailable.')
      : 'Bank access is disabled. Transaction file imports remain available.';
    const container = document.getElementById('bank-connections');
    container.replaceChildren();
    for (const connection of data.connections || []) {
      const row = document.createElement('div');
      const text = document.createElement('p');
      text.textContent = `${connection.provider}: ${connection.status}${connection.error_code ? ` · ${connection.error_code}` : ''}. Latest provider success: ${connection.provider_last_success_at ? formatMessageTime(connection.provider_last_success_at) : 'never'}. Application receipt: ${connection.last_received_at ? formatMessageTime(connection.last_received_at) : 'never'}.`;
      row.append(text);
      const action = (label, handler, disabled = false) => {
        const control = document.createElement('button');
        control.className = 'dashboard-btn'; control.textContent = label; control.disabled = disabled;
        control.addEventListener('click', async () => {
          control.disabled = true;
          try { await handler(); } catch (error) { document.getElementById('bank-action-status').textContent = error.message; }
          finally { control.disabled = disabled; }
        });
        row.append(control);
      };
      const historyLabel = document.createElement('label');
      historyLabel.textContent = 'Retrieve bank history from ';
      const historyDate = document.createElement('input');
      historyDate.type = 'date'; historyDate.setAttribute('aria-label', 'Bank history start date');
      const today = new Date();
      historyDate.max = today.toISOString().slice(0, 10);
      historyDate.min = new Date(today.getTime() - 730 * 86400000).toISOString().slice(0, 10);
      const historyDisabled = !data.external_access_enabled || !['connected', 'retry_wait'].includes(connection.status);
      historyDate.disabled = historyDisabled;
      historyLabel.append(historyDate); row.append(historyLabel);
      action('Retrieve older history', async () => {
        if (!historyDate.value || !historyDate.checkValidity()) throw new Error('Choose a valid start date within the last 730 days.');
        const result = await bankRequest(`/${encodeURIComponent(connection.id)}/history`, 'POST', {date_from: historyDate.value});
        document.getElementById('bank-action-status').textContent = result.status === 'complete'
          ? 'History retrieval finished. Provider coverage may be limited; missing transactions were not deleted.'
          : (result.error_code || 'History retrieval is waiting for provider retry.');
        await loadBankConnections();
        if (result.status === 'complete') await loadExpenses(true);
      }, historyDisabled);
      const historyNote = document.createElement('p');
      const history = connection.last_history_retrieval;
      historyNote.textContent = history
        ? `Last history request: from ${history.requested_from}, received ${formatMessageTime(history.completed_at)} (${history.records} records). Complete coverage is not verified.`
        : 'Older corrections require a history request. Available history depends on bank consent and provider coverage; missing records are kept.';
      row.append(historyNote);
      action('Choose consented account', () => chooseBankAccount(connection.id, row), !data.external_access_enabled);
      action('Renew bank consent', () => beginBankConsent(connection.id), !data.consent_setup_available);
      action('Stop local synchronization', async () => {
        await bankRequest(`/${encodeURIComponent(connection.id)}`, 'DELETE');
        document.getElementById('bank-action-status').textContent = 'Local synchronization stopped and local tokens removed. Revoke provider consent at your bank or provider separately.';
        await loadBankConnections();
      }, connection.status === 'disconnected');
      container.append(row);
    }
  } catch (error) { status.textContent = error.message; }
}

async function beginBankConsent(connectionId) {
  const status = document.getElementById('bank-action-status');
  const button = document.getElementById('bank-consent');
  button.disabled = true;
  status.replaceChildren();
  try {
    const institution = document.getElementById('bank-institution').value.trim();
    if (!/^[A-Za-z0-9_-]{1,128}$/.test(institution)) throw new Error('Enter the institution identifier from your provider setup.');
    const result = await bankRequest(connectionId ? `/${encodeURIComponent(connectionId)}/reconnect` : '/consent', 'POST', {institution});
    const url = new URL(result.consent_url);
    if (url.protocol !== 'https:' || url.hostname !== 'ob.gocardless.com' || url.username || url.password || (url.port && url.port !== '443')) throw new Error('Provider consent link was rejected.');
    const link = document.createElement('a');
    link.href = url.href; link.target = '_blank'; link.rel = 'noopener noreferrer';
    link.textContent = 'Continue consent at the bank provider';
    status.append(link, document.createTextNode('. Return here after consent and choose the authorized account.'));
    await loadBankConnections();
  } catch (error) { status.textContent = error.message; }
  finally { await loadBankConnections(); }
}

async function chooseBankAccount(connectionId, row) {
  row.querySelector('[data-bank-selection]')?.remove();
  const result = await bankRequest(`/${encodeURIComponent(connectionId)}/accounts`);
  if (!result.accounts?.length) throw new Error('No consented accounts returned. Complete bank consent first.');
  const selection = document.createElement('div'); selection.dataset.bankSelection = 'true';
  const select = document.createElement('select'); select.setAttribute('aria-label', 'Consented bank account');
  for (const account of result.accounts) {
    const option = document.createElement('option'); option.value = account.handle; option.textContent = account.label; select.append(option);
  }
  const button = document.createElement('button'); button.textContent = 'Use selected account'; button.className = 'dashboard-btn';
  button.addEventListener('click', async () => {
    button.disabled = true;
    try {
      await bankRequest(`/${encodeURIComponent(connectionId)}/account`, 'POST', {account_handle: select.value});
      document.getElementById('bank-action-status').textContent = 'Account selected. Scheduled retrieval is subject to bank availability and rate limits.';
      await loadBankConnections();
    } catch (error) { document.getElementById('bank-action-status').textContent = error.message; }
    finally { button.disabled = false; }
  });
  selection.append(select, button); row.append(selection);
}

function appendTurnEvidence(turn) {
  if (!turn) return;
  const note = document.createElement('div'); note.className = 'chat-evidence-note';
  const labels = {retired: 'Content removed by owner', complete: 'Saved answer', in_progress: 'Unfinished turn', failed: 'Incomplete answer', interrupted: 'Interrupted turn'};
  note.textContent = `${labels[turn.state] || 'Historical turn'} · ${turn.evidence_count || 0} saved tool observations. `;
  if (turn.omitted_events) note.append(document.createTextNode('Some events exceeded the evidence limit. '));
  if (/^\/api\/chat\/turns\/[A-Za-z0-9_-]{1,36}\/evidence$/.test(turn.evidence_url || '')) {
    const link = document.createElement('a'); link.href = turn.evidence_url; link.textContent = 'Download evidence';
    note.append(link);
  }
  note.append(document.createTextNode(' Historical evidence does not confirm a current broker fill.'));
  messagesEl().append(note);
}

async function exportExpensePeriod() {
  if (!expenseSnapshot) return;
  const button = document.getElementById('expenses-export-period');
  const status = document.getElementById('expense-import-status');
  button.disabled = true;
  try {
    const query = new URLSearchParams({from_date: expenseSnapshot.period_start, to_date: expenseSnapshot.period_end});
    const response = await fetch(`/api/expenses/export?${query}`, {cache: 'no-store'});
    if (!response.ok) throw new Error('Export unavailable.');
    const text = await response.text();
    const lines = text.trimEnd().split('\n');
    const completion = JSON.parse(lines[lines.length - 1]);
    if (completion.kind !== 'completion' || completion.status !== 'complete') throw new Error('Export did not complete. Try a narrower date interval.');
    const url = URL.createObjectURL(new Blob([text], {type: 'application/x-ndjson'}));
    const link = document.createElement('a'); link.href = url; link.download = 'expenses-period.jsonl';
    link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    status.textContent = `Exported ${completion.records} transactions across all categories in the selected period.`;
  } catch (error) { status.textContent = error.message; }
  finally { button.disabled = false; }
}

let expenseRetentionPlan = null;
function resetExpenseRetention() {
  expenseRetentionPlan = null;
  const approval = document.getElementById('expense-retention-confirm');
  approval.checked = false; approval.disabled = true;
  document.getElementById('expense-retention-apply').disabled = true;
  document.getElementById('expense-retention-status').textContent = 'Preview the chosen age before approving cleanup.';
}
function updateExpenseRetentionApproval() {
  document.getElementById('expense-retention-apply').disabled =
    !expenseRetentionPlan || !document.getElementById('expense-retention-confirm').checked;
}
async function previewExpenseRetention() {
  resetExpenseRetention();
  const days = Number(document.getElementById('expense-retain-days').value);
  const status = document.getElementById('expense-retention-status');
  if (!Number.isInteger(days) || days < 1 || days > 36525) {
    status.textContent = 'Enter a whole number of days between 1 and 36525.'; return;
  }
  const button = document.getElementById('expense-retention-preview'); button.disabled = true;
  try {
    const response = await fetch('/api/expenses/retention/preview', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({retain_days: days}),
    });
    if (!response.ok) throw new Error('Cleanup preview unavailable.');
    const plan = await response.json();
    // Changing the age while the request was in flight invalidates its response.
    if (Number(document.getElementById('expense-retain-days').value) !== days) return;
    if (!plan.count) { status.textContent = 'No raw copies match this age.'; return; }
    expenseRetentionPlan = plan;
    status.textContent = `${plan.count} raw copies in this batch. Preview expires after 10 minutes. ` +
      (plan.may_have_more ? 'Additional copies may need another preview. ' : '') + 'Transaction history remains.';
    document.getElementById('expense-retention-confirm').disabled = false;
  } catch (error) { status.textContent = error.message; }
  finally { button.disabled = false; }
}
async function applyExpenseRetention() {
  if (!expenseRetentionPlan || !document.getElementById('expense-retention-confirm').checked) return;
  const plan = expenseRetentionPlan;
  resetExpenseRetention();
  const status = document.getElementById('expense-retention-status');
  try {
    const response = await fetch('/api/expenses/retention/apply', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({policy: plan.policy, plan_sha256: plan.plan_sha256, confirm_raw_payload_removal: true}),
    });
    if (!response.ok) throw new Error('Cleanup did not complete. Preview again; the data or authorization may have changed.');
    const result = await response.json();
    status.textContent = `Removed ${result.removed_raw_payloads} raw copies. Transaction history remains.`;
  } catch (error) { status.textContent = error.message; }
}

let expenseHistoryPlan = null;
let expenseHistoryGeneration = 0;
function resetExpenseHistory() {
  expenseHistoryPlan = null;
  expenseHistoryGeneration += 1;
  const approval = document.getElementById('expense-history-confirm');
  approval.checked = false; approval.disabled = true;
  document.getElementById('expense-history-apply').disabled = true;
  document.getElementById('expense-history-status').textContent = 'Choose an age, then export and review before removal.';
}
function updateExpenseHistoryApproval() {
  document.getElementById('expense-history-apply').disabled =
    !expenseHistoryPlan || !document.getElementById('expense-history-confirm').checked;
}
async function previewExpenseHistory() {
  resetExpenseHistory();
  const generation = expenseHistoryGeneration;
  const days = Number(document.getElementById('expense-history-days').value);
  const status = document.getElementById('expense-history-status');
  if (!Number.isInteger(days) || days < 1 || days > 36525) {
    status.textContent = 'Enter a whole number of days between 1 and 36525.'; return;
  }
  const button = document.getElementById('expense-history-preview'); button.disabled = true;
  try {
    const response = await fetch('/api/expenses/retention/history/preview', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({retain_days: days}),
    });
    if (!response.ok) throw new Error('History preview unavailable.');
    const result = await response.json();
    if (generation !== expenseHistoryGeneration) return;
    if (!result.plan.count) { status.textContent = 'No settled history matches this age.'; return; }
    const url = URL.createObjectURL(new Blob([JSON.stringify(result.export, null, 2)], {type: 'application/json'}));
    const link = document.createElement('a'); link.href = url; link.download = 'expense-history-retention.json';
    link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    expenseHistoryPlan = result.plan;
    status.textContent = `${result.plan.count} transactions in this batch. Verify the downloaded export before approving. ` +
      'Preview expires after 10 minutes. ' + (result.plan.may_have_more ? 'More history may require another batch.' : '');
    document.getElementById('expense-history-confirm').disabled = false;
  } catch (error) { if (generation === expenseHistoryGeneration) status.textContent = error.message; }
  finally { button.disabled = false; }
}
async function applyExpenseHistory() {
  if (!expenseHistoryPlan || !document.getElementById('expense-history-confirm').checked) return;
  const plan = expenseHistoryPlan;
  resetExpenseHistory();
  const status = document.getElementById('expense-history-status');
  try {
    const response = await fetch('/api/expenses/retention/history/apply', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({policy: plan.policy, plan_sha256: plan.plan_sha256, export_sha256: plan.export_sha256,
        confirm_history_removal: true, confirm_export_saved: true}),
    });
    if (!response.ok) throw new Error('History removal did not complete. Preview again; data or authorization may have changed.');
    const result = await response.json();
    status.textContent = `Removed ${result.removed_transactions} transactions. Matching re-imports remain blocked. Reports, chats and backups are separate.`;
  } catch (error) { status.textContent = error.message; }
}


function readableExactDecimal(value) {
  const text = String(value);
  if (/^-?0+(?:\.0+)?(?:e[+-]?\d+)?$/i.test(text)) return '0';
  return /^-?\d+\.\d+$/.test(text) ? text.replace(/0+$/, '').replace(/\.$/, '') : text;
}
async function captureFixtureValuation() {
  if (!executionFixture) return;
  const accountId = executionFixture.account_id;
  const button = document.getElementById('fixture-valuation-capture');
  const status = document.getElementById('fixture-valuation-status');
  button.disabled = true;
  try {
    await fixtureRequest(`/accounts/${accountId}/valuations`, {snapshot_key: crypto.randomUUID()});
    const response = await fetch(`/api/simulator/accounts/${accountId}/valuations`, {cache: 'no-store'});
    if (!response.ok) throw new Error('Saved valuations unavailable.');
    const result = await response.json();
    if (executionFixture?.account_id !== accountId) return;
    const snapshots = result.snapshots.slice().reverse();
    for (const id of ['fixture-valuation-start', 'fixture-valuation-end']) {
      const select = document.getElementById(id); select.replaceChildren();
      for (const row of snapshots) {
        const option = document.createElement('option'); option.value = row.as_of;
        option.textContent = `${row.as_of} · ${readableExactDecimal(row.equity)} ${row.currency}`;
        select.append(option);
      }
    }
    document.getElementById('fixture-valuation-end').selectedIndex = snapshots.length - 1;
    document.getElementById('fixture-valuation-compare').disabled = snapshots.length < 2;
    status.textContent = `Valuation saved. ${snapshots.length} observations shown.` +
      (result.truncated ? ' Only the newest 100 observations are listed.' : '');
  } catch (error) { if (executionFixture?.account_id === accountId) status.textContent = error.message; }
  finally { button.disabled = !executionFixture; }
}
async function compareFixtureValuations() {
  if (!executionFixture) return;
  const accountId = executionFixture.account_id;
  const start = document.getElementById('fixture-valuation-start').value;
  const end = document.getElementById('fixture-valuation-end').value;
  const status = document.getElementById('fixture-valuation-status');
  if (!start || !end || start >= end) { status.textContent = 'Choose an opening observation before the closing observation.'; return; }
  try {
    const query = new URLSearchParams({start, end});
    const response = await fetch(`/api/simulator/accounts/${accountId}/performance?${query}`, {cache: 'no-store'});
    const result = await response.json();
    if (executionFixture?.account_id !== accountId) return;
    if (!response.ok || result.status !== 'complete') throw new Error('Period valuation unavailable; retained evidence may be missing or invalid.');
    status.textContent = `Observed portfolio P&L: ${readableExactDecimal(result.portfolio_pnl)} ${result.currency}. ` +
      `Realized change ${readableExactDecimal(result.realized_change)}; unrealized change ${readableExactDecimal(result.unrealized_change)}; dividend income ${readableExactDecimal(result.dividend_net)}. ` +
      `External flows excluded: ${readableExactDecimal(result.net_external_flows)}. Fees included. ` +
      (result.fx_attribution_status === 'complete'
        ? `Price contribution ${readableExactDecimal(result.price_effect)}; FX contribution ${readableExactDecimal(result.fx_effect)}. Price changes use closing FX. `
        : 'Separate FX attribution unavailable. ') +
      `Benchmark attribution unavailable. ` +
      `Period: ${result.start} to ${result.end_exclusive}.`;
  } catch (error) { if (executionFixture?.account_id === accountId) status.textContent = error.message; }
}


let expensePendingId = null;
let expenseReconciliationPlan = null;
let expenseReconciliationGeneration = 0;
function resetPendingReconciliation() {
  expensePendingId = null;
  expenseReconciliationPlan = null;
  expenseReconciliationGeneration += 1;
  const approval = document.getElementById('expense-reconciliation-confirm');
  approval.checked = false; approval.disabled = true;
  document.getElementById('expense-reconciliation-apply').disabled = true;
  document.getElementById('expense-reconciliation-status').textContent = 'Select a pending transaction below, then its booked entry. No match is inferred.';
  if (expenseSnapshot) renderExpenseTransactions(expenseSnapshot.transactions, expenseSnapshot.currency);
}
function selectPendingReconciliation(id) {
  resetPendingReconciliation();
  expensePendingId = id;
  document.getElementById('expense-reconciliation-controls').open = true;
  const row = expenseSnapshot?.transactions.find(item => item.id === id);
  document.getElementById('expense-reconciliation-status').textContent =
    `Pending selected: ${row?.merchant || 'transaction'}. Select “Review as booked match” on its settled entry. You can change pages.`;
  if (expenseSnapshot) renderExpenseTransactions(expenseSnapshot.transactions, expenseSnapshot.currency);
}
function updatePendingReconciliationApproval() {
  document.getElementById('expense-reconciliation-apply').disabled =
    !expenseReconciliationPlan || !document.getElementById('expense-reconciliation-confirm').checked;
}
async function previewPendingReconciliation(bookedId) {
  if (!expensePendingId) return;
  const pendingId = expensePendingId;
  expenseReconciliationPlan = null;
  const generation = ++expenseReconciliationGeneration;
  const approval = document.getElementById('expense-reconciliation-confirm');
  approval.checked = false; approval.disabled = true;
  updatePendingReconciliationApproval();
  const status = document.getElementById('expense-reconciliation-status');
  status.textContent = 'Checking the selected pair…';
  try {
    const response = await fetch('/api/expenses/reconciliation/preview', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({pending_id: pendingId, booked_id: bookedId}),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail?.reason_code === 'CATEGORY_OVERRIDE_CONFLICT'
      ? 'The entries have different category overrides. Review their categories before linking them.'
      : 'Pair unavailable. Select your pending and booked entries from the same account, currency and transaction type.');
    if (generation !== expenseReconciliationGeneration) return;
    const url = URL.createObjectURL(new Blob([JSON.stringify(result.export, null, 2)], {type: 'application/json'}));
    const link = document.createElement('a'); link.href = url; link.download = 'pending-reconciliation.json';
    link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    expenseReconciliationPlan = result.plan;
    const describe = row => `${row.merchant}, ${row.occurred_at}, ${readableExactDecimal(row.amount)} ${row.currency}`;
    status.textContent = `Review pending: ${describe(result.export.pending)}. Booked: ${describe(result.export.booked)}. ` +
      `The booked amount stays unchanged. ${result.plan.copy_pending_category ? 'Your pending category override will carry over. ' : ''}` +
      'Verify the downloaded pair before confirming. This preview expires after 10 minutes.';
    approval.disabled = false;
    document.getElementById('expense-reconciliation-controls').scrollIntoView({block: 'center'});
  } catch (error) { if (generation === expenseReconciliationGeneration) status.textContent = error.message; }
}
async function applyPendingReconciliation() {
  if (!expenseReconciliationPlan || !document.getElementById('expense-reconciliation-confirm').checked) return;
  const plan = expenseReconciliationPlan;
  resetPendingReconciliation();
  const generation = expenseReconciliationGeneration;
  const status = document.getElementById('expense-reconciliation-status');
  try {
    const response = await fetch('/api/expenses/reconciliation/apply', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken()},
      body: JSON.stringify({pending_id: plan.pending_id, booked_id: plan.booked_id, as_of: plan.as_of,
        plan_sha256: plan.plan_sha256, export_sha256: plan.export_sha256,
        confirm_same_transaction: true, confirm_export_saved: true}),
    });
    if (!response.ok) throw new Error('Resolution did not complete. Preview again; the records or your authorization may have changed.');
    if (generation === expenseReconciliationGeneration) status.textContent =
      'Removed the reviewed pending entry; the booked amount is unchanged. Imports of the removed identity stay blocked.';
    await loadExpenses(true);
  } catch (error) { if (generation === expenseReconciliationGeneration) status.textContent = error.message; }
}
